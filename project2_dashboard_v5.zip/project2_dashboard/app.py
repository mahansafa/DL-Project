import streamlit as st

from lib import ui

st.set_page_config(page_title='Project 2 · Quera AI Bootcamp', page_icon='static/quera.png', layout='wide',
                   initial_sidebar_state='expanded')
ui.inject_css()
st.logo('static/quera.png', size='large')

pages = {
    'Overview': [
        st.Page('views/home.py', title='Home', icon=':material/space_dashboard:', default=True),
    ],
    'NLP · Main task': [
        st.Page('views/nlp_part1.py', title='Part 1 · EDA', icon=':material/query_stats:', url_path='nlp-eda'),
        st.Page('views/nlp_part2.py', title='Part 2 · Warranty', icon=':material/verified_user:', url_path='nlp-warranty'),
        st.Page('views/nlp_part3.py', title='Part 3 · Sentiment model', icon=':material/model_training:', url_path='nlp-model'),
        st.Page('views/nlp_live.py', title='Live prediction', icon=':material/bolt:', url_path='nlp-live'),
    ],
    'NLP · Bonus': [
        st.Page('views/nlp_bonus.py', title='Hidden incentivized reviews', icon=':material/policy:', url_path='nlp-bonus'),
        st.Page('views/nlp_bonus_helpful.py', title='Review helpfulness', icon=':material/thumb_up:', url_path='nlp-helpful'),
        st.Page('views/nlp_bonus_hmm.py', title='HMM · alternative method', icon=':material/account_tree:', url_path='nlp-hmm'),
    ],
    'Vision · Main task': [
        st.Page('views/vision_main.py', title='Accident detection', icon=':material/videocam:', url_path='vision-detection'),
    ],
    'Vision · Bonus': [
        st.Page('views/vision_bonus.py', title='Collision anticipation', icon=':material/warning:', url_path='vision-anticipation'),
    ],
    'Resources': [
        st.Page('views/notebooks.py', title='Notebooks', icon=':material/menu_book:', url_path='notebooks'),
    ],
}

nav = st.navigation(pages, position='sidebar', expanded=True)
nav.run()
