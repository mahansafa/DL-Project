"""Design system: colors, CSS, HTML blocks, plotly template and ECharts helpers."""
import json
import re
from functools import lru_cache
from html import escape
from pathlib import Path

import numpy as np
import plotly.graph_objects as go
import plotly.io as pio
import streamlit as st

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / 'data'

C = dict(
    bg='#060912', panel='#0d1426', panel2='#121b33', line='#1c2540', line2='#26304f',
    text='#e8ecf6', text2='#a3acc6', muted='#6b7491',
    gold='#f5b53f', amber='#fbbf24', cyan='#22d3ee', sky='#38bdf8', teal='#2dd4bf', green='#34d399',
    red='#f43f5e', rose='#fb7185', orange='#fb923c', violet='#a78bfa', pink='#f472b6', slate='#94a3b8',
)
RATING = {1: '#f43f5e', 2: '#fb923c', 3: '#94a3b8', 4: '#38bdf8', 5: '#34d399'}
SENT = {'negative': RATING[1], 'neutral': RATING[3], 'positive': RATING[5]}
MODEL = {'TF-IDF': '#94a3b8', 'MiniLM': '#5eead4', 'DistilRoBERTa': '#a78bfa', 'RoBERTa': '#60a5fa',
         'DeBERTa': '#f5b53f', 'Ensemble': '#f472b6'}
ACCENT = {'nlp': C['gold'], 'vision': C['cyan'], 'home': C['sky']}

FA = str.maketrans('0123456789%,', '۰۱۲۳۴۵۶۷۸۹٪٬')


def fa(x):
    """Persian digits for Persian sentences."""
    return str(x).translate(FA)


def num(x, fmt=','):
    return fa(format(x, fmt))


def half_up(x, digits=0):
    """Round half up (76.5 -> 77), not Python's round-half-to-even."""
    from decimal import Decimal, ROUND_HALF_UP
    q = Decimal(1).scaleb(-digits)
    return float(Decimal(repr(float(x))).quantize(q, rounding=ROUND_HALF_UP))


def nice(x, unit=''):
    """A number written as a percentage: if its first decimal is 5 or more it is rounded up to the next whole number
    (76.5 -> 77, 49.6 -> 50); otherwise it is shown as it is (59.4 stays 59.4, 16.35 stays 16.35)."""
    from decimal import Decimal, ROUND_HALF_UP
    d = Decimal(repr(float(x))).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)
    first = int(abs(d) * 10) % 10
    if first >= 5:
        return f'{int(d.quantize(Decimal(1), rounding=ROUND_HALF_UP))}{unit}'
    text = format(d, 'f').rstrip('0').rstrip('.')
    return f'{text}{unit}'


def fx(x, digits=3):
    """A number not written as a percentage, shown with `digits` decimals. If its third decimal is 5 or more
    (0.746 is 74.6%), it is rounded half up to two decimals: 0.746 -> 0.75, 0.7055 -> 0.71; otherwise it is
    shown as it is: 0.733 stays 0.733."""
    from decimal import Decimal, ROUND_HALF_UP
    shown = Decimal(repr(float(x))).quantize(Decimal(1).scaleb(-digits), rounding=ROUND_HALF_UP)
    text = format(shown, 'f')
    if digits >= 3 and int(text.split('.')[1][2]) >= 5:
        return format(shown.quantize(Decimal('0.01'), rounding=ROUND_HALF_UP), 'f')
    return text


def fnum(v):
    """Like fx, for a value whose precision is not fixed (up to four decimals, trailing zeros dropped)."""
    if isinstance(v, int):
        return str(v)
    text = f'{v:.4f}'.rstrip('0').rstrip('.')
    decimals = len(text.split('.')[1]) if '.' in text else 0
    return fx(v, decimals) if decimals >= 3 else text


def pct(share, unit='%'):
    """A share (0-1) as a percentage under the project rule: 0.765 -> '77%', 0.594 -> '59.4%'."""
    return nice(share * 100, unit)


def pct0(share, unit='%'):
    """A share (0-1) as a whole percentage, rounded half up: 0.125 -> '13%'."""
    return f'{int(half_up(share * 100))}{unit}'


# ---------------------------------------------------------------- CSS
# Every colour in the custom HTML comes from a CSS variable defined with light-dark(),
# so the page follows the light/dark switch in the app menu instantly (the script does
# not rerun on a theme switch, so Python never needs to know the active theme).
INK = 'color-mix(in oklab, var(--c), light-dark(#0b1020, var(--c)) 36%)'          # accent text, darker on light
INK_A = 'color-mix(in oklab, var(--accent), light-dark(#0b1020, var(--accent)) 36%)'

CSS = """
<style>
[data-testid="stApp"] {
  --bg: light-dark(#f4f6fb, #060912);
  --card-a: light-dark(rgba(255,255,255,.97), rgba(20,28,52,.78)); --card-b: light-dark(rgba(250,251,254,.97), rgba(11,17,33,.78));
  --box-a: light-dark(rgba(255,255,255,.92), rgba(20,28,52,.62));  --box-b: light-dark(rgba(250,251,254,.92), rgba(11,17,33,.62));
  --kpi-a: light-dark(#ffffff, rgba(22,31,58,.85));               --kpi-b: light-dark(#fafbfe, rgba(11,17,33,.85));
  --hero-a: light-dark(rgba(255,255,255,.96), rgba(20,28,52,.92)); --hero-b: light-dark(rgba(245,247,252,.96), rgba(8,12,24,.92));
  --tile-a: light-dark(#ffffff, rgba(22,31,58,.9));              --tile-b: light-dark(#f7f9fc, rgba(9,14,28,.9));
  --flat: light-dark(#ffffff, rgba(13,20,38,.8));  --flat2: light-dark(#f8fafd, rgba(9,14,28,.7));
  --edge: light-dark(rgba(15,23,42,.09), rgba(148,163,184,.12)); --edge2: light-dark(rgba(15,23,42,.15), rgba(148,163,184,.18));
  --shadow: light-dark(rgba(15,23,42,.10), rgba(0,0,0,.6)); --shadow2: light-dark(rgba(15,23,42,.13), rgba(0,0,0,.8));
  --inset: light-dark(rgba(255,255,255,.8), rgba(255,255,255,.04));
  --text: light-dark(#141a2e, #e8ecf6); --text2: light-dark(#434c69, #a3acc6); --muted: light-dark(#667090, #6b7491);
  --body: light-dark(#3a4360, #b6bfd8); --body2: light-dark(#2b3350, #d5dbec); --faint: light-dark(#8a92ab, #4f5874);
  --strong: light-dark(#0b1020, #ffffff); --off: light-dark(#d3d8e4, #2a3150); --line: light-dark(#e1e5ee, #1c2540);
  --dot: light-dark(rgba(15,23,42,.07), rgba(255,255,255,.035)); --chip-bg: light-dark(rgba(15,23,42,.035), rgba(255,255,255,.03));
  --side-a: light-dark(#ffffff, #070b16); --side-b: light-dark(#f7f9fc, #060912); --side-edge: light-dark(#e3e7ef, #141c33);
  --h1a: light-dark(#0b1020, #ffffff); --h1b: light-dark(#1d2640, #e8ecf6);
  --accent: #f5b53f;
  background:
    radial-gradient(1100px 520px at 92% -8%, rgba(56,189,248,.10), transparent 60%),
    radial-gradient(900px 480px at -5% 0%, rgba(245,181,63,.08), transparent 62%),
    radial-gradient(800px 600px at 50% 120%, rgba(167,139,250,.07), transparent 60%),
    var(--bg);
  background-attachment: fixed;
}
[data-testid="stApp"]::before {
  content:""; position:fixed; inset:0; pointer-events:none; z-index:0;
  background-image: radial-gradient(var(--dot) 1px, transparent 1px);
  background-size: 24px 24px; mask-image: linear-gradient(180deg, rgba(0,0,0,.9), rgba(0,0,0,.25));
}
header[data-testid="stHeader"] { background: transparent; }
[data-testid="stMainBlockContainer"] { direction: rtl; max-width: 1320px; padding-top: 2.6rem; padding-bottom: 5rem; }
[data-testid="stMainBlockContainer"] p, [data-testid="stMarkdownContainer"] { text-align: right; }
.stPlotlyChart, [data-testid="stDataFrame"], [data-testid="stCode"], [data-testid="stSlider"], .ltr,
[data-testid="stTable"], [data-testid="stCodeBlock"], pre, code,
[class*="EChart"], [data-testid*="Echart"], [data-testid*="EChart"], [data-testid="stTextArea"] textarea,
[data-testid="stTextInput"] input { direction: ltr; }
[data-testid="stCode"] *, pre * { text-align: left !important; }
.ink { color: INK; }

/* sidebar */
[data-testid="stSidebar"] { background: linear-gradient(180deg, var(--side-a) 0%, var(--side-b) 100%); border-right: 1px solid var(--side-edge); }
[data-testid="stSidebarNav"] { padding-top: .4rem; }
[data-testid="stNavSectionHeader"] { color: var(--muted) !important; font-size: .70rem !important; letter-spacing: .14em;
  text-transform: uppercase; font-weight: 800 !important; margin-top: .9rem; }
[data-testid="stSidebarNavLink"] { border-radius: 10px; margin: 1px 0; transition: background .2s; }
[data-testid="stSidebarNavLink"] span { font-weight: 600; font-size: .92rem; }
[data-testid="stSidebarNavLink"][aria-current="page"] { background: linear-gradient(90deg, rgba(245,181,63,.18), rgba(245,181,63,.02)); box-shadow: inset 3px 0 0 #f5b53f; }

/* generic glass card */
.card { background: linear-gradient(180deg, var(--card-a), var(--card-b)); border: 1px solid var(--edge);
        border-radius: 20px; padding: 1.1rem 1.25rem; box-shadow: 0 18px 40px -18px var(--shadow), inset 0 1px 0 var(--inset);
        backdrop-filter: blur(10px); position: relative; overflow: hidden; }
[data-testid="stVerticalBlock"] > [data-testid="stLayoutWrapper"] > [data-testid="stVerticalBlock"][class*="Border"],
div[data-testid="stVerticalBlockBorderWrapper"] {
  background: linear-gradient(180deg, var(--box-a), var(--box-b)) !important; border-radius: 20px !important;
  border-color: var(--edge) !important; box-shadow: 0 18px 40px -22px var(--shadow2); }

/* hero */
.hero { position: relative; border-radius: 28px; padding: 2.2rem 2.4rem 2rem; margin: 0 0 1.6rem; overflow: hidden;
        background: linear-gradient(135deg, var(--hero-a), var(--hero-b)); border: 1px solid var(--edge);
        box-shadow: 0 30px 80px -30px var(--shadow2); }
.hero::before { content:""; position:absolute; inset:-1px; border-radius: 28px; padding:1px; pointer-events:none;
  background: linear-gradient(120deg, var(--accent), transparent 30%, transparent 70%, var(--accent2, #38bdf8));
  -webkit-mask: linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0); -webkit-mask-composite: xor; mask-composite: exclude; opacity:.7; }
.hero .glow { position:absolute; width: 520px; height: 520px; border-radius: 50%; filter: blur(90px); opacity: .22; pointer-events:none;
              background: var(--accent); top: -260px; left: -120px; animation: drift 14s ease-in-out infinite alternate; }
.hero .glow.b { background: var(--accent2, #38bdf8); left: auto; right: -160px; top: -200px; opacity: .16; animation-duration: 18s; }
@keyframes drift { from { transform: translate(0,0) scale(1);} to { transform: translate(60px, 40px) scale(1.15);} }
.eyebrow { display:inline-flex; gap:.5rem; align-items:center; direction:ltr; padding:.34rem .8rem; border-radius:999px; font-size:.74rem;
           font-weight:800; letter-spacing:.14em; text-transform:uppercase; color: INK_A; background: color-mix(in srgb, var(--accent) 12%, transparent);
           border: 1px solid color-mix(in srgb, var(--accent) 35%, transparent); }
.eyebrow .dot { width:7px; height:7px; border-radius:50%; background: var(--accent); box-shadow: 0 0 10px var(--accent); animation: pulse 2s infinite; }
@keyframes pulse { 0%,100% { opacity:1; } 50% { opacity:.35; } }
.hero h1 { font-size: 3.1rem; line-height: 1.08; font-weight: 900; margin: .9rem 0 .6rem; letter-spacing: -.025em; direction: ltr; text-align: right;
           background: linear-gradient(90deg, var(--h1a) 0%, var(--h1b) 45%, INK_A 100%); -webkit-background-clip: text; background-clip: text; color: transparent; }
.hero p.lead { font-size: 1.08rem; color: var(--body); line-height: 2; max-width: 56rem; margin: 0; }
.chips { display:flex; flex-wrap:wrap; gap:.45rem; margin-top: 1.1rem; }
.chip { font-size:.78rem; color: var(--text2); border:1px solid var(--edge2); background: var(--chip-bg); padding:.25rem .65rem;
        border-radius:999px; direction:ltr; font-weight:600; }
.chip.c { color: INK; border-color: color-mix(in srgb, var(--c) 45%, transparent); }
.chip b { color: var(--text); font-weight: 800; }

/* section headings */
.sec { display:flex; align-items:center; gap:.9rem; margin: 2.6rem 0 .4rem; }
.sec .num { flex:0 0 auto; min-width: 46px; height: 46px; padding: 0 .6rem; border-radius: 14px; display:flex; align-items:center; justify-content:center;
            font-weight:900; font-size: .95rem; color: #060912; background: var(--accent); box-shadow: 0 0 0 4px color-mix(in srgb, var(--accent) 18%, transparent), 0 8px 24px -6px var(--accent); direction:ltr; }
.sec h2 { margin:0; font-size: 1.55rem; font-weight: 850; letter-spacing: -.01em; color: var(--text); direction: ltr; }
.sec .fa { color: var(--muted); font-size: .95rem; font-weight: 600; margin-top: .15rem; }
p.take { color: var(--body); font-size: 1rem; line-height: 2; margin: .3rem 0 1rem; max-width: 62rem; }
p.note, .note { color: var(--muted); font-size: .84rem; line-height: 1.9; }
h4.sub { font-size: 1.02rem; font-weight: 800; color: var(--text); margin: .2rem 0 .55rem; display:flex; flex-wrap:wrap; align-items:baseline; gap:.2rem .6rem; }
h4.sub bdi { direction: ltr; unicode-bidi: isolate; }
h4.sub span { color: var(--muted); font-weight: 600; font-size: .84rem; direction: rtl; }

/* KPI tiles */
.kpis { display:grid; grid-template-columns: repeat(auto-fit, minmax(190px, 1fr)); gap: .85rem; margin: .6rem 0 1rem; }
.kpi { position: relative; padding: 1.05rem 1.15rem 1rem; border-radius: 18px; overflow:hidden;
       background: linear-gradient(180deg, var(--kpi-a), var(--kpi-b)); border: 1px solid var(--edge); box-shadow: 0 10px 26px -20px var(--shadow); }
.kpi::before { content:""; position:absolute; top:0; right:0; left:0; height:3px; background: linear-gradient(90deg, transparent, var(--c, var(--accent)), transparent); }
.kpi::after { content:""; position:absolute; width:140px; height:140px; border-radius:50%; background: var(--c, var(--accent)); opacity:.08; filter: blur(30px); top:-60px; left:-40px; }
.kpi .ic { font-size: 1.1rem; opacity:.9; }
.kpi b { display:block; direction:ltr; unicode-bidi:isolate; text-align:right; font-size: 2.05rem; font-weight: 900; line-height: 1.15; margin-top: .25rem; color: INK; letter-spacing: -.02em; font-variant-numeric: tabular-nums; }
.kpi span { display:block; color: var(--text2); font-size: .86rem; line-height: 1.7; margin-top: .2rem; }
.kpi small { display:block; color: var(--muted); font-size: .76rem; margin-top: .15rem; }

/* callouts */
.callout { display:flex; gap:.8rem; align-items:flex-start; border-radius: 16px; padding: .9rem 1.05rem; margin: .7rem 0 1rem; line-height: 1.95;
           background: color-mix(in srgb, var(--c) 9%, var(--flat)); border: 1px solid color-mix(in srgb, var(--c) 30%, transparent); color: var(--body2); font-size: .96rem; }
.callout .i { flex: 0 0 auto; width: 30px; height: 30px; border-radius: 10px; display:flex; align-items:center; justify-content:center;
              background: color-mix(in srgb, var(--c) 22%, transparent); color: INK; font-weight: 900; }
.callout b { color: var(--strong); }

/* quotes */
.quote { border-right: 3px solid var(--c); padding: .75rem 1rem; margin: .55rem 0; background: var(--flat);
         border-radius: 0 0 0 14px; border-top: 1px solid var(--edge); }
.quote .stars { color: light-dark(#e09a12, #f5b53f); letter-spacing: 2px; font-size: .95rem; direction:ltr; display:inline-block; }
.quote .stars i { color: var(--off); font-style: normal; }
.quote p { direction: ltr; text-align: left !important; color: var(--body2); font-size: .9rem; line-height: 1.75; margin: .35rem 0 0; }
.quote .meta { color: var(--muted); font-size: .8rem; margin-right: .4rem; }

/* flow / pipeline */
.flow { display:flex; gap:.55rem; align-items:stretch; flex-wrap:wrap; margin:.7rem 0 .6rem; }
.flow > div.step { flex: 1 1 150px; background: var(--flat); border: 1px solid var(--edge); border-radius: 16px; padding: .85rem 1rem; position: relative; }
.flow > div.step::before { content: attr(data-n); display:block; font-size:.72rem; font-weight:900; color: INK_A; opacity:.85; direction:ltr; text-align:right; margin-bottom:.15rem; letter-spacing:.08em; }
.flow > div.arrow { flex:0 0 auto; display:flex; align-items:center; color: var(--muted); font-size: 1.2rem; }
.flow b { display:block; color: var(--text); font-size: 1rem; margin-bottom: .25rem; direction: ltr; text-align: right; }
.flow span { color: var(--text2); font-size: .85rem; line-height: 1.75; display:block; }

/* rating band */
.band { display:flex; width:100%; border-radius: 14px; overflow:hidden; gap:3px; direction:ltr; }
.band > div { display:flex; flex-direction:column; justify-content:center; align-items:center; color:#fff; font-weight:800; font-size:.9rem;
              line-height:1.2; min-width:0; white-space:nowrap; text-shadow: 0 1px 2px rgba(0,0,0,.25); }
.band > div small { font-weight:600; font-size:.74rem; opacity:.9; }
.band.grow { transform-origin:left center; animation: grow .9s cubic-bezier(.2,.8,.2,1) .2s both; }
@keyframes grow { from { transform: scaleX(0);} to { transform: scaleX(1);} }

/* tables of words */
.wordcols { display:grid; grid-template-columns: repeat(5, 1fr); gap:.8rem; direction:ltr; }
.wordcols h4 { margin:0 0 .45rem; font-size:1rem; font-weight:900; color: var(--text); border-bottom:3px solid var(--c); padding-bottom:.35rem; text-align:left; }
.wordcols span { display:block; color: var(--body2); font-size:.88rem; line-height:1.8; text-align:left; }

/* tabs */
.stTabs [data-baseweb="tab-list"] { gap: .35rem; border-bottom: 1px solid var(--line); }
[data-testid="stTab"] { padding: .5rem .9rem .65rem; border-radius: 12px 12px 0 0; }
[data-testid="stTab"] p { font-size: .98rem !important; font-weight: 800; color: var(--muted); }
[data-testid="stTab"][aria-selected="true"] p { color: var(--text); }

/* expander as code drawer */
[data-testid="stExpander"] details { border-radius: 14px !important; border-color: var(--edge) !important; background: var(--flat2); }
[data-testid="stExpander"] summary p { font-weight: 700; color: var(--text2); }

/* team */
.team { display:grid; grid-template-columns: repeat(3, 1fr); gap:.8rem; }
.member { display:flex; align-items:center; gap:.75rem; padding:.8rem .9rem; border-radius:16px; background: var(--flat);
          border:1px solid var(--edge); direction:ltr; transition: transform .25s, border-color .25s; }
.member:hover { transform: translateY(-3px); border-color: rgba(245,181,63,.45); }
.member .av { flex:0 0 auto; width:42px; height:42px; border-radius: 13px; display:flex; align-items:center; justify-content:center; font-weight:900;
              color:#060912; font-size:.92rem; background: linear-gradient(135deg, var(--a), var(--b)); box-shadow: 0 8px 20px -8px var(--a); }
.member b { display:block; color: var(--text); font-size: .95rem; font-weight: 800; text-align:left; }
.member span { display:block; color: var(--muted); font-size: .76rem; text-align:left; }

/* navigation tiles on home */
.tile { display:block; text-decoration:none !important; border-radius: 22px; padding: 1.3rem 1.4rem; position:relative; overflow:hidden; height:100%;
        background: linear-gradient(160deg, var(--tile-a), var(--tile-b)); border: 1px solid var(--edge); transition: transform .3s, border-color .3s, box-shadow .3s; }
.tile:hover { transform: translateY(-4px); border-color: color-mix(in srgb, var(--c) 60%, transparent); box-shadow: 0 24px 50px -20px color-mix(in srgb, var(--c) 45%, transparent); }
.tile .tag { font-size:.7rem; font-weight:900; letter-spacing:.14em; color: INK; direction:ltr; text-align:right; }
.tile h3 { margin:.45rem 0 .35rem; font-size:1.25rem; font-weight:900; color: var(--text); direction:ltr; text-align:right; }
.tile p { color: var(--text2); font-size:.9rem; line-height:1.9; margin:0; }
.tile .go { position:absolute; left: 1.1rem; bottom: 1rem; color: INK; font-weight:900; font-size:1.2rem; }

/* pending state */
.pending { border-radius: 22px; padding: 2.2rem; text-align:center; border: 1px dashed rgba(34,211,238,.45);
           background: repeating-linear-gradient(135deg, rgba(34,211,238,.06) 0 14px, transparent 14px 28px); }
.pending .spin { width: 56px; height: 56px; margin: 0 auto 1rem; border-radius: 50%; border: 4px solid rgba(34,211,238,.18); border-top-color: #22d3ee; animation: spin 1.1s linear infinite; }
@keyframes spin { to { transform: rotate(360deg);} }
.pending h3 { margin: 0 0 .4rem; color: var(--text); font-weight: 900; }
.pending p { color: var(--text2); margin:0 auto; max-width: 40rem; line-height: 2; text-align: center !important; }

/* verdict (live prediction) */
.verdict { display:flex; align-items:baseline; gap:1.1rem; flex-wrap:wrap; margin:.2rem 0 .8rem; direction: rtl; }
.verdict .big { font-size: 4.4rem; font-weight: 900; line-height:1; animation: rise .55s cubic-bezier(.2,.8,.2,1) both; }
.verdict .starrow { font-size: 2.2rem; letter-spacing: 4px; color: light-dark(#e09a12, #f5b53f); direction:ltr; }
.verdict .starrow span { display:inline-block; animation: pop .5s cubic-bezier(.2,1.6,.4,1) both; }
.verdict .starrow .off { color: var(--off); }
@keyframes pop { from { transform: scale(.2) rotate(-40deg); opacity:0;} to { transform:none; opacity:1;} }
@keyframes rise { from { transform: translateY(18px); opacity:0;} to { transform:none; opacity:1;} }
.reading { direction:ltr; text-align:left; font-size:1.08rem; line-height:2.2; color: var(--text); background: var(--flat);
           border:1px solid var(--edge); border-radius: 16px; padding: 1rem 1.2rem; }
.reading .s { font-weight: 800; }
.reading mark { color: var(--strong); border-radius:6px; padding:1px 4px; }

.strip img { width:100%; display:block; border-radius: 16px; border:1px solid var(--edge); }
.strip-times { display:grid; grid-template-columns: repeat(8, 1fr); direction:ltr; color: var(--muted); font-size:.78rem; text-align:center; margin-top:.35rem; }

.legend { display:flex; flex-wrap:wrap; gap: .9rem; direction:ltr; justify-content:flex-end; font-size:.82rem; color: var(--text2); margin:.2rem 0 .4rem; }
.legend i { display:inline-block; width:10px; height:10px; border-radius:3px; margin-right:.35rem; vertical-align:-1px; }

.board { width:100%; border-collapse: separate; border-spacing: 0 6px; direction:ltr; }
.board td { padding: .55rem .8rem; background: var(--flat); font-size:.9rem; color: var(--body2); }
.board td:first-child { border-radius: 12px 0 0 12px; font-weight:800; }
.board td:last-child { border-radius: 0 12px 12px 0; text-align:right; font-variant-numeric: tabular-nums; font-weight:800; }
.board tr.me td { background: linear-gradient(90deg, rgba(34,211,238,.20), rgba(34,211,238,.05)); color: var(--strong); }
.board .bar { height: 8px; border-radius: 6px; background: var(--c); }

/* 2x2 confusion matrix */
.cm { display:grid; grid-template-columns: 74px 1fr 1fr; gap:7px; direction:ltr; font-size:.82rem; }
.cm .h { color: var(--muted); font-weight:800; display:flex; align-items:center; justify-content:center; text-align:center; line-height:1.3; padding:.2rem; }
.cm .cell { border-radius:14px; padding:.75rem .5rem .7rem; text-align:center; background: color-mix(in srgb, var(--c) 15%, var(--flat));
            border:1px solid color-mix(in srgb, var(--c) 38%, transparent); }
.cm .cell b { display:block; font-size:1.6rem; font-weight:900; color: INK; font-variant-numeric: tabular-nums; line-height:1.2; }
.cm .cell span { display:block; color: var(--text2); font-size:.76rem; line-height:1.5; }

/* method badge (HMM / alternative approaches) */
.badge { display:inline-flex; align-items:center; gap:.45rem; padding:.3rem .75rem; border-radius:10px; font-weight:800; font-size:.8rem; direction:ltr;
         color: INK; background: color-mix(in srgb, var(--c) 14%, transparent); border: 1px solid color-mix(in srgb, var(--c) 40%, transparent); }
.vs { display:grid; grid-template-columns: 1fr auto 1fr; gap: .9rem; align-items: stretch; }
.vs > .side { background: var(--flat); border: 1px solid var(--edge); border-radius: 18px; padding: 1rem 1.15rem; border-top: 3px solid var(--c); }
.vs > .side h4 { margin: 0 0 .35rem; color: var(--text); font-weight: 900; direction: ltr; text-align: right; }
.vs > .side p { margin: 0; color: var(--text2); font-size: .9rem; line-height: 1.9; }
.vs > .mid { display:flex; align-items:center; justify-content:center; font-weight: 900; color: var(--muted); font-size: 1.05rem; }

.footer { margin-top: 3rem; padding-top: 1.2rem; border-top: 1px solid var(--side-edge); color: var(--faint); font-size: .8rem; text-align:center; }
@media (max-width: 900px) { .hero h1 { font-size: 2.1rem; } .wordcols { grid-template-columns: repeat(2, 1fr); } .vs { grid-template-columns: 1fr; } }
@media (prefers-reduced-motion: reduce) { * { animation: none !important; } }
</style>
""".replace('INK_A', INK_A).replace('INK', INK)

# Charts are drawn with the dark palette. In light mode the neutral colours of that palette
# (text, grid lines, panel fills) are swapped by CSS, so a chart never has to be redrawn.
# ECharts uses the SVG renderer, which writes colours as attributes; Plotly writes inline styles.
_SWAP = [  # dark colour, light colour, which properties
    ('#e8ecf6', '#141a2e', 'fill stroke'), ('#a3acc6', '#434c69', 'fill stroke'), ('#6b7491', '#5c6582', 'fill stroke'),
    ('#b6bfd8', '#3a4360', 'fill stroke'), ('#1c2540', '#e1e5ee', 'fill stroke'), ('#26304f', '#cfd5e2', 'fill stroke'),
    ('#2b3558', '#cfd5e2', 'fill stroke'), ('#2a3150', '#d3d8e4', 'fill stroke'), ('#0f1628', '#ffffff', 'fill stroke'),
    ('#0d1426', '#ffffff', 'fill stroke'), ('#94a3b8', '#64748b', 'fill stroke'), ('#060912', '#ffffff', 'stroke'),
]


def _swap_css():
    ec_root, pl_root = '[data-testid="stEChartsChart"]', '.stPlotlyChart'
    rules = []
    for dark, light, props in _SWAP:
        r, g, b = (int(dark[i:i + 2], 16) for i in (1, 3, 5))
        for prop in props.split():
            value = f'light-dark({light}, {dark})'
            rules.append(f'{ec_root} [{prop}="{dark}" i], {ec_root} [{prop}="rgb({r},{g},{b})"] {{ {prop}: {value}; }}')
            rules.append(f'{pl_root} [style*="{prop}: rgb({r}, {g}, {b})"] {{ {prop}: {value} !important; }}')
    # the page background colour used as a fill (treemap gaps, separators): swap it, but keep dark text labels dark
    rules.append(f'{ec_root} :not(text)[fill="#060912" i] {{ fill: light-dark(#ffffff, #060912); }}')
    rules.append(f'{pl_root} :not(text)[style*="fill: rgb(6, 9, 18)"] {{ fill: light-dark(#ffffff, #060912) !important; }}')
    # translucent white washes (radar rings, bar tracks) turn into translucent ink on light backgrounds
    for prop in ('fill', 'stroke'):
        rules.append(f'{ec_root} [{prop}="rgb(255,255,255)"] {{ {prop}: light-dark(#0f172a, #ffffff); }}')
        rules.append(f'{pl_root} [style*="{prop}: rgb(255, 255, 255); {prop}-opacity: 0"] {{ {prop}: light-dark(#0f172a, #ffffff) !important; }}')
    # translucent slate / light-gray lines used for grids, tracks and ticks
    for rgb_ec, rgb_pl, light in (('148,163,184', '148, 163, 184', '#64748b'), ('163,172,198', '163, 172, 198', '#475569')):
        for prop in ('fill', 'stroke'):
            rules.append(f'{ec_root} [{prop}="rgb({rgb_ec})"] {{ {prop}: light-dark({light}, rgb({rgb_ec})); }}')
    return '<style>\n' + '\n'.join(rules) + '\n</style>'


SWAP_CSS = _swap_css()


def inject_css():
    st.html(CSS + SWAP_CSS)


def set_accent(accent, accent2=None):
    st.html(f'<style>[data-testid="stApp"] {{ --accent: {accent}; --accent2: {accent2 or accent}; }}</style>')


# ---------------------------------------------------------------- HTML blocks
def hero(eyebrow, title, lead, chips=(), accent=None, accent2=None):
    accent = accent or C['gold']
    chip_html = ''.join(f'<span class="chip">{c}</span>' for c in chips)
    st.html(f"""
    <div class="hero" style="--accent:{accent}; --accent2:{accent2 or C['sky']}">
      <div class="glow"></div><div class="glow b"></div>
      <span class="eyebrow"><span class="dot"></span>{eyebrow}</span>
      <h1>{title}</h1>
      <p class="lead">{lead}</p>
      <div class="chips">{chip_html}</div>
    </div>""")


def section(num, title, fa_title='', take=''):
    st.html(f"""<div class="sec"><div class="num">{num}</div><div><h2>{title}</h2>
    {f'<div class="fa">{fa_title}</div>' if fa_title else ''}</div></div>
    {f'<p class="take">{take}</p>' if take else ''}""")


def take(text):
    st.html(f'<p class="take">{text}</p>')


def note(text):
    st.html(f'<p class="note">{text}</p>')


def sub(title, small=''):
    st.html(f'<h4 class="sub"><bdi>{title}</bdi>{f"<span>{small}</span>" if small else ""}</h4>')


def kpis(items, cols=None):
    """items: (value, label, small, color, icon)"""
    cells = []
    for it in items:
        value, label = it[0], it[1]
        small = it[2] if len(it) > 2 else ''
        color = it[3] if len(it) > 3 and it[3] else 'var(--text)'
        icon = it[4] if len(it) > 4 else ''
        cells.append(f'<div class="kpi" style="--c:{color}">{f"<div class=ic>{icon}</div>" if icon else ""}<b>{value}</b>'
                     f'<span>{label}</span>{f"<small>{small}</small>" if small else ""}</div>')
    style = f' style="grid-template-columns: repeat({cols}, 1fr)"' if cols else ''
    st.html(f'<div class="kpis"{style}>' + ''.join(cells) + '</div>')


def callout(text, kind='insight'):
    icon, color = {'insight': ('✦', C['gold']), 'warn': ('!', C['orange']), 'ok': ('✓', C['green']),
                   'info': ('i', C['sky']), 'leak': ('⛔', C['red']), 'vision': ('◉', C['cyan'])}[kind]
    st.html(f'<div class="callout" style="--c:{color}"><div class="i">{icon}</div><div>{text}</div></div>')


def flow(steps):
    parts = []
    for k, (title, text) in enumerate(steps, 1):
        parts.append(f'<div class="step" data-n="{k:02d}"><b>{title}</b><span>{text}</span></div>')
        if k < len(steps):
            parts.append('<div class="arrow">←</div>')
    st.html('<div class="flow">' + ''.join(parts) + '</div>')


def legend(items):
    st.html('<div class="legend">' + ''.join(f'<span><i style="background:{c}"></i>{t}</span>' for t, c in items) + '</div>')


def band(shares, labels=None, height=58, grow=False):
    parts = []
    for r in [1, 2, 3, 4, 5]:
        s = shares.get(r, 0)
        label = labels[r] if labels else f'{nice(s * 100)}%'
        text = f'{r}★<small>{label}</small>' if s > 0.045 else ''
        parts.append(f'<div style="flex:{max(s, 1e-4):.5f} 1 0; background:{RATING[r]}" title="{r}★ {label}">{text}</div>')
    return f'<div class="band{" grow" if grow else ""}" style="height:{height}px">' + ''.join(parts) + '</div>'


def stars(k):
    k = int(round(k))
    return '★' * k + '<i>' + '★' * (5 - k) + '</i>'


def quote(text, rating=None, meta='', color=None):
    color = color or (RATING[int(rating)] if rating else C['slate'])
    s = f'<span class="stars">{stars(rating)}</span>' if rating else ''
    st.html(f'<div class="quote" style="--c:{color}">{s}<span class="meta">{meta}</span><p>{escape(text)}</p></div>')


def pending(title, text):
    st.html(f'<div class="pending"><div class="spin"></div><h3>{title}</h3><p>{text}</p></div>')


def footer():
    st.html('<div class="footer">Quera AI Bootcamp · Summer 1405 · Project 2 — built with Streamlit, Plotly & ECharts</div>')


# ---------------------------------------------------------------- plotly
pio.templates['p2'] = go.layout.Template(layout=dict(
    font=dict(family='UI, Inter, Vazirmatn, sans-serif', color=C['text2'], size=13),
    paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)',
    colorway=[C['gold'], C['sky'], C['green'], C['red'], C['violet'], C['orange'], C['teal'], C['pink']],
    xaxis=dict(gridcolor='rgba(148,163,184,.09)', linecolor=C['line'], zerolinecolor=C['line2'], tickfont=dict(color=C['muted']),
               title=dict(font=dict(color=C['text2'], size=12)), automargin=True),
    yaxis=dict(gridcolor='rgba(148,163,184,.09)', linecolor=C['line'], zerolinecolor=C['line2'], tickfont=dict(color=C['muted']),
               title=dict(font=dict(color=C['text2'], size=12)), automargin=True),
    hoverlabel=dict(bgcolor='#0f1628', bordercolor='#26304f', font=dict(family='UI, Inter, sans-serif', color=C['text'], size=13)),
    legend=dict(bgcolor='rgba(0,0,0,0)', font=dict(color=C['text2'])),
    margin=dict(l=8, r=8, t=24, b=8), bargap=0.28,
    title=dict(font=dict(color=C['text'], size=14)),
))
pio.templates.default = 'p2'


_PH = re.compile(r'%\{(x|y|customdata(?:\[(\d+)\])?):([+]?)\.(\d)([f%])\}')


def _hover_value(v, sign, nd, kind):
    v = float(v)
    if kind == '%':
        return pct0(v) if nd == 0 else pct(v)
    text = fx(v, nd) if nd >= 3 else f'{v:.{nd}f}'
    return '+' + text if sign and v >= 0 else text


def _rule_hovers(fig):
    """Hover numbers like %{y:.3f} or %{x:.1%} are written out per point with the project's rounding rule."""
    for tr in fig.data:
        ht = getattr(tr, 'hovertemplate', None)
        if tr.type == 'heatmap' and isinstance(ht, str) and '%{z:' in ht and tr.customdata is None:
            m = re.search(r'%\{z:([+]?)\.(\d)([f%])\}', ht)
            if m:
                sign, nd, kind = m.group(1), int(m.group(2)), m.group(3)
                tr.customdata = [[_hover_value(v, sign, nd, kind) for v in row] for row in tr.z]
                tr.hovertemplate = ht.replace(m.group(0), '%{customdata}')
            continue
        if tr.type not in ('scatter', 'bar', 'scattergl'):
            continue
        if ht is None and tr.hoverinfo not in ('skip', 'none'):
            _default_hover(tr)
            continue
        if not isinstance(ht, str) or not _PH.search(ht):
            continue
        xs, ys, cd = tr.x, tr.y, tr.customdata
        n = len(xs) if xs is not None else (len(ys) if ys is not None else 0)
        out = []
        for i in range(n):
            def rep(m):
                name, idx, sign, nd, kind = m.groups()
                try:
                    if name == 'x':
                        v = xs[i]
                    elif name == 'y':
                        v = ys[i]
                    else:
                        row = cd[i]
                        v = row[int(idx)] if idx is not None else (row if np.ndim(row) == 0 else row[0])
                    return _hover_value(v, sign, int(nd), kind)
                except (TypeError, ValueError, IndexError):
                    return m.group(0)
            out.append(_PH.sub(rep, ht))
        if out:
            tr.hovertemplate = out


def _default_hover(tr):
    """Traces without a hovertemplate would show raw values (0.269); write them out with the rounding rule."""
    def cell(v, axis):
        if isinstance(v, (bool, np.bool_)) or v is None:
            return f'%{{{axis}}}'
        if isinstance(v, (int, np.integer)):
            return f'{int(v):,}'
        if isinstance(v, (float, np.floating)):
            return fnum(float(v)) if abs(v) < 1000 else f'{v:,.0f}'
        return f'%{{{axis}}}'
    xs, ys = tr.x, tr.y
    n = len(xs) if xs is not None else (len(ys) if ys is not None else 0)
    if not n:
        return
    horizontal = tr.type == 'bar' and tr.orientation == 'h'
    name = escape(tr.name) if tr.name else ''
    out = []
    for i in range(n):
        x = cell(xs[i], 'x') if xs is not None else ''
        y = cell(ys[i], 'y') if ys is not None else ''
        body = f'{y}: {x}' if horizontal else (f'{x}: {y}' if xs is not None else y)
        out.append(f'{body}<extra>{name}</extra>')
    tr.hovertemplate = out


def _histograms_to_bars(fig):
    """Plotly labels a histogram bin as '0.04 - 0.05999' on hover. Bin the data here instead and draw bars,
    so the hover shows the bin centre written with the rounding rule."""
    new = []
    for tr in fig.data:
        if tr.type != 'histogram' or tr.x is None:
            new.append(tr)
            continue
        x = np.asarray(tr.x, dtype=float)
        x = x[np.isfinite(x)]
        xb = tr.xbins
        if xb is not None and xb.size is not None and xb.start is not None and xb.end is not None:
            edges = np.arange(float(xb.start), float(xb.end) + float(xb.size) * 0.5, float(xb.size))
        else:
            edges = np.histogram_bin_edges(x, bins=int(tr.nbinsx or 30))
        counts, edges = np.histogram(x, bins=edges)
        width = np.diff(edges)
        norm = tr.histnorm or ''
        if norm == 'probability density':
            y = counts / max(len(x), 1) / width
        elif norm == 'percent':
            y = 100 * counts / max(len(x), 1)
        elif norm == 'probability':
            y = counts / max(len(x), 1)
        else:
            y = counts
        centres = (edges[:-1] + edges[1:]) / 2
        ht = tr.hovertemplate if isinstance(tr.hovertemplate, str) else '%{x}: %{y}' + (f'<extra>{escape(tr.name)}</extra>' if tr.name else '')
        hover = [ht.replace('%{x}', '≈ ' + fnum(round(float(c), 6))) for c in centres]
        if norm == 'percent':
            hover = [h.replace('%{y}', nice(v) + '%') for h, v in zip(hover, y)]
        bar = go.Bar(x=centres, y=y, width=width, name=tr.name, marker=tr.marker.to_plotly_json() if tr.marker else None, opacity=tr.opacity, showlegend=tr.showlegend,
                     legendgroup=tr.legendgroup, xaxis=tr.xaxis, yaxis=tr.yaxis, hovertemplate=hover)
        new.append(bar)
    if any(t.type == 'histogram' for t in fig.data):
        fig.data = []
        for t in new:
            fig.add_trace(t)


def show(fig, height=360, key=None, on_select=None, selection_mode=None, legend_top=False):
    _histograms_to_bars(fig)
    _rule_hovers(fig)
    fig.update_layout(height=height, paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)')
    if legend_top:
        fig.update_layout(legend=dict(orientation='h', y=1.12, x=1, xanchor='right'))
    kw = dict(theme=None, config={'displayModeBar': False, 'scrollZoom': False}, width='stretch')
    if key:
        kw['key'] = key
    if on_select:
        kw['on_select'] = on_select
        kw['selection_mode'] = selection_mode or 'points'
    return st.plotly_chart(fig, **kw)


@lru_cache(maxsize=None)
def _fig_json(path):
    return json.loads((DATA / 'figs' / path).read_text())


def nbfig(path):
    """Raw data of a figure saved in a notebook output (data + layout)."""
    return _fig_json(path)


def rgba(hex_color, a):
    h = hex_color.lstrip('#')
    return f'rgba({int(h[0:2], 16)},{int(h[2:4], 16)},{int(h[4:6], 16)},{a})'


# ---------------------------------------------------------------- ECharts
TOOLTIP = dict(backgroundColor='rgba(15,22,40,.95)', borderColor='#26304f', borderWidth=1,
               textStyle=dict(color=C['text'], fontFamily='UI, Inter, sans-serif', fontSize=13),
               extraCssText='border-radius:12px; box-shadow:0 12px 30px rgba(0,0,0,.45);')
FONT = 'UI, Inter, Vazirmatn, sans-serif'


def ec(spec, height=320, key=None):
    spec.setdefault('backgroundColor', 'transparent')
    spec.setdefault('textStyle', {'fontFamily': FONT, 'color': C['text2']})
    spec.setdefault('animationDuration', 1400)
    spec.setdefault('animationEasing', 'cubicOut')
    st.echarts_chart(spec, height=height, theme=None, renderer='svg', key=key)


def gauge(value, title='', lo=0.0, hi=1.0, color=None, fmt='{value}', bands=None, height=270, key=None, sub='',
          decimals=3, split=None, mark=None, mark_color=None):
    """A speedometer gauge with a progress arc and needle. `mark` draws a small red reference tick (e.g. a baseline)."""
    color = color or C['gold']
    if fmt == '{value}':
        fmt = fx(value, decimals)
    if split is None:
        steps = (hi - lo) / 0.1
        split = int(round(steps)) if abs(steps - round(steps)) < 1e-6 and round(steps) <= 10 else 5
        if split > 6 and split % 2 == 0:
            split //= 2
    axis_color = bands or [[1, 'rgba(148,163,184,.13)']]
    spec = {
        'series': [{
            'type': 'gauge', 'min': lo, 'max': hi, 'startAngle': 210, 'endAngle': -30, 'radius': '92%', 'center': ['50%', '58%'],
            'splitNumber': split,
            'progress': {'show': True, 'width': 14, 'roundCap': True,
                         'itemStyle': {'color': {'type': 'linear', 'x': 0, 'y': 0, 'x2': 1, 'y2': 0,
                                                 'colorStops': [{'offset': 0, 'color': rgba(color, .35)}, {'offset': 1, 'color': color}]},
                                       'shadowColor': color, 'shadowBlur': 16}},
            'axisLine': {'roundCap': True, 'lineStyle': {'width': 14, 'color': axis_color}},
            'axisTick': {'show': True, 'distance': 4, 'splitNumber': 2, 'length': 3, 'lineStyle': {'width': 1, 'color': 'rgba(163,172,198,.25)'}},
            'splitLine': {'distance': 4, 'length': 7, 'lineStyle': {'width': 2, 'color': 'rgba(163,172,198,.45)'}},
            'axisLabel': {'distance': 16, 'color': C['muted'], 'fontSize': 10, 'fontFamily': FONT},
            'pointer': {'icon': 'path://M2.9,0.7L2.9,0.7c1.4,0,2.6,1.2,2.6,2.6v115c0,1.4-1.2,2.6-2.6,2.6l0,0c-1.4,0-2.6-1.2-2.6-2.6V3.3C0.3,1.9,1.4,0.7,2.9,0.7z',
                        'length': '62%', 'width': 7, 'offsetCenter': [0, '6%'], 'itemStyle': {'color': color, 'shadowColor': color, 'shadowBlur': 10}},
            'anchor': {'show': True, 'size': 16, 'showAbove': True, 'itemStyle': {'color': '#0f1628', 'borderColor': color, 'borderWidth': 4}},
            'title': {'offsetCenter': [0, '64%'], 'color': C['text2'], 'fontSize': 12, 'fontFamily': FONT},
            'detail': {'valueAnimation': True, 'offsetCenter': [0, '36%'], 'fontSize': 30, 'fontWeight': 900, 'color': C['text'],
                       'fontFamily': FONT, 'formatter': fmt},
            'data': [{'value': round(float(value), 6), 'name': title}],
        }],
    }
    if mark is not None:
        spec['series'].append({
            'type': 'gauge', 'min': lo, 'max': hi, 'startAngle': 210, 'endAngle': -30, 'radius': '92%', 'center': ['50%', '58%'],
            'axisLine': {'show': False}, 'axisTick': {'show': False}, 'splitLine': {'show': False}, 'axisLabel': {'show': False},
            'progress': {'show': False}, 'anchor': {'show': False}, 'title': {'show': False}, 'detail': {'show': False}, 'z': 5,
            'pointer': {'icon': 'rect', 'length': '17%', 'width': 4, 'offsetCenter': [0, '-83%'],
                        'itemStyle': {'color': mark_color or C['red'], 'borderColor': C['bg'], 'borderWidth': 1}},
            'data': [{'value': round(float(mark), 6)}]})
    if sub:
        spec['graphic'] = [{'type': 'text', 'left': 'center', 'bottom': 4,
                            'style': {'text': sub, 'fill': C['muted'], 'fontSize': 11, 'fontFamily': FONT}}]
    ec(spec, height=height, key=key)


def rings(items, height=300, key=None, center_text=None, max_value=1.0):
    """Concentric progress rings. items: (name, value, color)"""
    n = len(items)
    data = []
    for k, (name, value, color) in enumerate(items):
        outer = 92 - k * 15
        data.append({
            'type': 'gauge', 'startAngle': 90, 'endAngle': -270, 'radius': f'{outer}%', 'min': 0, 'max': max_value,
            'pointer': {'show': False}, 'axisTick': {'show': False}, 'splitLine': {'show': False}, 'axisLabel': {'show': False},
            'progress': {'show': True, 'roundCap': True, 'width': 11, 'itemStyle': {'color': color, 'shadowColor': color, 'shadowBlur': 12}},
            'axisLine': {'lineStyle': {'width': 11, 'color': [[1, 'rgba(148,163,184,.10)']]}},
            'title': {'show': False}, 'detail': {'show': False},
            'data': [{'value': round(float(value), 6), 'name': name}],
            'tooltip': {'formatter': f'{name}: {fnum(float(value))}'},
        })
    spec = {'series': data, 'tooltip': {**TOOLTIP}}
    if center_text:
        spec['graphic'] = [{'type': 'text', 'left': 'center', 'top': 'middle',
                            'style': {'text': center_text, 'fill': C['text'], 'fontSize': 15, 'fontWeight': 800,
                                      'fontFamily': FONT, 'textAlign': 'center'}}]
    ec(spec, height=height, key=key)


def donut(items, height=300, key=None, center=None, center_sub='', rose=False, radius=('52%', '72%'), label=True, fmt='{b}\n{d}%'):
    """items: (name, value, color)"""
    total = sum(v for _, v, _ in items) or 1
    shown = (lambda v: nice(v) + '%') if '{c}%' in fmt else fnum
    spec = {
        'tooltip': {**TOOLTIP, 'trigger': 'item'},
        'series': [{
            'type': 'pie', 'radius': list(radius), 'center': ['50%', '52%'], 'roseType': 'area' if rose else False,
            'avoidLabelOverlap': True, 'padAngle': 2,
            'itemStyle': {'borderRadius': 10, 'borderColor': '#060912', 'borderWidth': 3},
            'label': {'show': label, 'color': C['text2'], 'fontFamily': FONT, 'fontSize': 12, 'formatter': fmt, 'overflow': 'none',
                      'edgeDistance': 6, 'minMargin': 3},
            'labelLine': {'lineStyle': {'color': 'rgba(163,172,198,.35)'}, 'length': 8, 'length2': 8},
            'emphasis': {'scale': True, 'scaleSize': 8, 'label': {'fontWeight': 800, 'color': C['text']}},
            'data': [{'name': n, 'value': v, 'itemStyle': {'color': c, 'shadowColor': c, 'shadowBlur': 10},
                      # percentage text made in Python so it follows the rounding rule ({d} would print 49.63%)
                      'label': {'formatter': fmt.replace('{b}', str(n)).replace('{d}', nice(100 * v / total)).replace('{c}%', nice(v) + '%').replace('{c}', fnum(v))},
                      'tooltip': {'formatter': f'{n}<br/><b>{shown(v)}</b>'}}
                     for n, v, c in items],
        }],
    }
    if center:
        spec['graphic'] = [
            {'type': 'text', 'left': 'center', 'top': '43%', 'style': {'text': center, 'fill': C['text'], 'fontSize': 24, 'fontWeight': 900,
                                                                     'fontFamily': FONT, 'textAlign': 'center'}},
            {'type': 'text', 'left': 'center', 'top': '55%', 'style': {'text': center_sub, 'fill': C['muted'], 'fontSize': 11,
                                                                     'fontFamily': FONT, 'textAlign': 'center'}}]
    ec(spec, height=height, key=key)


def radar(indicators, series, height=380, key=None, lo=None):
    """indicators: list of (name, max); series: list of (name, values, color)"""
    spec = {
        'tooltip': {**TOOLTIP},
        'legend': {'bottom': 0, 'textStyle': {'color': C['text2'], 'fontFamily': FONT}, 'icon': 'roundRect', 'itemGap': 14},
        'radar': {
            'indicator': [{'name': n, 'max': m, **({'min': lo} if lo is not None else {})} for n, m in indicators],
            'radius': '66%', 'center': ['50%', '48%'], 'splitNumber': 4, 'shape': 'polygon',
            'axisName': {'color': C['text2'], 'fontFamily': FONT, 'fontWeight': 700},
            'splitLine': {'lineStyle': {'color': 'rgba(148,163,184,.14)'}},
            'splitArea': {'areaStyle': {'color': ['rgba(255,255,255,.015)', 'rgba(255,255,255,.035)']}},
            'axisLine': {'lineStyle': {'color': 'rgba(148,163,184,.14)'}},
        },
        'series': [{'type': 'radar', 'symbolSize': 5, 'data': [
            {'name': n, 'value': [round(v, 4) for v in vals], 'lineStyle': {'color': c, 'width': 2.2}, 'itemStyle': {'color': c},
             'areaStyle': {'color': rgba(c, .10)},
             'tooltip': {'formatter': f'<b>{n}</b><br/>' + '<br/>'.join(f'{ind}: {fnum(v)}' for (ind, _), v in zip(indicators, vals))}}
            for n, vals, c in series]}],
    }
    ec(spec, height=height, key=key)


def hbar_race(items, height=320, key=None, fmt='{c}', xmax=None, xmin=None):
    """Horizontal bars with rounded ends and glow. items: (name, value, color) in display order (top first)."""
    items = list(items)[::-1]
    spec = {
        'grid': {'left': 8, 'right': 54, 'top': 8, 'bottom': 8, 'containLabel': True},
        'tooltip': {**TOOLTIP, 'trigger': 'item'},
        'xAxis': {'type': 'value', 'show': False, **({'max': xmax} if xmax else {}), **({'min': xmin} if xmin is not None else {})},
        'yAxis': {'type': 'category', 'data': [n for n, _, _ in items], 'axisLine': {'show': False}, 'axisTick': {'show': False},
                  'axisLabel': {'color': C['text2'], 'fontFamily': FONT, 'fontSize': 12, 'fontWeight': 600}},
        'series': [{'type': 'bar', 'barWidth': '58%', 'showBackground': True,
                    'backgroundStyle': {'color': 'rgba(148,163,184,.06)', 'borderRadius': 8},
                    'label': {'show': True, 'position': 'right', 'color': C['text'], 'fontWeight': 800, 'fontFamily': FONT, 'formatter': fmt},
                    'data': [{'value': v, 'label': {'formatter': fmt.replace('{c}', nice(v) if fmt.endswith('%') else fnum(v))},
                              'tooltip': {'formatter': f'{n}: {fnum(v)}'},
                              'itemStyle': {'borderRadius': 8, 'color': {'type': 'linear', 'x': 0, 'y': 0, 'x2': 1, 'y2': 0,
                              'colorStops': [{'offset': 0, 'color': rgba(c, .35)}, {'offset': 1, 'color': c}]}}} for n, v, c in items]}],
    }
    ec(spec, height=height, key=key)


# ---------------------------------------------------------------- notebook code panels
@lru_cache(maxsize=None)
def notebook(key):
    return json.loads((DATA / 'nb' / f'{key}.json').read_text())


def code(nb_key, cells, label=None):
    nb = notebook(nb_key)
    label = label or f'کد این بخش — {nb["name"]}'
    with st.expander(f'⌘  {label}', expanded=False):
        for i in cells:
            c = nb['cells'][i]
            if c['type'] != 'code':
                continue
            st.caption(f'cell [{i}]')
            st.code(c['src'], language='python')
            texts = [o['text'] for o in c['outputs'] if o['kind'] == 'text']
            if texts:
                st.code('\n'.join(texts)[:3000], language='text')
