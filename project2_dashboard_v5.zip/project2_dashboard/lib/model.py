"""TF-IDF + logistic regression from Part 3, rebuilt from plain arrays (no scikit-learn version dependency)."""
import json
import re

import numpy as np
import streamlit as st
from sklearn.feature_extraction.text import CountVectorizer

from lib.ui import DATA

TOKEN = re.compile(r"(?u)\b\w[\w']*\b")


@st.cache_resource
def load():
    z = np.load(DATA / 'part3/tfidf_model.npz', allow_pickle=True)
    vocabulary = json.loads((DATA / 'part3/tfidf_vocabulary.json').read_text())
    counter = CountVectorizer(vocabulary=vocabulary, ngram_range=(1, 2), token_pattern=r"(?u)\b\w[\w']*\b")
    return counter, np.array(vocabulary), z['idf'], z['coef'], z['intercept']


def clean(text):
    text = re.sub(r'<[^>]+>', ' ', text or '')
    text = re.sub(r'http\S+|www\.\S+', ' ', text)
    return re.sub(r'\s+', ' ', text).strip()


def predict(summary, review):
    counter, vocab, idf, coef, intercept = load()
    x = counter.transform([clean(summary) + ' . ' + clean(review)]).astype(np.float32).tocsr()
    x.data = 1 + np.log(x.data)
    x = x.multiply(idf).tocsr()
    norm = np.sqrt((x.data ** 2).sum())
    if norm > 0:
        x = x / norm
    x = x.tocsr()
    scores = np.asarray(x @ coef.T + intercept).ravel()
    probs = np.exp(scores - scores.max())
    probs = probs / probs.sum()
    polarity = {vocab[j]: float(v * (coef[4, j] - coef[0, j])) for j, v in zip(x.indices, x.data)}
    contrib = {vocab[j]: (v * coef[:, j]).tolist() for j, v in zip(x.indices, x.data)}
    return probs, polarity, contrib


def highlight(text, polarity, scale, threshold=0.18):
    words = [(m.start(), m.end(), m.group(0).lower()) for m in TOKEN.finditer(text)]
    out, last = [], 0
    for k, (a, b, word) in enumerate(words):
        value = polarity.get(word, 0)
        if k > 0:
            value += 0.5 * polarity.get(words[k - 1][2] + ' ' + word, 0)
        if k + 1 < len(words):
            value += 0.5 * polarity.get(word + ' ' + words[k + 1][2], 0)
        out.append(text[last:a].replace('<', '&lt;'))
        strength = min(1.0, abs(value) / scale) if scale > 0 else 0
        if strength > threshold:
            color = '52,211,153' if value > 0 else '244,63,94'
            out.append(f'<mark style="background:rgba({color},{0.22 + 0.7 * strength:.2f})">{text[a:b]}</mark>')
        else:
            out.append(text[a:b])
        last = b
    out.append(text[last:].replace('<', '&lt;'))
    return ''.join(out)
