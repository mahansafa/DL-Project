import json

import numpy as np
import pandas as pd
import streamlit as st

from lib.ui import DATA


@st.cache_data
def csv(path, **kw):
    return pd.read_csv(DATA / path, **kw)


@st.cache_data
def parquet(path):
    return pd.read_parquet(DATA / path)


@st.cache_data
def jsonfile(path):
    return json.loads((DATA / path).read_text())


@st.cache_data
def length_stats():
    lengths = parquet('part1/eda_lengths.parquet')
    out = {}
    for r, g in lengths.groupby('overall'):
        q = g['length'].quantile([0.25, 0.5, 0.75]).values
        iqr = q[2] - q[0]
        out[int(r)] = dict(q1=q[0], med=q[1], q3=q[2], lo=max(g['length'].min(), q[0] - 1.5 * iqr),
                           hi=min(g['length'].max(), q[2] + 1.5 * iqr), mean=g['length'].mean(), n=len(g))
    return out


@st.cache_data
def length_hist(limit, width):
    lengths = parquet('part1/eda_lengths.parquet')['length']
    clipped = lengths[lengths <= limit]
    counts, edges = np.histogram(clipped, bins=np.arange(0, limit + width, width))
    return counts, edges
