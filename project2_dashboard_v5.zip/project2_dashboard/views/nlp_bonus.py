import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st
from plotly.subplots import make_subplots

from lib import ui
from lib.ui import C, RATING

ui.set_accent(C['pink'], C['violet'])
ui.hero('NLP · Bonus · New problem', 'Hidden Incentivized Reviews',
        'تا ۳ اکتبر ۲۰۱۶ آمازون نظر در ازای کالای مجانی یا تخفیف‌دار را مجاز می‌دانست، به شرط اعلام در متن؛ بعد ممنوعش کرد. <b>ایده:</b> نظرهای اعلام‌شده‌ی قبل از '
        'ممنوعیت با یک regex و <b>بدون برچسب‌زنی دستی</b> پیدا می‌شوند، جمله‌ی اعلام از همه‌ی متن‌ها حذف می‌شود و مدل یاد می‌گیرد نظر تشویقی را از روی بقیه‌ی متن '
        'تشخیص دهد. بعد روی نظرهای بعد از ممنوعیت اجرا می‌شود و با دو آزمون مستقل از برچسب دستی سنجیده می‌شود. خروجی: صف بررسی، محصول‌ها و برندهای مشکوک و امتیاز اصلاح‌شده.',
        chips=['bonus_incentivized_reviews.ipynb', 'bonus_minilm_finetune.ipynb', 'PU learning · distant supervision', 'GroupKFold by reviewer'],
        accent=C['pink'], accent2=C['violet'])

ui.kpis([
    ('11,917 → 48', 'نظر اعلام‌شده قبل و بعد از ممنوعیت', 'سهم در ژوئن ۲۰۱۶: ۷.۲٪', C['pink'], '⛔'),
    ('+0.51★', 'تورم امتیاز داخل همان محصول', '۲٬۳۴۴ محصول · Wilcoxon p ≈ 6e-179', C['gold'], '★'),
    ('0.714', 'AUC بعد از ممنوعیت روی نظردهنده‌های کنارگذاشته', 'در ۱۰۰۰ نظر اول ۲۴ برابر سهم پایه', C['violet'], '🎯'),
    ('68 vs 9', 'محصول با نظر مشکوکِ غیرعادی زیاد', 'در برابر انتظار تصادفی · p < 0.001', C['sky'], '🔎'),
], cols=4)

# ================================================================= the ban
ui.section('01', 'The 2016 Ban', 'روند ماهانه: سهم نظرهای اعلام‌شده، میانگین امتیاز و سهم خرید تأییدشده')
fm = ui.nbfig('bonus_nlp/cell014_0.json')['data']
x = [v[:10] for v in fm[0]['x']]
fig = make_subplots(rows=3, cols=1, shared_xaxes=True, vertical_spacing=0.06,
                    subplot_titles=['share of disclosed incentivized reviews', 'mean rating', 'share of verified purchases'])
fig.add_scatter(x=x, y=fm[0]['y'], name='disclosed share', line=dict(color=C['pink'], width=3, shape='spline'), fill='tozeroy',
                fillcolor=ui.rgba(C['pink'], .12), customdata=fm[0]['customdata'],
                hovertemplate='%{x|%b %Y}<br>%{y:.1%}<br>%{customdata:,} reviews<extra></extra>', row=1, col=1)
for row, (a, b) in [(2, (1, 2)), (3, (3, 4))]:
    fig.add_scatter(x=x, y=fm[a]['y'], name='all reviews', line=dict(color=C['sky'], width=2.4), legendgroup='all', showlegend=row == 2,
                    row=row, col=1)
    fig.add_scatter(x=x, y=fm[b]['y'], name='without disclosed reviews', line=dict(color=C['gold'], width=2.4, dash='dot'),
                    legendgroup='rest', showlegend=row == 2, row=row, col=1)
fig.add_vline(x='2016-10-03', line_dash='dash', line_color=C['red'])
fig.add_annotation(x='2016-10-03', y=1, yref='paper', text='ban · 2016-10-03', showarrow=False, xanchor='left', font=dict(color=C['red']))
fig.update_yaxes(tickformat='.0%', row=1, col=1)
fig.update_yaxes(tickformat='.0%', row=3, col=1)
fig.update_annotations(font=dict(color=C['text2'], size=12))
fig.update_layout(hovermode='x unified', legend=dict(orientation='h', y=-0.06, x=1, xanchor='right'))
with st.container(border=True):
    ui.show(fig, 620)
ui.callout('سهم نظرهای اعلام‌شده در ژوئن ۲۰۱۶ به ۷.۲٪ رسید و بعد از ممنوعیت صفر شد. قبل از ممنوعیت میانگین همه‌ی نظرها بالاتر از میانگین بدون نظرهای اعلام‌شده بود '
           'و بعد از آن دو خط یکی شدند. فقط <b>۵٪</b> نظرهای اعلام‌شده verified‌اند، در برابر ۸۵٪ بقیه، چون کالا با قیمت معمول خریده نشده؛ این بعداً یک شاخص کمکی می‌شود.', 'insight')
ui.code('bonus_nlp', [8, 11, 13, 14, 16])

# ================================================================= inflation
ui.section('02', 'Rating Inflation', 'آیا نظرهای تشویقی واقعاً امتیاز را بالا برده‌اند؟')
c1, c2 = st.columns([1.2, 1], gap='large')
with c1:
    with st.container(border=True):
        ui.sub('Disclosed minus other reviews of the same product', '۲٬۳۴۴ محصول، قبل از ممنوعیت')
        gaps = ui.nbfig('bonus_nlp/cell021_0.json')['data'][0]['x']
        fig = go.Figure(go.Histogram(x=gaps, xbins=dict(start=-3, end=3, size=0.15), marker_color=C['pink'], marker_line_width=0,
                                     hovertemplate='gap %{x}<br>%{y} products<extra></extra>'))
        fig.add_vline(x=0, line_color=C['text2'], line_dash='dot')
        fig.add_vline(x=0.51, line_color=C['gold'])
        fig.add_annotation(x=0.51, y=1, yref='paper', text='mean +0.51', showarrow=False, xanchor='left', font=dict(color=C['gold']))
        fig.update_xaxes(title='rating gap (stars)')
        fig.update_yaxes(title='products')
        ui.show(fig, 330)
with c2:
    with st.container(border=True):
        ui.sub('Star distribution before the ban', 'سهم هر امتیاز')
        dist = {'disclosed': [.010, .012, .044, .221, .713], 'other reviews': [.091, .065, .095, .192, .556]}
        fig = go.Figure()
        for r in range(1, 6):
            fig.add_bar(y=list(dist), x=[dist[k][r - 1] for k in dist], orientation='h', name=f'{r}★', marker_color=RATING[r],
                        text=[ui.pct0(dist[k][r - 1]) if dist[k][r - 1] > .04 else '' for k in dist], textposition='inside',
                        hovertemplate=f'{r}★ · ' + '%{y}: %{x:.1%}<extra></extra>')
        fig.update_layout(barmode='stack', legend=dict(orientation='h', y=1.18, x=1, xanchor='right'))
        fig.update_xaxes(tickformat='.0%')
        fig.update_traces(textfont=dict(color='#fff'))
        ui.show(fig, 230)
        ui.kpis([('78%', 'محصول‌ها با نظر اعلام‌شده‌ی بالاتر', '', C['gold']), ('5% vs 85%', 'سهم verified', 'اعلام‌شده در برابر بقیه', C['sky'])], cols=2)
c1, c2 = st.columns([1.25, 1], gap='large')
with c1:
    with st.container(border=True):
        ui.sub('After the ban: change in mean rating', 'difference-in-differences داخل گروه‌های هم‌امتیاز قبل از ممنوعیت')
        fd = ui.nbfig('bonus_nlp/cell028_0.json')['data']
        fig = go.Figure()
        for tr, col in zip(fd, [C['pink'], C['slate']]):
            fig.add_bar(x=tr['x'], y=tr['y'], name=tr['name'], marker_color=col, marker_cornerradius=5, text=[f'{v:+.2f}' for v in tr['y']],
                        textposition='outside', customdata=[c[0] for c in tr['customdata']],
                        hovertemplate=tr['name'] + ' · %{x}: %{y:+.3f} (%{customdata} products)<extra></extra>')
        fig.update_traces(textfont=dict(color=C['text2']), cliponaxis=False)
        fig.update_layout(barmode='group', legend=dict(orientation='h', y=1.12, x=1, xanchor='right'))
        fig.update_xaxes(title='mean rating before the ban')
        fig.update_yaxes(title='mean after − mean before')
        ui.show(fig, 340)
with c2:
    with st.container(border=True):
        ui.sub('Products with ≥10 reviews before and after', '۶۹۰ محصول با نظر اعلام‌شده · ۴٬۲۲۲ بدون آن')
        fig = go.Figure()
        for name, pre, post, col in [('had disclosed reviews', 4.219, 3.932, C['pink']), ('no disclosed reviews', 4.139, 3.968, C['slate'])]:
            fig.add_scatter(x=['before the ban', 'after the ban'], y=[pre, post], mode='lines+markers+text', name=name,
                            text=[f'{pre:.2f}', f'{post:.2f}'], textposition=['middle left', 'middle right'], line=dict(color=col, width=4),
                            marker=dict(size=14, line=dict(color=C['bg'], width=2)))
        fig.update_traces(textfont=dict(color=C['text']))
        fig.update_layout(legend=dict(orientation='h', y=1.14, x=1, xanchor='right'))
        fig.update_yaxes(range=[3.85, 4.3], title='mean rating')
        ui.show(fig, 340)
ui.callout('در یک محصول ثابت، نظرهای اعلام‌شده ۰.۵۱ ستاره بالاترند؛ پس بیشتر فاصله‌ی خام (۴.۶۲ در برابر ۴.۰۱) به خود تشویق برمی‌گردد نه به انتخاب محصول‌های بهتر. '
           'محصول‌هایی که این نظرها را داشتند بعد از ممنوعیت <b>۰.۱۲ ستاره بیشتر</b> افت کردند (Mann-Whitney، p ≈ 2e-9)، و این در ۴ گروه از ۵ گروه هم‌امتیاز هم دیده می‌شود. '
           'آزمون‌های جفتی و رتبه‌ای انتخاب شدند چون فاصله‌ها نرمال نیستند.', 'insight')
ui.code('bonus_nlp', [19, 20, 21, 22, 25, 26, 28])

# ================================================================= labels and masking
ui.section('03', 'Labels Without Manual Labelling', 'distant supervision و PU learning؛ masking برای جلوگیری از نشت')
ui.flow([('Weak labels', 'جمله‌ی اعلام قبل از ممنوعیت = مثبت · بقیه = بی‌برچسب'),
         ('Uncertain out', '۴٬۲۸۲ نظر با شکل‌های دیگر اعلام کنار رفتند'),
         ('Hold out people', '۳۰٪ اعلام‌کننده‌ها با همه‌ی نظرهایشان، برای آزمون بعد از ممنوعیت'),
         ('Masking', 'هر جمله‌ای با کلمه‌ی نشانه از همه‌ی متن‌ها حذف شد'),
         ('Train pool', '۴۲٬۳۲۱ نظر روی ۵٬۵۵۲ محصول · ۲۰٪ مثبت')])
LEAK = {'opinions', 'my own', 'full price', 'disclaimer', 'opinions are'}
V1 = ['this', 'opinions', 'my own', 'this review', 'my review', 'please', 'helpful', 'own', 'my reviews', 'pretty', 'or', 'full price', 'am',
      'just as', 'we', 'opinions are', 'cable', 'review helpful', 'always', 'kids', 'my', 'your', 'pros', 'quality', 'this is', 'has',
      'disclaimer', 'husband', 'tested', 'of this']
V2 = ['this', 'please', 'helpful', 'my review', 'this review', 'my reviews', 'or', 'pretty', 'cable', 'review', 'am', 'test', 'we', 'just as',
      'review helpful', 'this is', 'kids', 'guarantee', 'overall', 'your', 'adapters', 'pros', 'husband', 'not only', 'you', 'quality', 'always',
      'vote', 'has', 'tested']
c1, c2 = st.columns(2, gap='large')
for col, title, words, kind in [(c1, 'Masking v1 · leaks left', V1, 'warn'), (c2, 'Masking v2 · clean', V2, 'ok')]:
    with col:
        with st.container(border=True):
            ui.sub(title, 'کلمه‌هایی که بیشترین وزن مثبت را در یک مدل خطی ساده گرفتند')
            pills = ''.join((f'<span class="chip c" style="--c:{C["red"]}">{w}</span>' if w in LEAK else f'<span class="chip">{w}</span>')
                            for w in words)
            st.html(f'<div class="chips" style="direction:ltr; justify-content:flex-start">{pills}</div>')
ui.callout('در نسخه‌ی اول تکه‌هایی از جمله‌ی اعلام نشت کرده بود («opinions are my own»، «full price»، «disclaimer»)؛ فهرست نشانه‌ها بزرگ‌تر شد و در نسخه‌ی دوم هیچ تکه‌ای '
           'از اعلام نمانده. کلمه‌های باقی‌مانده بیشتر عادت نظردهی‌اند («my reviews»، «please vote»، «tested»). masking روی <b>همه‌ی</b> متن‌ها انجام شد تا حذف شدن جمله '
           'خودش نشانه‌ی مثبت بودن نشود؛ AUC طول متن هم از ۰.۸۰ به ۰.۷۵ پایین آمد، پس masking نشانه‌ای در طول نساخت.', 'leak')
ui.code('bonus_nlp', [30, 33, 37, 40, 42, 44, 46])

# ================================================================= models
ui.section('04', 'Model Comparison', 'cross-validation با GroupKFold بر اساس نظردهنده · معیار اصلی average precision (تصادفی = ۰.۲۰)')
c1, c2 = st.columns([1.35, 1], gap='large')
with c1:
    with st.container(border=True):
        fc = ui.nbfig('bonus_nlp/cell071_0.json')['data']
        rows = []
        for tr in fc:
            for name, ap, err, cd in zip(tr['y'], tr['x'], tr['error_x']['array'], tr['customdata']):
                rows.append((name, ap, err, cd[0], tr['name']))
        t = pd.DataFrame(rows, columns=['name', 'AP', 'err', 'AUC', 'features']).sort_values('AP')
        colors = {'length only': C['slate'], 'MiniLM': C['violet'], 'TF-IDF': C['pink']}
        fig = go.Figure(go.Bar(x=t['AP'], y=t['name'], orientation='h', marker_color=[colors[f] for f in t['features']], marker_cornerradius=5,
                               error_x=dict(type='data', array=t['err'], color=C['text2'], thickness=1.4),
                               text=[f'{ui.fx(v)}' for v in t['AP']], textposition='inside', insidetextanchor='end', customdata=t['AUC'],
                               hovertemplate='%{y}<br>AP %{x:.3f} · AUC %{customdata:.3f}<extra></extra>'))
        fig.add_vline(x=0.198, line_dash='dot', line_color=C['muted'])
        fig.add_annotation(x=0.198, y=1, yref='paper', text='random 0.20', showarrow=False, xanchor='left', font=dict(color=C['muted']))
        fig.update_traces(textfont=dict(color='#060912'))
        fig.update_xaxes(range=[0, 0.7], title='average precision (5 folds)')
        ui.show(fig, 400)
        ui.legend([('TF-IDF features', C['pink']), ('MiniLM (frozen or fine-tuned)', C['violet']), ('length only', C['slate'])])
with c2:
    with st.container(border=True):
        ui.sub('Fold by fold', 'MiniLM fine-tuned در برابر linear SVM روی همان foldها')
        folds = pd.DataFrame({'fold': range(5), 'SVM': [.592, .586, .664, .604, .632], 'fine-tuned': [.626, .626, .660, .616, .650]})
        fig = go.Figure()
        for _, r in folds.iterrows():
            fig.add_shape(type='line', x0=r['SVM'], x1=r['fine-tuned'], y0=f"fold {int(r['fold'])}", y1=f"fold {int(r['fold'])}",
                          line=dict(color=C['line2'], width=4), layer='below')
        fig.add_scatter(x=folds['SVM'], y=[f'fold {f}' for f in folds['fold']], mode='markers', name='linear SVM',
                        marker=dict(size=15, color=C['pink'], line=dict(color=C['bg'], width=2)))
        fig.add_scatter(x=folds['fine-tuned'], y=[f'fold {f}' for f in folds['fold']], mode='markers', name='fine-tuned MiniLM',
                        marker=dict(size=15, color=C['violet'], line=dict(color=C['bg'], width=2)))
        fig.update_layout(legend=dict(orientation='h', y=1.16, x=1, xanchor='right'))
        fig.update_xaxes(title='average precision')
        ui.show(fig, 300)
    ui.note('fine-tuned در ۴ fold از ۵ fold در AP و در هر ۵ fold در AUC بهتر است؛ ولی SVM مدل کاری شد: وزن هر کلمه مستقیم قابل توضیح است، روی CPU در چند ثانیه '
            'به صدها هزار نظر امتیاز می‌دهد، و برتری ۰.۰۲ در AP در برابر این دو هزینه کوچک است.')
with st.container(border=True):
    ui.sub('Words with the largest weights in the final SVM', 'قرمز = نشانه‌ی نظر تشویقی · آبی = نشانه‌ی خرید و استفاده‌ی واقعی')
    fw = ui.nbfig('bonus_nlp/cell074_0.json')['data']
    words = sorted([(w, v) for tr in fw for w, v in zip(tr['y'], tr['x'])], key=lambda kv: kv[1])
    fig = go.Figure(go.Bar(y=[w for w, _ in words], x=[v for _, v in words], orientation='h', marker_cornerradius=4,
                           marker_color=[C['pink'] if v > 0 else C['sky'] for _, v in words], hovertemplate='%{y}: %{x:.3f}<extra></extra>'))
    fig.add_vline(x=0, line_color=C['line2'])
    fig.update_yaxes(tickfont=dict(size=11))
    ui.show(fig, 640)
ui.callout('کلمه‌های مثبت بیشتر درباره‌ی خود نظرند، نه کالا: helpful، please، my review و vote، مثل «I hope this review was helpful, please vote». '
           'کلمه‌های منفی نشانه‌ی خرید و استفاده‌ی واقعی‌اند: bought، the price، months، return، customer service و update.', 'insight')
ui.code('bonus_nlp', [50, 52, 55, 56, 57, 58, 62, 63, 64, 68, 70, 71, 74])
ui.code('bonus_minilm', [8, 9, 11, 12, 14, 15], 'کد fine-tune کردن MiniLM — bonus_minilm_finetune.ipynb')

# ================================================================= after the ban
ui.section('05', 'After the Ban: Does It Still Work?', 'مدل هیچ نظری از بعد از ممنوعیت ندیده است')
c1, c2, c3 = st.columns(3, gap='medium')
with c1:
    with st.container(border=True):
        ui.gauge(0.714, 'held-out former disclosers', lo=0.5, hi=1.0, color=C['violet'], decimals=3, height=240, key='b_g1',
                 sub='AUC · 1,292 post-ban reviews')
with c2:
    with st.container(border=True):
        ui.gauge(0.723, 'same test, 5-star reviews only', lo=0.5, hi=1.0, color=C['pink'], decimals=3, height=240, key='b_g2',
                 sub='not just detecting positive tone')
with c3:
    with st.container(border=True):
        ui.gauge(0.732, 'reviewer level', lo=0.5, hi=1.0, color=C['sky'], decimals=3, height=240, key='b_g3',
                 sub='476 people · not driven by a few')
c1, c2 = st.columns([1, 1.2], gap='large')
with c1:
    with st.container(border=True):
        ui.sub('Lift at the top of the review queue', 'سهم نظردهنده‌های کنارگذاشته نسبت به سهم پایه‌ی ۰.۲۸٪')
        ui.hbar_race([('top 100 · 6 people', 77, C['pink']), ('top 1,000 · 36 people', 24, C['violet']), ('top 5,000 · 74 people', 11, C['sky'])],
                     height=220, key='b_lift', fmt='{c}×')
        ui.note('عدد ۱۰۰ نظر اول را باید با احتیاط خواند (۲۲ نظر از ۶ نفر). سیگنال در بالای فهرست قوی است، که با کاربرد صف بررسی جور است.')
with c2:
    with st.container(border=True):
        ui.sub('Post-ban scores', 'توزیع امتیاز مدل: نظردهنده‌های کنارگذاشته در برابر بقیه')
        fdn = ui.nbfig('bonus_nlp/cell084_0.json')['data']
        fig = go.Figure()
        for tr, col in zip(fdn, [C['pink'], C['slate']]):
            fig.add_scatter(x=tr['x'], y=tr['y'], name=tr['name'], mode='lines', line=dict(color=col, width=3, shape='spline'), fill='tozeroy',
                            fillcolor=ui.rgba(col, .12))
        fig.update_xaxes(title='SVM score')
        fig.update_yaxes(title='density')
        fig.update_layout(legend=dict(orientation='h', y=1.12, x=1, xanchor='right'))
        ui.show(fig, 280)
with st.container(border=True):
    ui.sub('Verified purchases by score decile', 'نظر تشویقی معمولاً verified نیست · دهک ۱۰ = مشکوک‌ترین')
    fv = ui.nbfig('bonus_nlp/cell088_0.json')['data'][0]
    fig = go.Figure(go.Bar(x=[str(v) for v in fv['x']], y=fv['y'], marker_cornerradius=6, text=[f'{v:.2f}' for v in fv['y']], textposition='outside',
                           marker_color=[C['slate']] * 8 + [C['violet'], C['pink']]))
    fig.add_hline(y=0.682, line_dash='dot', line_color=C['pink'])
    fig.add_annotation(x=0, xref='paper', y=0.682, text='top 1,000 reviews · 0.68', showarrow=False, xanchor='left', yshift=10, font=dict(color=C['pink']))
    fig.update_traces(textfont=dict(color=C['text2']), cliponaxis=False)
    fig.update_yaxes(range=[0.6, 0.95], title='verified share')
    fig.update_xaxes(title='score decile')
    ui.show(fig, 300)
ui.code('bonus_nlp', [78, 80, 81, 83, 84, 87, 88, 91, 93])

# ================================================================= rings
ui.section('06', 'Review Rings: an Independent Test', 'جفت نظردهنده‌هایی که روی دست‌کم ۵ محصول کم‌نظر مشترکاً نظر داده‌اند — کاملاً مستقل از متن')
fr = ui.nbfig('bonus_nlp/cell101_0.json')['data']
nx_, ny_ = fr[1]['x'], fr[1]['y']
key = {(round(a, 6), round(b, 6)): i for i, (a, b) in enumerate(zip(nx_, ny_))}
ex, ey = fr[0]['x'], fr[0]['y']
links = []
for k in range(0, len(ex) - 1, 3):
    a = key.get((round(ex[k], 6), round(ey[k], 6)))
    b = key.get((round(ex[k + 1], 6), round(ey[k + 1], 6)))
    if a is not None and b is not None:
        links.append({'source': a, 'target': b})
colors = fr[1]['marker']['color']
deg = [int(t.split()[0]) for t in fr[1]['text']]
nodes = [{'id': i, 'name': f'reviewer {i}', 'x': nx_[i] * 600, 'y': ny_[i] * 600, 'value': deg[i],
          'symbolSize': 6 + np.sqrt(deg[i]) * 3.2,
          'itemStyle': {'color': C['pink'] if colors[i] == '#D62728' else C['sky'],
                        'shadowColor': C['pink'] if colors[i] == '#D62728' else C['sky'], 'shadowBlur': 8,
                        'borderColor': '#060912', 'borderWidth': 1}} for i in range(len(nx_))]
c1, c2 = st.columns([1.55, 1], gap='large')
with c1:
    with st.container(border=True):
        ui.sub('The largest ring: 159 reviewers, 497 pairs', 'بکش و زوم کن · صورتی = دست‌کم یک نظر اعلام‌شده')
        ui.ec({'tooltip': {**ui.TOOLTIP, 'formatter': '{b}<br/>{c} connections'},
               'series': [{'type': 'graph', 'layout': 'force', 'roam': True, 'draggable': True, 'data': nodes, 'links': links,
                           'force': {'repulsion': 140, 'edgeLength': [25, 90], 'gravity': 0.05, 'friction': 0.12, 'layoutAnimation': True},
                           'lineStyle': {'color': 'rgba(163,172,198,.38)', 'width': 1.1, 'curveness': 0.1},
                           'emphasis': {'focus': 'adjacency', 'lineStyle': {'width': 2, 'color': C['gold']}},
                           'label': {'show': False}}]}, height=520, key='b_ring')
with c2:
    with st.container(border=True):
        ui.sub('Ring members vs other active reviewers', '۲۰۵ عضو در ۱۱ حلقه')
        comp = pd.DataFrame({'metric': ['mean rating / 5', 'verified share', 'has a disclosed review'],
                             'ring members': [4.490 / 5, .147, .127], 'other active': [4.132 / 5, .836, .044]})
        fig = go.Figure()
        for col, color in [('ring members', C['pink']), ('other active', C['slate'])]:
            fig.add_bar(y=comp['metric'], x=comp[col], orientation='h', name=col, marker_color=color, marker_cornerradius=5,
                        text=[ui.pct0(v) if i else f'{v * 5:.2f}★' for i, v in enumerate(comp[col])], textposition='outside')
        fig.update_traces(textfont=dict(color=C['text2']), cliponaxis=False)
        fig.update_layout(barmode='group', legend=dict(orientation='h', y=1.16, x=1, xanchor='right'))
        fig.update_xaxes(range=[0, 1.1], tickformat='.0%')
        ui.show(fig, 280)
    with st.container(border=True):
        ui.sub('Text model vs ring members (post-ban, never disclosed)', 'AUC')
        ui.rings([('SVM vs all others', 0.761, C['pink']), ('5-star only', 0.743, C['violet']), ('vs similar active reviewers', 0.729, C['sky'])],
                 height=190, key='b_ring_auc', center_text='0.761')
ui.callout('مدل متنی، که هیچ اطلاعی از این شبکه ندارد، به نظرهای بعد از ممنوعیتِ اعضایی که <b>هرگز اعلام نکرده‌اند</b> امتیاز بالاتری می‌دهد. دو روش مستقل — یکی از روی متن '
           'و یکی از روی رفتار — همان افراد را مشکوک نشان می‌دهند. روی همین آزمون MiniLM fine-tune شده بهتر است (۰.۸۰۳ در برابر ۰.۷۶۲) ولی روی آزمون اصلی دو مدل '
           'تقریباً برابرند (۰.۷۲۲ و ۰.۷۲). عضویت در حلقه اثبات نیست: آستانه‌ی ۵ محصول با آزمون آماری انتخاب نشده.', 'insight')
ui.code('bonus_nlp', [96, 98, 99, 101, 103, 106, 108])

# ================================================================= business
ui.section('07', 'Business Output', '۱٪ نظرهای بعد از ممنوعیت با بیشترین امتیاز علامت می‌خورند — برای بررسی و کم کردن وزن، نه حذف خودکار')
c1, c2 = st.columns([1.35, 1], gap='large')
with c1:
    flagged = pd.DataFrame([
        ('Cheetah', 'Cheetah Mounts APFMSB TV Wall Mount Bracket', 448, 19, 3.99, 3.96), ('Cheetah', 'Cheetah APTMM2B TV Wall Mount for 20-70" TVs', 315, 12, 3.90, 3.87),
        ('ODRVM', 'Action Camera HD 1080P Underwater Sports Camera', 56, 10, 4.52, 4.48), ('Old Shark', 'OldShark Dash Cam, 3" 1080P HD Car Recorder', 146, 10, 4.01, 3.96),
        ('Albott', 'Albott 70 Inch Digital SLR Camera Aluminum Tripod', 50, 9, 3.96, 3.76), ('Nucleus', 'Nucleus Anywhere Intercom with Amazon Alexa', 64, 9, 3.50, 3.38),
        ('Fortress Mount', 'Parent tv mount (40"-75" (2016))', 46, 9, 4.24, 4.08), ('AudioAffairs', 'AudioAffairs Bluetooth Plug Radio', 26, 9, 3.92, 3.82),
        ('Huawei', 'Huawei Watch Stainless Steel', 164, 9, 3.91, 3.88), ('ECHOGEAR', 'ECHOGEAR Full Motion Articulating TV Wall Mount', 181, 8, 4.60, 4.58),
        ('Corsair', 'CORSAIR CARBIDE SPEC-02 Mid-Tower Gaming Case', 108, 7, 4.22, 4.22), ('SOLO', 'Solo Conquer 15.6 Inch Expandable Laptop Messenger', 28, 7, 4.75, 4.71),
        ('QualGear', 'QualGear QG-TM-005-WHT 23-Inch to 42-Inch TV Mount', 62, 7, 4.44, 4.40), ('SOLO', 'Solo Astor 15.6 Inch Laptop Slim Brief, Grey', 29, 7, 4.31, 4.23),
        ('StarTech', 'StarTech.com 2m (6ft) Long White Apple 8-pin Lightning', 93, 7, 4.27, 4.24)],
        columns=['brand', 'product', 'reviews', 'flagged', 'rating', 'adjusted'])
    st.dataframe(flagged, hide_index=True, width='stretch', height=35 * 16 + 3,
                 column_config={'product': st.column_config.TextColumn(width='large'),
                                'flagged': st.column_config.ProgressColumn('flagged', format='%d', min_value=0, max_value=20, color='#f472b6'),
                                'rating': st.column_config.NumberColumn('rating', format='%.2f'),
                                'adjusted': st.column_config.NumberColumn('adjusted', format='%.2f')})
    ui.note('۶۸ محصول از ۹٬۳۴۵ محصول (با دست‌کم ۱۰ نظر بعد از ممنوعیت) نظر علامت‌خورده‌ی غیرعادی زیاد دارند (آزمون دوجمله‌ای، p < 0.001)؛ به‌طور تصادفی حدود ۹ مورد انتظار می‌رود.')
with c2:
    with st.container(border=True):
        ui.sub('How much do product ratings move?', 'محصول‌های با دست‌کم ۳۰ نظر · افت ۰.۱ ستاره یا بیشتر')
        sens = pd.DataFrame({'share': ['0.5%', '1%', '2%', '5%'], 'drop': [0, 6, 17, 100], 'largest': [.093, .204, .269, .382]})
        fig = go.Figure()
        fig.add_bar(x=sens['share'], y=sens['drop'], name='products dropping ≥ 0.1★', marker_color=C['violet'], marker_cornerradius=6,
                    text=sens['drop'], textposition='outside', hovertemplate='%{x}: %{y} products<extra></extra>')
        fig.add_scatter(x=sens['share'], y=sens['largest'], name='largest drop (stars)', yaxis='y2', mode='lines+markers',
                        line=dict(color=C['pink'], width=3), marker=dict(size=10), hovertemplate='%{x}: largest drop %{y:.3f}★<extra></extra>')
        fig.update_traces(selector=dict(type='bar'), textfont=dict(color=C['text2']), cliponaxis=False)
        fig.update_layout(yaxis2=dict(overlaying='y', side='right', showgrid=False, tickfont=dict(color=C['pink']), range=[0, 0.45], dtick=0.1, tickformat='.1f'),
                          legend=dict(orientation='h', y=1.16, x=1, xanchor='right'))
        fig.update_xaxes(title='share of reviews flagged')
        ui.show(fig, 300)
    with st.container(border=True):
        ui.sub('Brands with the most flagged reviews', 'برندهای با دست‌کم ۳۰۰ نظر بعد از ممنوعیت')
        fbr = ui.nbfig('bonus_nlp/cell119_0.json')['data'][0]
        pairs = sorted(zip(fbr['y'], fbr['x']), key=lambda kv: -kv[1])[:8]
        ui.hbar_race([(b, round(v * 100, 1), C['pink'] if v > .03 else C['violet']) for b, v in pairs], height=270, key='b_brands', fmt='{c}%')
ui.callout('اثر روی امتیاز محصول‌ها کوچک است: با مرز ۱٪ فقط ۶ محصول از ۲٬۷۹۵ محصول ۰.۱ ستاره یا بیشتر افت می‌کنند و ترتیب محصول‌ها تقریباً عوض نمی‌شود (Spearman ۱.۰۰). '
           'پس ارزش کار بعد از ممنوعیت <b>صف بررسی و فهرست محصول‌ها و برندهای مشکوک</b> است. SOLO با ۱۳.۲٪ جلوتر از بقیه است؛ چون چند کلمه‌ی نوع کالا (کیف، قاب) '
           'هنوز در مدل هست، بخشی از این فاصله ممکن است به نوع کالا برگردد.', 'insight')
ui.code('bonus_nlp', [111, 113, 116, 119, 122])

ui.footer()
