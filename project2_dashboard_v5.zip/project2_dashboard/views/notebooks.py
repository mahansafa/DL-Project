import json

import plotly.graph_objects as go
import streamlit as st

from lib import ui
from lib.ui import C

ui.set_accent(C['violet'], C['sky'])
ui.hero('Resources', 'Notebook Explorer',
        'همه‌ی نوت‌بوک‌های پروژه، سلول به سلول، با کد، متن و خروجی. نمودارهای Plotly همان داده‌ی خروجی نوت‌بوک‌اند که با تم داشبورد دوباره رسم شده‌اند.',
        chips=['12 notebooks', 'markdown · code · outputs'], accent=C['violet'])

GROUPS = {
    'NLP · Part 1': ['part1'], 'NLP · Part 2': ['part2', 'part2_setfit'], 'NLP · Part 3': ['part3_finetune', 'part3_final'],
    'NLP · Bonus': ['bonus_nlp', 'bonus_minilm', 'bonus_helpful', 'part3_hmm'],
    'Vision · Main': ['vision_prep', 'vision_mil'], 'Vision · Bonus': ['vision_bonus'],
}
index = json.loads((ui.DATA / 'nb/index.json').read_text())
c1, c2, c3 = st.columns([1, 1.3, 1])
with c1:
    group = st.selectbox('section', list(GROUPS), key='nb_group')
with c2:
    key = st.selectbox('notebook', GROUPS[group], format_func=lambda k: index[k], key='nb_key')
nb = ui.notebook(key)
cells = nb['cells']
with c3:
    show = st.segmented_control('show', ['all', 'markdown', 'code'], default='all', key='nb_show')

n_code = sum(c['type'] == 'code' for c in cells)
n_md = len(cells) - n_code
n_fig = sum(o['kind'] == 'figure' for c in cells for o in c['outputs'])
ui.kpis([(str(len(cells)), 'سلول', nb['name'], C['violet']), (str(n_code), 'سلول کد', '', C['sky']),
         (str(n_md), 'سلول markdown', '', C['gold']), (str(n_fig), 'نمودار', '', C['green'])], cols=4)


def render_fig(path):
    p = ui.DATA / path
    if not p.exists():
        st.caption('figure shown on the section page')
        return
    f = json.loads(p.read_text())
    # drop the notebook's own template (it can contain trace types newer plotly versions no longer accept)
    layout = {k: v for k, v in f['layout'].items() if k != 'template'}
    fig = go.Figure(data=f['data'], layout=layout, skip_invalid=True)
    fig.update_layout(template='p2', paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)', height=f['layout'].get('height') or 420)
    st.plotly_chart(fig, theme=None, config={'displayModeBar': False}, width='stretch', key=f'nbfig_{path}')


for c in cells:
    if show == 'markdown' and c['type'] != 'markdown':
        continue
    if show == 'code' and c['type'] != 'code':
        continue
    if c['type'] == 'markdown':
        st.markdown(c['src'], unsafe_allow_html=True)
        continue
    st.caption(f'In [{c["i"]}]')
    st.code(c['src'], language='python')
    for o in c['outputs']:
        if o['kind'] == 'text':
            st.code(o['text'], language='text')
        elif o['kind'] == 'figure':
            render_fig(o['path'])
ui.footer()
