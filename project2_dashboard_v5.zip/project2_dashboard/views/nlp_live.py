import numpy as np
import plotly.graph_objects as go
import streamlit as st

from lib import model, ui
from lib.ui import C, RATING, fa

ui.set_accent(C['sky'], C['gold'])
ui.hero('NLP · Live', 'Try the Model',
        'یک نظر به انگلیسی بنویس (مدل روی نظرهای انگلیسی آمازون آموزش دیده) یا یکی از نمونه‌ها را امتحان کن. عقربه میانگین وزنی ستاره‌هاست، '
        'نوار رنگی احتمال هر امتیاز، و رنگ هر کلمه نشان می‌دهد مدل را به کدام سمت هل داده: <b class="ink" style="--c:#34d399">سبز به سمت ۵ ستاره</b> و '
        '<b class="ink" style="--c:#f43f5e">قرمز به سمت ۱ ستاره</b>.', chips=['TF-IDF · 1–2 grams', 'logistic regression · 5 classes', 'runs on CPU, offline'],
        accent=C['sky'])

EXAMPLES = {
    'Happy 😀': ('Best charger I have owned', 'Charges my phone and tablet fast, the cable feels solid and it still works perfectly after six months. Highly recommend.'),
    'Mixed 😐': ('Good sound, weak battery', "The speaker sounds great for the price, but the battery barely lasts three hours and the Bluetooth drops sometimes. It's okay for the money."),
    'Unhappy 😠': ('Stopped working after two weeks', "It worked fine at first but died after two weeks. Customer support never answered and the return window had closed. Don't waste your money."),
    'Not bad 🙂': ('Not bad at all', "Not bad at all. Setup took a few minutes, the picture is clear and it does what it promises, though the remote feels a bit cheap."),
    'Sarcasm 🙃': ('Great, just great', 'Great, the mouse stopped clicking on day three. Exactly what I wanted from a premium product.'),
}


def use_example(name):
    st.session_state['live_summary'], st.session_state['live_review'] = EXAMPLES[name]


if 'live_summary' not in st.session_state:
    use_example('Mixed 😐')

cols = st.columns(len(EXAMPLES))
for col, name in zip(cols, EXAMPLES):
    col.button(name, on_click=use_example, args=(name,), width='stretch', key=f'ex_{name}')

left, right = st.columns([1, 1.15], gap='large')
with left:
    with st.container(border=True):
        ui.sub('Your review', 'خلاصه و متن نظر')
        summary = st.text_input('summary', key='live_summary', label_visibility='collapsed', placeholder='Summary (optional)')
        review = st.text_area('review', key='live_review', height=210, label_visibility='collapsed', placeholder='Write a product review…')
with right:
    with st.container(border=True):
        if not review.strip():
            ui.pending('Waiting for text', 'برای پیش‌بینی، متن نظر را بنویس.')
            probs = None
        else:
            probs, polarity, contrib = model.predict(summary, review)
            rating = int(np.argmax(probs)) + 1
            expected = float(np.dot(probs, np.arange(1, 6)))
            spec = {
                'series': [{
                    'type': 'gauge', 'min': 1, 'max': 5, 'splitNumber': 4, 'startAngle': 200, 'endAngle': -20, 'radius': '88%',
                    'center': ['50%', '64%'],
                    'axisLine': {'lineStyle': {'width': 18, 'color': [[0.2, RATING[1]], [0.4, RATING[2]], [0.6, RATING[3]], [0.8, RATING[4]],
                                                                      [1, RATING[5]]]}},
                    'pointer': {'icon': 'path://M12.8,0.7l12,40.1H0.7L12.8,0.7z', 'length': '16%', 'width': 18, 'offsetCenter': [0, '-58%'],
                                'itemStyle': {'color': C['text'], 'shadowColor': 'rgba(0,0,0,.35)', 'shadowBlur': 8}},
                    'axisTick': {'length': 6, 'distance': -18, 'lineStyle': {'color': 'rgba(6,9,18,.6)', 'width': 1}},
                    'splitLine': {'length': 18, 'distance': -18, 'lineStyle': {'color': '#060912', 'width': 4}},
                    'axisLabel': {'color': C['text2'], 'fontSize': 14, 'fontWeight': 800, 'distance': -46, 'formatter': '{value}★',
                                  'fontFamily': ui.FONT},
                    'title': {'offsetCenter': [0, '32%'], 'color': C['muted'], 'fontSize': 12, 'fontFamily': ui.FONT},
                    'detail': {'valueAnimation': True, 'offsetCenter': [0, '2%'], 'fontSize': 46, 'fontWeight': 900, 'color': RATING[rating],
                               'fontFamily': ui.FONT, 'formatter': f'{expected:.2f}'},
                    'data': [{'value': round(expected, 3), 'name': 'expected stars'}],
                }],
            }
            ui.ec(spec, height=280, key='live_gauge')
            st.html(f"""<div class="verdict" style="justify-content:center">
              <span class="big" style="color:{RATING[rating]}">{rating}</span>
              <span class="starrow">{''.join(f'<span class="{"on" if i < rating else "off"}" style="animation-delay:{0.12 + 0.1 * i:.2f}s">★</span>' for i in range(5))}</span>
              <span class="note">محتمل‌ترین امتیاز · اطمینان {fa(ui.pct0(probs.max()))}</span></div>""")
            st.html(ui.band({r: max(float(probs[r - 1]), 1e-4) for r in range(1, 6)}, labels={r: ui.pct0(probs[r - 1]) for r in range(1, 6)},
                            height=50, grow=True))

if probs is not None:
    c1, c2 = st.columns([1.2, 1], gap='large')
    with c1:
        with st.container(border=True):
            ui.sub('The text through the model’s eyes', 'هر کلمه با رنگ اثرش')
            scale = max([abs(v) for v in polarity.values()] + [1e-6]) * 0.7
            st.html('<div class="reading">' + (f'<span class="s">{model.highlight(model.clean(summary), polarity, scale)}</span><br>' if summary.strip() else '')
                    + model.highlight(model.clean(review), polarity, scale) + '</div>')
    with c2:
        with st.container(border=True):
            ui.sub('Strongest words and phrases', 'وزن به سمت ۵ ستاره منهای وزن به سمت ۱ ستاره')
            items = sorted(polarity.items(), key=lambda kv: kv[1])
            neg = [kv for kv in items if kv[1] < 0][:6]
            pos = [kv for kv in items[::-1] if kv[1] > 0][:6]
            chosen = sorted(neg + pos, key=lambda kv: kv[1])
            if chosen:
                fig = go.Figure(go.Bar(x=[v for _, v in chosen], y=[t for t, _ in chosen], orientation='h', marker_cornerradius=5,
                                       marker_color=[C['green'] if v > 0 else C['red'] for _, v in chosen],
                                       hovertemplate='%{y}: %{x:.3f}<extra></extra>'))
                fig.add_vline(x=0, line_color=C['line2'])
                ui.show(fig, max(240, 30 * len(chosen) + 40))
ui.callout('این صفحه مدل TF-IDF و logistic regression را اجرا می‌کند (روی validation متوازن ۰.۶۰۳ درست) چون روی CPU و بدون اینترنت در کسری از ثانیه جواب می‌دهد و '
           'کلمه‌به‌کلمه قابل توضیح است. مدل نهایی (DeBERTa، ۰.۷۰) زمینه‌ی جمله را بهتر می‌فهمد؛ نمونه‌ی «Sarcasm» جایی است که مدل کلمه‌محور گول می‌خورد، '
           'و «Not bad» نشان می‌دهد چرا جفت‌کلمه‌ها (bigram) و نگه داشتن not لازم بودند.', 'info')
ui.footer()
