import streamlit as st

from lib import ui
from lib.ui import C, fa

ui.set_accent(C['sky'], C['gold'])

TEAM = ['Aria Hosseini', 'Behzad Dadmehr', 'Bita Arabi', 'Pardis Eslami', 'Fatemeh Ashtari', 'Mohammad Mahan Safaiyan']
GRAD = [('#f5b53f', '#fb923c'), ('#38bdf8', '#22d3ee'), ('#a78bfa', '#f472b6'), ('#34d399', '#2dd4bf'),
        ('#fb7185', '#f43f5e'), ('#60a5fa', '#a78bfa')]


def initials(name):
    parts = name.split()
    return (parts[0][0] + parts[-1][0]).upper()


st.html(f"""
<div class="hero" style="--accent:{C['sky']}; --accent2:{C['gold']}; padding: 2.4rem 2.6rem;">
  <div class="glow"></div><div class="glow b"></div>
  <div style="display:flex; gap:2rem; align-items:center; flex-wrap:wrap; direction:rtl;">
    <div style="flex:0 0 auto;">
      <img src="app/static/quera.png" alt="Quera" style="width:150px; height:150px; border-radius:30px; display:block;
           box-shadow: 0 0 0 6px rgba(56,189,248,.12), 0 20px 50px -10px rgba(56,189,248,.55);">
    </div>
    <div style="flex:1 1 420px; min-width:0;">
      <span class="eyebrow"><span class="dot"></span>Quera AI Bootcamp · Summer 1405 · Project 2</span>
      <h1 style="font-size:3.3rem;">Words to Stars,<br>Frames to Alerts</h1>
      <p class="lead">دو مسئله‌ی واقعی هوش مصنوعی روی داده‌ی واقعی: <b class="ink" style="--c:#f5b53f">تحلیل احساس ۸۳۰ هزار نظر آمازون</b>
      از اکتشاف داده تا مدل ترنسفورمر، و <b class="ink" style="--c:#22d3ee">تشخیص و پیش‌بینی تصادف از ویدئوی دوربین خودرو</b>.
      هر عدد این داشبورد مستقیم از خروجی نوت‌بوک‌های پروژه آمده است.</p>
      <div class="chips"><span class="chip">NLP · <b>Amazon Electronics Reviews</b></span><span class="chip">Vision · <b>Nexar Dashcam</b></span>
      <span class="chip">12 notebooks</span><span class="chip">Streamlit · Plotly · ECharts</span></div>
    </div>
  </div>
</div>""")

# ---------------------------------------------------------------- team
c1, c2 = st.columns([3.2, 1], gap='medium')
with c1:
    ui.sub('Team Members', 'اعضای گروه')
    cards = ''.join(f'<div class="member" style="--a:{a}; --b:{b}"><div class="av">{initials(n)}</div>'
                    f'<div><b>{n}</b><span>Team member</span></div></div>' for n, (a, b) in zip(TEAM, GRAD))
    st.html(f'<div class="team">{cards}</div>')
with c2:
    ui.sub('Mentor', 'منتور')
    st.html(f"""<div class="member" style="--a:#f5b53f; --b:#38bdf8; padding:1.05rem; border-color: rgba(245,181,63,.35);
              background: linear-gradient(135deg, rgba(245,181,63,.12), rgba(56,189,248,.06));">
              <div class="av" style="width:52px;height:52px;font-size:1.05rem;">MM</div>
              <div><b style="font-size:1.05rem">Melika Molaei</b><span>Project mentor</span></div></div>""")

# ---------------------------------------------------------------- at a glance
ui.section('◎', 'Project at a Glance', 'پروژه در یک نگاه')
ui.kpis([
    ('830,390', 'نظر آمازون بعد از حذف تکراری‌ها', 'train_data.csv · ۲۰٬۰۰۰ نظر test', C['gold'], '💬'),
    ('18,912', 'نظر درباره‌ی گارانتی', 'word2vec · fastText · غلط‌های املایی', C['amber'], '🛡'),
    ('0.70', 'micro-F1 مدل نهایی روی holdout', 'DeBERTa-v3 · ۵ کلاس متوازن', C['green'], '🎯'),
    ('0.733', 'AUC پیش‌بینی نظر مفید روی test', 'امتیازی · ترنسفورمر + stacking', C['teal'], '👍'),
    ('2,844', 'ویدئوی دوربین خودرو', '۱۵۰۰ train · ۱۳۴۴ کلیپ آزمون رسمی', C['cyan'], '🎥'),
    ('0.810', 'accuracy تشخیص تصادف روی test', 'Attention-MIL + ensemble · ۳۰۰ ویدئو', C['sky'], '🚗'),
    ('0.75', 'mAP پیش‌بینی تصادف روی آزمون رسمی', 'امتیازی · Nexar public و private', C['violet'], '⚡'),
    ('71%', 'اوج امتیاز مدل تشخیص در ۲± ثانیه‌ی حادثه', 'مدل زمان حادثه را ندیده · تصادفی: ۱۱٪', C['gold'], '📍'),
], cols=4)

# ---------------------------------------------------------------- the two problems
ui.section('⇄', 'Two Problems', 'دو بخش پروژه — هر بخش تسک اصلی و امتیازی دارد')
left, right = st.columns(2, gap='large')
with left:
    with st.container(border=True):
        st.html(f"""<span class="eyebrow" style="--accent:{C['gold']}"><span class="dot"></span>NLP · Sentiment Analysis</span>
        <h3 style="margin:.7rem 0 .2rem; font-size:1.55rem; font-weight:900; direction:ltr; text-align:right;">Amazon Electronics Reviews</h3>
        <p class="take" style="margin:0">از متن نظر تا امتیاز ۱ تا ۵: اکتشاف داده، رضایت از گارانتی و مدل احساس.</p>""")
        g1, g2 = st.columns(2)
        with g1:
            ui.gauge(0.70, 'DeBERTa · holdout accuracy', lo=0.2, hi=1.0, color=C['gold'], fmt='0.70', height=230, key='h_g1')
        with g2:
            ui.gauge(0.98, 'warranty set precision', lo=0.5, hi=1.0, color=C['green'], decimals=2, height=230, key='h_g2')
        st.html(f"""<div style="display:grid; grid-template-columns: 1fr 1fr; gap:.7rem;">
          <a class="tile" href="nlp-eda" target="_self" style="--c:{C['gold']}"><div class="tag">MAIN · PART 1</div><h3>EDA</h3><p>توزیع امتیازها، ابر کلمات، طول نظرها، برندها</p><span class="go">←</span></a>
          <a class="tile" href="nlp-warranty" target="_self" style="--c:{C['amber']}"><div class="tag">MAIN · PART 2</div><h3>Warranty</h3><p>embedding، غلط‌های املایی و رضایت از ضمانت</p><span class="go">←</span></a>
          <a class="tile" href="nlp-model" target="_self" style="--c:{C['green']}"><div class="tag">MAIN · PART 3</div><h3>Sentiment Model</h3><p>TF-IDF تا DeBERTa، انتخاب مدل و تحلیل خطا</p><span class="go">←</span></a>
          <a class="tile" href="nlp-live" target="_self" style="--c:{C['sky']}"><div class="tag">LIVE</div><h3>Try the Model</h3><p>یک نظر بنویس و امتیازش را زنده ببین</p><span class="go">←</span></a>
          <a class="tile" href="nlp-bonus" target="_self" style="--c:{C['pink']}"><div class="tag">BONUS · NEW PROBLEM</div><h3>Incentivized Reviews</h3><p>نظرهای تشویقی پنهان بعد از ممنوعیت ۲۰۱۶ آمازون، بدون برچسب‌زنی دستی</p><span class="go">←</span></a>
          <a class="tile" href="nlp-helpful" target="_self" style="--c:{C['teal']}"><div class="tag">BONUS · NEW PROBLEM</div><h3>Review Helpfulness</h3><p>کدام نظر رأی «مفید» می‌گیرد؟ فقط از روی متن · AUC ‏۰.۷۳۳ روی test</p><span class="go">←</span></a>
          <a class="tile" href="nlp-hmm" target="_self" style="--c:{C['violet']}; grid-column: span 2;"><div class="tag">BONUS · ALTERNATIVE METHOD FOR THE MAIN TASK</div><h3>Hidden Markov Models</h3><p>همان تحلیل احساس با یک روش مولد: یک HMM برای هر کلاس · micro-F1 سه‌کلاسه ۰.۷۸۴</p><span class="go">←</span></a>
        </div>""")
with right:
    with st.container(border=True):
        st.html(f"""<span class="eyebrow" style="--accent:{C['cyan']}"><span class="dot"></span>Vision · Dashcam Video</span>
        <h3 style="margin:.7rem 0 .2rem; font-size:1.55rem; font-weight:900; direction:ltr; text-align:right;">Nexar Collision Dataset</h3>
        <p class="take" style="margin:0">از فریم‌های ویدئو تا تشخیص تصادف و هشدار پیش از برخورد.</p>""")
        g1, g2 = st.columns(2)
        with g1:
            ui.gauge(0.810, 'detection · test accuracy', lo=0.5, hi=1.0, color=C['cyan'], fmt='0.810', height=230, key='h_g3')
        with g2:
            ui.gauge(0.746, 'anticipation · test mAP', lo=0.4, hi=1.0, color=C['red'], decimals=3, height=230, key='h_g4')
        st.html(f"""<div style="display:grid; grid-template-columns: 1fr; gap:.7rem;">
          <a class="tile" href="vision-detection" target="_self" style="--c:{C['cyan']}"><div class="tag">MAIN TASK</div><h3>Accident Detection</h3><p>آیا در این ویدئو تصادف رخ می‌دهد؟ Attention-MIL روی لحظه‌های هر ۰.۲ ثانیه · accuracy ‏۰.۸۱۰ روی test</p><span class="go">←</span></a>
          <a class="tile" href="vision-anticipation" target="_self" style="--c:{C['red']}"><div class="tag">BONUS · NEW PROBLEM</div><h3>Collision Anticipation</h3><p>با دیدن فقط ۲ ثانیه‌ی آخر، تا ۰.۵ تا ۱.۵ ثانیه‌ی دیگر تصادف رخ می‌دهد؟ منحنی خطر، آستانه‌ی هشدار و مقایسه با مقاله‌ها</p><span class="go">←</span></a>
        </div>""")

# ---------------------------------------------------------------- project map
ui.section('◉', 'Project Map', 'نقشه‌ی پروژه: هر حلقه یک سطح — مسئله، بخش و روش‌ها')
TREE = {
    'NLP': (C['gold'], {
        'Part 1 · EDA': ['ratings', 'word clouds', 'helpful reviewers', 'review length', 'top products', 'top brands'],
        'Part 2 · Warranty': ['word2vec', 'fastText', 'misspellings', 'MiniLM', 'guarantee filter', 'Bayesian mean', 'experience RF'],
        'Part 3 · Model': ['TF-IDF', 'MiniLM', 'DistilRoBERTa', 'RoBERTa', 'DeBERTa', 'ensemble'],
        'Bonus · Incentivized': ['weak labels', 'masking', 'linear SVM', 'fine-tuned MiniLM', 'review rings', 'business output'],
        'Bonus · Helpfulness': ['vote ≥ 2', 'length baseline', 'DistilRoBERTa', 'stacking', 'threshold', 'lift'],
        'Bonus · HMM': ['per-class HMM', 'bias tuning', '3 & 2 classes'],
    }),
    'Vision': (C['cyan'], {
        'Main · Detection': ['CLIP · DINOv2', 'optical flow', 'Attention-MIL', 'random search', 'ensemble'],
        'Bonus · Anticipation': ['DINOv2', 'LightGBM', '1D CNN', 'risk curves', 'alarm threshold', 'official test'],
    }),
}
data = []
for problem, (col, parts) in TREE.items():
    children = []
    for k, (part, leaves) in enumerate(parts.items()):
        shade = ui.rgba(col, 0.86 - 0.07 * k)
        children.append({'name': part, 'itemStyle': {'color': shade},
                         'children': [{'name': leaf, 'value': 1, 'itemStyle': {'color': ui.rgba(col, 0.38)}} for leaf in leaves]})
    data.append({'name': problem, 'itemStyle': {'color': col}, 'children': children})
with st.container(border=True):
    ui.ec({'tooltip': {**ui.TOOLTIP, 'formatter': '{b}'},
           'series': [{'type': 'sunburst', 'data': data, 'radius': ['12%', '96%'], 'sort': None, 'nodeClick': 'rootToNode',
                       'emphasis': {'focus': 'ancestor'},
                       'itemStyle': {'borderColor': '#060912', 'borderWidth': 2, 'borderRadius': 6},
                       'label': {'color': '#060912', 'fontFamily': ui.FONT, 'fontWeight': 800},
                       'levels': [{}, {'r0': '12%', 'r': '30%', 'label': {'fontSize': 16, 'rotate': 0}},
                                  {'r0': '30%', 'r': '56%', 'label': {'fontSize': 11, 'rotate': 'tangential', 'color': '#060912'}},
                                  {'r0': '56%', 'r': '96%', 'label': {'fontSize': 11, 'rotate': 'radial', 'color': '#e8ecf6', 'fontWeight': 600,
                                                                    'align': 'right'}}]}]},
          height=620, key='home_map')
    ui.note('روی هر بخش کلیک کن تا بزرگ شود؛ روی مرکز کلیک کن تا برگردی.')

# ---------------------------------------------------------------- deliverables
ui.section('✓', 'What Is Inside', 'آنچه در این داشبورد و نوت‌بوک‌ها آمده')
items = [
    ('Part 1 · EDA', 'شش سؤال صورت پروژه، با کد هر سؤال', C['gold']),
    ('Part 2 · Warranty', 'word2vec، fastText، MiniLM و تجربه‌ی واقعی گارانتی', C['amber']),
    ('Part 3 · Model', '۵ مدل، ترکیب، انتخاب با bootstrap و holdout یک‌باره', C['green']),
    ('Live prediction', 'پیش‌بینی زنده با توضیح کلمه‌به‌کلمه', C['sky']),
    ('Bonus · Incentivized', 'مسئله‌ی جدید: نظرهای تشویقی پنهان + حلقه‌های نظردهی', C['pink']),
    ('Bonus · Helpfulness', 'مسئله‌ی جدید: پیش‌بینی رأی «مفید» با ترنسفورمر و stacking', C['teal']),
    ('Bonus · HMM', 'روش دیگر برای تسک اصلی: مدل مولد HMM برای هر کلاس', C['violet']),
    ('Bonus · Vision', 'مسئله‌ی جدید: پیش‌بینی برخورد + متادیتا', C['red']),
    ('Main · Vision', 'تشخیص تصادف: ویژگی حرکت، Attention-MIL و ensemble · accuracy ‏۰.۸۱۰ روی test', C['cyan']),
    ('Notebooks', 'همه‌ی نوت‌بوک‌ها با کد و خروجی، داخل داشبورد', C['violet']),
]
cards = ''.join(f'<div class="kpi" style="--c:{c}; padding:.9rem 1rem;"><b style="font-size:1.05rem; direction:ltr; text-align:right;">{t}</b>'
                f'<span>{d}</span></div>' for t, d, c in items)
st.html(f'<div class="kpis" style="grid-template-columns: repeat(auto-fit, minmax(230px, 1fr));">{cards}</div>')
ui.footer()
