import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from lib import data, ui
from lib.ui import C, RATING, fa

ui.set_accent(C['amber'], C['sky'])
W = data.csv('part2/warranty_reviews.csv', index_col=0)
ratings = data.csv('part1/eda_ratings.csv').set_index('rating')

ui.hero('NLP · Main task · Part 2', 'Warranty Satisfaction',
        'کدام نظرها درباره‌ی ضمانت کالا (گارانتی، وارانتی و ...) حرف می‌زنند و مشتری‌ها چقدر از آن راضی‌اند؟ جست‌وجوی دقیق warranty و guarantee '
        'غلط‌های املایی و کلمه‌های هم‌خانواده را نمی‌گیرد؛ پس کلمه‌های مشابه با word2vec و fastText، غلط‌ها با فاصله‌ی ویرایشی، و embedding یک '
        'ترنسفورمر برای مقایسه پیدا شدند. بعد از رتبه‌ی ستاره‌ای جلوتر رفتیم و خود <b>تجربه‌ی گارانتی</b> را سنجیدیم (روش خلاقانه، تأییدشده توسط منتور).',
        chips=['part2_warranty.ipynb', 'part2_setfit.ipynb', 'gensim · word2vec · fastText', 'MiniLM', 'random forest'],
        accent=C['amber'])

ui.kpis([
    ('18,912', 'نظر درباره‌ی گارانتی', '۲.۳٪ کل نظرها', C['amber'], '🛡'),
    ('3.08', 'میانگین امتیاز نظرهای گارانتی', 'در برابر ۴.۰۴ برای بقیه', RATING[1], '★'),
    ('49 / 50', 'نمونه‌ی تصادفی واقعاً درباره‌ی گارانتی', 'precision · بازه‌ی ۹۵٪: ۰.۹۰ تا ۱.۰۰', C['green'], '✓'),
    ('34%', 'تجربه‌های گارانتی خوب', 'امتیاز ستاره‌ای این را ~۶۰٪ نشان می‌دهد', C['sky'], '🔎'),
], cols=4)

# ================================================================= pipeline
ui.section('01', 'From Two Keywords to 18,912 Reviews', 'مسیر ساختن مجموعه‌ی نظرهای گارانتی')
ui.flow([('Exact match', 'warranty یا guarantee دقیق: ۱۷٬۲۳۸ نظر'),
         ('word2vec', 'sg، CBOW و phrases روی خود نظرها + GoogleNews'),
         ('Misspellings', 'Damerau-Levenshtein + fastText روی تکه‌ی کلمه'),
         ('MiniLM', 'مقایسه با embedding ترنسفورمر'),
         ('Plans & RMA', 'SquareTrade، Asurion، protection plan، rma'),
         ('Guarantee filter', 'حذف «guarantee» به معنی عمومی')])
c1, c2 = st.columns([1.35, 1], gap='large')
with c1:
    with st.container(border=True):
        ui.sub('Waterfall', 'هر مرحله چند نظر اضافه یا کم کرد')
        f = ui.nbfig('part2/cell095_0.json')['data'][0]
        fig = go.Figure(go.Waterfall(x=f['x'], y=f['y'], measure=f['measure'], text=f['text'], textposition='outside',
                                     connector=dict(line=dict(color=C['line2'], dash='dot')),
                                     increasing=dict(marker=dict(color=C['green'])), decreasing=dict(marker=dict(color=C['red'])),
                                     totals=dict(marker=dict(color=C['amber'])),
                                     textfont=dict(color=C['text'])))
        fig.data[0].update(base=None)
        fig.update_yaxes(range=[15000, 20500], title='reviews')
        ui.show(fig, 360)
with c2:
    with st.container(border=True):
        ui.sub('Final set by source', 'گروه هر نظر در مجموعه‌ی نهایی')
        counts = W['group'].value_counts()
        ui.donut([('keywords & misspellings', int(counts['word']), C['amber']), ('rma', int(counts['rma']), C['red']),
                  ('protection plans', int(counts['plan']), C['violet'])], height=330, key='w_src',
                 center='18,912', center_sub='warranty reviews', fmt='{b}\n{c}')
ui.code('part2', [13, 14, 15, 16, 18, 95])

# ================================================================= embeddings
ui.section('02', 'Similar Words From Embeddings', 'کلمه‌های نزدیک به warranty و guarantee')
NEIGHBORS = {
    'warranty': {
        'skip-gram': ['warrantee', 'warrenty', 'warranties', 'warantee', 'honored', 'expired', 'warrantied', 'honor', 'honoring', 'policy',
                      'waranty', 'expires', 'honour', 'warrantech', 'squaretrade', 'assurant', 'honors', 'lifetime', 'upheld', 'warenty'],
        'CBOW': ['warrantee', 'warrenty', 'warranties', 'waranty', 'warantee', 'warrantied', 'squaretrade', 'contract', 'guarantee', 'policy',
                 'guaranty', 'rebate', 'assurant', 'warenty', 'rma', 'asurion', 'eligibility', 'rebates', 'warrany', 'refunds'],
        'phrases': ['warrantee', 'warrenty', 'warranty_period', 'warranties', 'year_warranty', 'warantee', 'square_trade', 'refused_to_honor',
                    'policy', 'year_warrantee', 'honoring', 'covered_under', 'assurant', 'honoring_their', 'yr_warranty', 'month_warranty',
                    'waranty', 'return_policy', 'extended_warranty', 'expired'],
        'GoogleNews': ['warranties', 'warrantee', 'Warranty', 'lifetime_warranty', 'Limited_Warranty', 'extended_warranties', 'warrantees',
                       'Lifetime_Warranty', 'powertrain_warranty', 'Warranties', 'Extended_Warranty', 'limited_powertrain_warranty',
                       'powertrain_warranties', 'warrantied', 'years/###', 'AppleCare_Protection_Plan', 'Extended_warranties', ',###_mile',
                       'year/###', 'anti_perforation_warranty'],
        'fastText': ['warrantee', 'warrantees', 'warranteed', 'waranty', 'warrant', 'warrantech', 'warrantied', 'guaranty', 'warranties',
                     'warrants', 'warranted', 'warrantly', 'warrany', 'warranting', 'warraty', 'warrenty', 'unwarranted', 'gurantee'],
    },
    'guarantee': {
        'skip-gram': ['guaranty', 'commitments', 'promise', 'guarentee', 'warrenty', 'guarantees', 'warenty', 'upheld', 'lifetime', 'refunds',
                      'honored', 'transferrable', 'cashing', 'honer', 'warrantech', 'honour', 'warranty', 'reimbursement', 'warrantee', 'uphold'],
        'CBOW': ['guaranty', 'warrantee', 'promise', 'warranty', 'honor', 'warranties', 'warrenty', 'guarentee', 'commitment', 'deny', 'contract',
                 'guarantees', 'warantee', 'assure', 'offer', 'refunds', 'payment', 'authorize', 'reward', 'honored'],
        'phrases': ['guaranty', 'commitments', 'reimburse', 'satisfaction_guarantee', 'honor', 'honour', 'guarantees', 'warrenty', 'guarentee',
                    'warranty', 'lifetime_warranty', 'honored', 'promise', 'refunds', 'honor_their', 'guaranteed', 'warranties',
                    'lifetime_guarantee', 'stand_behind', 'unconditional'],
        'GoogleNews': ['guarantees', 'guaranteed', 'guaranteeing', 'assure', 'assurances', 'ensure', 'Guarantee', 'assurance', 'insure',
                       'Disclaimer_Past_performance', 'guarentee', 'Guaranteed', 'assured', 'gurantee', 'assuring', 'assures', 'Guarantees',
                       'gaurantee', 'certainty', 'ironclad_guarantee'],
    },
}
TYPO = set('warrantee warrenty warantee waranty warrantied warenty warrany warraty warrantly gurantee guarentee gaurantee '
           'warranteed warrantees guaranty'.split())
COMPANY = set('squaretrade assurant asurion rma square_trade warrantech applecare'.split())
c1, c2 = st.columns([1.15, 1], gap='large')
with c1:
    with st.container(border=True):
        ui.sub('Nearest neighbours', 'یک کلمه و یک مدل انتخاب کن')
        word = st.segmented_control('word', ['warranty', 'guarantee'], default='warranty', label_visibility='collapsed', key='w_word')
        models = list(NEIGHBORS[word or 'warranty'])
        model = st.segmented_control('model', models, default='CBOW', label_visibility='collapsed', key='w_model')
        model = model if model in NEIGHBORS[word or 'warranty'] else 'CBOW'
        near = NEIGHBORS[word or 'warranty'][model]
        pills = []
        for k, w in enumerate(near, 1):
            col = C['red'] if w in TYPO else (C['violet'] if w in COMPANY or 'trade' in w else (C['amber'] if 'warrant' in w or 'guarant' in w else C['slate']))
            size = 1.18 - k * 0.018
            pills.append(f'<span class="chip c" style="font-size:{size:.2f}rem; --c:{col}">'
                         f'<b style="color:var(--muted); font-weight:700">{k}</b>&nbsp; {w}</span>')
        st.html('<div class="chips" style="direction:ltr; justify-content:flex-start; gap:.5rem">' + ''.join(pills) + '</div>')
        ui.legend([('misspelling', C['red']), ('company / plan', C['violet']), ('word family', C['amber']), ('other', C['slate'])])
with c2:
    with st.container(border=True):
        ui.sub('How close are the variants?', 'رتبه‌ی شکل‌ها و غلط‌ها در کنار warranty (کمتر = نزدیک‌تر)')
        rank = pd.DataFrame({'model': ['skip-gram', 'CBOW', 'phrases', 'GoogleNews'], 'top50': [11, 13, 7, 4],
                             'median_rank': [46, 21, 88, 1040], 'companies_top50': [3, 3, 3, 0], 'missing': [0, 0, 0, 12]})
        fig = go.Figure()
        fig.add_bar(x=rank['model'], y=rank['top50'], name='variants in top 50 (of 21)', marker_color=C['amber'], marker_cornerradius=6,
                    text=rank['top50'], textposition='outside')
        fig.add_bar(x=rank['model'], y=rank['companies_top50'], name='warranty companies in top 50 (of 4)', marker_color=C['violet'],
                    marker_cornerradius=6, text=rank['companies_top50'], textposition='outside')
        fig.update_layout(barmode='group', legend=dict(orientation='h', y=1.14, x=1, xanchor='right'))
        fig.update_traces(textfont=dict(color=C['text']), cliponaxis=False)
        ui.show(fig, 300)
ui.callout('مدل‌هایی که روی <b>خود نظرها</b> آموزش دیدند غلط‌های رایج و شرکت‌های گارانتی را کنار warranty می‌گذارند؛ بردارهای از پیش‌آموخته‌ی GoogleNews '
           '۱۲ غلط را اصلاً ندارند و guarantee را به معنی عمومی «تضمین کردن» می‌شناسند. CBOW با median rank برابر ۲۱ بهترین بود و حدود سه برابر سریع‌تر از '
           'skip-gram است؛ پس CBOW انتخاب شد. word2vec فقط برای کلمه‌های ۵ بار یا بیشتر بردار دارد، پس غلط‌های کمیاب با فاصله‌ی ویرایشی پیدا شدند.', 'insight')

c1, c2 = st.columns([1.3, 1], gap='large')
with c1:
    with st.container(border=True):
        ui.sub('Misspellings found in the corpus', 'هر مستطیل یک غلط املایی با تعداد تکرارش؛ مساحت ∝ √تعداد')
        fig_t = ui.nbfig('part2/cell047_0.json')['data']
        nodes = []
        for tr in fig_t:
            has_vec = 'has vector' in tr['name']
            for wv, cnt, cd in zip(tr['y'], tr['x'], tr['customdata']):
                nodes.append({'name': wv, 'value': cnt, 'target': cd[0], 'vec': has_vec})
        tree = {
            'tooltip': {**ui.TOOLTIP, 'formatter': '{b}'},
            'series': [{'type': 'treemap', 'roam': False, 'nodeClick': False, 'breadcrumb': {'show': False},
                        'left': 0, 'right': 0, 'top': 0, 'bottom': 0, 'squareRatio': 1.2,
                        'label': {'show': True, 'formatter': '{b}', 'color': '#fff', 'fontFamily': ui.FONT, 'fontWeight': 700, 'fontSize': 12},
                        'upperLabel': {'show': False},
                        'itemStyle': {'borderColor': '#060912', 'borderWidth': 3, 'gapWidth': 3, 'borderRadius': 6},
                        'data': [{'name': 'warranty', 'itemStyle': {'color': ui.rgba(C['amber'], .85)},
                                  'children': [{'name': f"{n['name']}  {n['value']}", 'value': round(float(np.sqrt(n['value'])), 3),
                                                'itemStyle': {'color': ui.rgba(C['amber'], .95 if n['vec'] else .45)}}
                                               for n in nodes if n['target'] == 'warranty']},
                                 {'name': 'guarantee', 'itemStyle': {'color': ui.rgba(C['sky'], .85)},
                                  'children': [{'name': f"{n['name']}  {n['value']}", 'value': round(float(np.sqrt(n['value'])), 3),
                                                'itemStyle': {'color': ui.rgba(C['sky'], .95 if n['vec'] else .45)}}
                                               for n in nodes if n['target'] == 'guarantee']}]}],
        }
        ui.ec(tree, height=360, key='w_tree')
        ui.legend([('misspelling of warranty', C['amber']), ('misspelling of guarantee', C['sky']), ('faded = too rare for a word2vec vector', C['slate'])])
with c2:
    with st.container(border=True):
        ui.sub('CBOW vs MiniLM ranks', 'هر نقطه یک کلمه؛ محور لگاریتمی')
        fr = ui.nbfig('part2/cell062_0.json')['data']
        fig = go.Figure()
        for tr, col in zip(fr, [C['amber'], C['violet'], C['red']]):
            fig.add_scatter(x=tr['x'], y=tr['y'], mode='markers', name=tr['name'], text=tr.get('hovertext'),
                            marker=dict(size=11, color=col, line=dict(color=C['bg'], width=1.5)),
                            hovertemplate='<b>%{text}</b><br>CBOW rank %{x}<br>MiniLM rank %{y}<extra>' + tr['name'] + '</extra>')
        fig.add_scatter(x=[1, 40000], y=[1, 40000], mode='lines', line=dict(color=C['line2'], dash='dot'), showlegend=False, hoverinfo='skip')
        fig.update_xaxes(type='log', title='rank next to warranty · CBOW', dtick=1)
        fig.update_yaxes(type='log', title='rank · MiniLM', dtick=1)
        fig.update_layout(legend=dict(orientation='h', y=1.12, x=1, xanchor='right'))
        ui.show(fig, 360)
ui.callout('MiniLM غلط‌هایی را که تکه‌ی «warrant» در آن‌ها سالم مانده خوب پیدا می‌کند ولی اگر غلط همین تکه را خراب کند (gaurantee، waranty) دور می‌افتد، '
           'شرکت‌های گارانتی را نمی‌شناسد و warrant را نزدیک warranty می‌گذارد. شباهتش بیشتر <b>املایی</b> است تا شباهت کاربرد؛ پس فهرست کلمات را بهتر نکرد.', 'warn')
ui.code('part2', [32, 33, 34, 41, 42, 47, 51, 60, 61, 62])

# ================================================================= guarantee filter
ui.section('03', 'Which “Guarantee” Is About a Warranty?', 'جدا کردن guarantee به معنی ضمانت کالا از معنی عمومی')
ui.take('«guaranteed to fit» یا «satisfaction guaranteed» درباره‌ی ضمانت کالا نیست. پنج روش روی نمونه‌های برچسب‌خورده مقایسه شدند: dev برای ساختن قاعده‌ها، '
        'test برای آزمون نسخه‌ی اول و <b>val فقط برای گزارش نهایی</b>.')
FILTER = pd.DataFrame([
    ('dev', 'all', .32, 1.00, .32), ('dev', 'rules v1', .85, .88, .91), ('dev', 'rules v2', .88, .88, .92), ('dev', 'CBOW fit', .87, .50, .81),
    ('dev', 'zero-shot', .56, .73, .72), ('dev', 'MiniLM + LR', .62, .69, .76),
    ('test', 'all', .34, 1.00, .34), ('test', 'rules v1', .68, 1.00, .84), ('test', 'rules v2', .94, 1.00, .98), ('test', 'CBOW fit', .88, .41, .78),
    ('test', 'zero-shot', .48, .59, .64), ('test', 'MiniLM + LR', .73, .65, .80),
    ('val', 'all', .28, 1.00, .28), ('val', 'rules v1', .54, 1.00, .76), ('val', 'rules v2', .74, 1.00, .90), ('val', 'CBOW fit', .88, .50, .84),
    ('val', 'zero-shot', .44, .50, .68), ('val', 'MiniLM + LR', .85, .79, .90)], columns=['set', 'method', 'precision', 'recall', 'accuracy'])
c1, c2 = st.columns([1.4, 1], gap='large')
with c1:
    with st.container(border=True):
        which = st.segmented_control('set', ['val', 'test', 'dev'], default='val', label_visibility='collapsed', key='w_set')
        part = FILTER[FILTER['set'] == (which or 'val')]
        colors = {'all': C['slate'], 'rules v1': C['orange'], 'rules v2': C['amber'], 'CBOW fit': C['violet'], 'zero-shot': C['red'], 'MiniLM + LR': C['sky']}
        fig = go.Figure()
        for _, r in part.iterrows():
            fig.add_scatter(x=[r['recall']], y=[r['precision']], mode='markers+text', text=[r['method']], textposition='top center',
                            marker=dict(size=14 + 26 * r['accuracy'], color=colors[r['method']], opacity=.9, line=dict(color=C['bg'], width=2)),
                            textfont=dict(color=colors[r['method']], size=12), name=r['method'], showlegend=False,
                            hovertemplate=f"{r['method']}<br>precision {r['precision']:.2f}<br>recall {r['recall']:.2f}<br>accuracy {r['accuracy']:.2f}<extra></extra>")
        fig.update_xaxes(range=[0.3, 1.1], title='recall (share of real warranty mentions kept)')
        fig.update_yaxes(range=[0.15, 1.08], title='precision')
        ui.show(fig, 380)
        ui.note('اندازه‌ی هر دایره = accuracy. گوشه‌ی بالا-راست بهترین است.')
with c2:
    with st.container(border=True):
        ui.sub('Rules v2 on the held-out val', 'روی ۵۰ نظری که در ساختن قاعده‌ها دیده نشد')
        ui.rings([('recall', 1.0, C['green']), ('accuracy', 0.90, C['amber']), ('precision', 0.74, C['sky'])], height=250, key='w_rings',
                 center_text='rules v2')
        ui.legend([('recall 1.00', C['green']), ('accuracy 0.90', C['amber']), ('precision 0.74', C['sky'])])
ui.callout('نسخه‌ی دوم قاعده‌ها روی val (که در ساختنش دیده نشده بود) recall برابر ۱ و accuracy برابر ۰.۹۰ دارد. CBOW (پرسیدن اینکه warranty چقدر در جای خالی '
           'guarantee می‌نشیند) recall پایینی دارد، zero-shot ضعیف است و logistic regression روی MiniLM با ۱۳۰ برچسب از قاعده‌ها بهتر نیست. '
           'نسخه‌ی دوم روی کل داده اعمال شد: <b>۸۸۷ نظر</b> با guarantee عمومی کنار رفتند.', 'ok')
ui.code('part2', [83, 84, 85, 87, 89, 90, 91, 94])

# ================================================================= quality of the final set
ui.section('04', 'How Good Is the Final Set?', 'precision و recall مجموعه‌ی نهایی با نمونه‌گیری')
c1, c2, c3 = st.columns(3, gap='medium')
with c1:
    with st.container(border=True):
        ui.gauge(0.98, 'precision · 49 of 50', lo=0.5, hi=1.0, color=C['green'], decimals=2, height=250, key='w_prec',
                 sub='95% interval 0.90 – 1.00')
with c2:
    with st.container(border=True):
        ui.gauge(0.96, 'recall · strict definition', lo=0.5, hi=1.0, color=C['amber'], decimals=2, height=250, key='w_rec1',
                 sub='talks about the warranty itself')
with c3:
    with st.container(border=True):
        ui.gauge(0.63, 'recall · broad definition', lo=0.5, hi=1.0, color=C['orange'], decimals=2, height=250, key='w_rec2',
                 sub='any repair or replacement story')
ui.callout('در ۱۰۰ نظر بیرون از مجموعه که کلمه‌هایی مثل replaced، defective یا manufacturer دارند، فقط ۱ نظر با تعریف صورت پروژه جا مانده بود. '
           'ولی ۱۵ نظر از ۱۰۰ تعویض یا تعمیر را بدون اسم بردن از گارانتی تعریف می‌کنند («شرکت یک نمونه‌ی جدید فرستاد») و میانگین امتیازشان بالاتر است: '
           'تجربه‌های خوب پس از فروش کمتر کلمه‌ی گارانتی را می‌آورند. پس ۳.۰۸ رضایت را احتمالاً <b>کمتر از واقعیت</b> نشان می‌دهد.', 'warn')
ui.code('part2', [97, 98, 100, 101])

# ================================================================= ratings
ui.section('05', 'Warranty Reviews Are Much Harsher', 'میانگین امتیاز هر کالا روی نظرهای گارانتی')
total = int(ratings['count'].sum())
other = ratings['count'] - W['overall'].value_counts().reindex(ratings.index, fill_value=0)
st.html('<p class="note" style="margin-top:.4rem">بقیه‌ی نظرها · میانگین ۴.۰۴</p>' + ui.band((other / other.sum()).to_dict(), height=46)
        + '<p class="note" style="margin-top:.8rem">نظرهای گارانتی · میانگین ۳.۰۸</p>'
        + ui.band(W['overall'].value_counts(normalize=True).to_dict(), height=46, grow=True))
c1, c2 = st.columns([1.2, 1], gap='large')
with c1:
    with st.container(border=True):
        ui.sub('Same product, warranty reviews minus the rest', '۶۱۸ محصول با دست‌کم ۵ نظر از هر دو نوع')
        gaps = ui.nbfig('part2/cell112_0.json')['data'][0]['x']
        fig = go.Figure(go.Histogram(x=gaps, xbins=dict(start=-4, end=2, size=0.2), marker_color=C['amber'], marker_line_width=0,
                                     hovertemplate='gap %{x}<br>%{y} products<extra></extra>'))
        fig.add_vline(x=0, line_color=C['text2'], line_dash='dot')
        fig.add_vline(x=-0.93, line_color=C['red'])
        fig.add_annotation(x=-0.93, y=1, yref='paper', text='mean −0.93', showarrow=False, xanchor='right', font=dict(color=C['red']))
        fig.update_xaxes(title='rating gap (stars)')
        fig.update_yaxes(title='products')
        ui.show(fig, 320)
with c2:
    ui.kpis([('84%', 'محصول‌ها که نظرهای گارانتی‌شان پایین‌تر است', 'میانه‌ی فاصله −۰.۹۷ ستاره', C['red'], '↓'),
             ('0.98', 'Spearman رتبه‌بندی با و بدون rma', '۱۵ محصول از ۲۰ بدترین یکسان‌اند', C['sky'], '≈')], cols=1)
    ui.callout('حتی در یک محصول ثابت هم نظرهای گارانتی حدود یک ستاره پایین‌ترند؛ یعنی این عدد هم <b>خرابی محصول</b> را نشان می‌دهد و هم تجربه‌ی گارانتی را.', 'insight')

# ================================================================= per product
ui.section('06', 'Warranty Satisfaction per Product', 'میانگین Bayesian برای اینکه محصول‌های کم‌نظر بالا و پایین فهرست را نگیرند')
ui.take('بیشتر محصول‌ها فقط ۱ نظر گارانتی دارند. میانگین هر محصول به سمت میانگین کل (۳.۰۸) کشیده شد: '
        '<code>bayes = (n·mean + m·C) / (n + m)</code>، و m از نسبت واریانس داخل محصول به واریانس بین محصول‌ها برآورد شد (m ≈ ۳).')
products = data.csv('part2/warranty_by_product.csv')
c1, c2 = st.columns([1, 1.2], gap='large')
with c1:
    with st.container(border=True):
        ui.sub('Raw vs Bayesian mean', 'هر نقطه یک محصول؛ رنگ = تعداد نظر گارانتی')
        fs = ui.nbfig('part2/cell109_0.json')['data']
        fig = go.Figure()
        for tr, col in zip(fs, [C['slate'], C['sky'], C['amber'], C['red']]):
            fig.add_scattergl(x=tr['x'], y=tr['y'], mode='markers', name=f"{tr['name']} reviews",
                              marker=dict(size=6 if tr['name'] in ('1', '2-4') else 9, color=col, opacity=.55 if tr['name'] == '1' else .8),
                              hovertemplate='raw %{x:.2f} → bayes %{y:.2f}<extra></extra>')
        fig.add_scatter(x=[1, 5], y=[1, 5], mode='lines', line=dict(color=C['line2'], dash='dot'), showlegend=False, hoverinfo='skip')
        fig.add_hline(y=3.08, line_color=C['muted'], line_dash='dot')
        fig.update_xaxes(title='raw mean of warranty reviews')
        fig.update_yaxes(title='Bayesian mean')
        fig.update_layout(legend=dict(orientation='h', y=1.12, x=1, xanchor='right'))
        ui.show(fig, 390)
with c2:
    with st.container(border=True):
        query = st.text_input('search', placeholder='Search a product or brand · e.g. Seagate, Kindle, router', label_visibility='collapsed',
                              key='w_query')
        if query.strip():
            q = query.strip()
            part = products[products['title'].str.contains(q, case=False, regex=False, na=False)
                            | products['brand'].str.contains(q, case=False, regex=False, na=False)].nlargest(12, 'n')
        else:
            which = st.segmented_control('order', ['worst', 'best'], default='worst', label_visibility='collapsed', key='w_order')
            pool = products[products['n'] >= 5]
            part = pool.nsmallest(12, 'bayes') if which != 'best' else pool.nlargest(12, 'bayes')
        table = pd.DataFrame({'brand': part['brand'], 'product': part['title'], 'warranty reviews': part['n'],
                              'bayes': part['bayes'], 'other reviews': part['mean_other']})
        st.dataframe(table, hide_index=True, width='stretch', height=35 * 13 + 3,
                     column_config={'product': st.column_config.TextColumn(width='large'),
                                    'bayes': st.column_config.ProgressColumn('warranty mean', format='%.2f', min_value=1, max_value=5,
                                                                             color='#fbbf24'),
                                    'other reviews': st.column_config.NumberColumn('other reviews mean', format='%.2f')})
ui.callout('پایین فهرست محصول‌هایی‌اند که مشتری برای گرفتن گارانتی به دردسر افتاده (کارت حافظه‌ی Lexar، تلویزیون VIZIO، مودم NETGEAR) و بالای فهرست '
           'آن‌هایی که گارانتی مادام‌العمرشان واقعاً اجرا شده (کابل‌های Syncwire، Anker و Belkin).', 'insight')
ui.code('part2', [104, 105, 106, 107, 108, 109, 110, 112, 113])

# ================================================================= brands
ui.section('07', 'Brands', 'میانگین امتیاز نظرهای گارانتی برای برندهایی با دست‌کم ۵۰ نظر گارانتی')
brands = data.csv('part2/warranty_by_brand.csv').sort_values('mean')
c1, c2 = st.columns([1.35, 1], gap='large')
with c1:
    with st.container(border=True):
        ui.sub('Forest plot', 'میانگین با بازه‌ی ۹۵٪؛ رنگ = فاصله با بقیه‌ی نظرهای همان محصول‌ها')
        fig = go.Figure(go.Scatter(
            x=brands['mean'], y=brands['brand'], mode='markers',
            error_x=dict(type='data', array=brands['ci'], color='rgba(163,172,198,.35)', thickness=1.4, width=0),
            marker=dict(size=np.clip(np.sqrt(brands['n']) * 0.9, 7, 24), color=brands['gap'],
                        colorscale=[[0, C['red']], [0.6, C['amber']], [1, C['green']]], cmin=-2, cmax=0,
                        line=dict(color=C['bg'], width=1.5),
                        colorbar=dict(title=dict(text='gap', font=dict(color=C['text2'])), thickness=10, len=.5, tickfont=dict(color=C['muted']))),
            customdata=np.stack([brands['n'], brands['gap'], brands['mean_other']], axis=1),
            hovertemplate='<b>%{y}</b><br>warranty mean %{x:.2f}<br>%{customdata[0]} reviews<br>others %{customdata[2]:.2f} (gap %{customdata[1]:.2f})<extra></extra>'))
        fig.update_xaxes(title='mean rating of warranty reviews', range=[1, 5])
        fig.update_yaxes(tickfont=dict(size=10))
        ui.show(fig, 900)
with c2:
    ui.kpis([('1.86 → 4.74', 'از VIZIO تا Syncwire', '۶۱ برند · ۸٬۷۰۲ نظر', C['amber'], '↕'),
             ('p ≈ 7e-189', 'Kruskal-Wallis', 'فرق برندها تصادفی نیست', C['sky'], 'Σ')], cols=1)
    with st.container(border=True):
        ui.sub('Same market, very different warranty', 'در یک بازار')
        market = pd.DataFrame([
            ('storage', 'western digital', 3.06, .17), ('storage', 'seagate', 2.42, .19), ('storage', 'toshiba', 2.38, .28),
            ('storage', 'crucial', 3.66, .45), ('storage', 'sandisk', 2.89, .21), ('storage', 'lexar', 1.98, .31), ('storage', 'pny', 2.63, .30),
            ('storage', 'transcend', 2.51, .42), ('pc parts', 'evga', 3.96, .20), ('pc parts', 'corsair', 3.18, .21), ('pc parts', 'msi', 2.64, .28),
            ('pc parts', 'gigabyte', 2.52, .31), ('pc parts', 'asus', 2.43, .12), ('networking', 'tp-link', 2.83, .22),
            ('networking', 'netgear', 2.46, .20)], columns=['market', 'brand', 'mean', 'ci'])
        fig = go.Figure()
        for m, col in [('storage', C['amber']), ('pc parts', C['violet']), ('networking', C['sky'])]:
            p = market[market['market'] == m].sort_values('mean')
            fig.add_scatter(x=p['mean'], y=[m] * len(p), mode='markers+text', text=p['brand'],
                            textposition=['top center' if k % 2 == 0 else 'bottom center' for k in range(len(p))],
                            textfont=dict(size=10, color=C['text2']), marker=dict(size=13, color=col, line=dict(color=C['bg'], width=2)),
                            error_x=dict(type='data', array=p['ci'], color=ui.rgba(col, .4), thickness=1.2, width=0), name=m, showlegend=False,
                            hovertemplate='%{text}: %{x:.2f}<extra></extra>')
        fig.update_xaxes(range=[1.5, 4.5], title='warranty mean')
        ui.show(fig, 300)
    ui.callout('EVGA با ۳.۹۶ در برابر Asus با ۲.۴۳، و Western Digital با ۳.۰۶ در برابر Seagate با ۲.۴۲، در حالی که سهم نظرهای گارانتی این دو تقریباً برابر است '
               'و بازه‌هایشان روی هم نمی‌افتد. آزمون بر پایه‌ی رتبه انتخاب شد چون امتیاز ۱ تا ۵ ترتیبی است و نرمال نیست.', 'insight')
ui.code('part2', [117, 118, 119, 120, 121])

# ================================================================= plans + length
ui.section('08', 'Protection Plans and Warranty Length', 'طرح‌های گارانتی شرکت‌های ثالث و مدت گارانتی')
c1, c2 = st.columns(2, gap='large')
with c1:
    with st.container(border=True):
        ui.sub('Ratings of protection plans are polarised', '۹۰۷ نظر برای ۴۲۹ طرح')
        fp = ui.nbfig('part2/cell126_0.json')['data']
        fig = go.Figure()
        for tr, col in zip(fp, [C['violet'], C['amber'], C['slate']]):
            fig.add_bar(x=[f'{v}★' for v in tr['x']], y=tr['y'], name=tr['name'], marker_color=col, marker_cornerradius=5,
                        hovertemplate=tr['name'] + ' · %{x}: %{y:.1%}<extra></extra>')
        fig.update_layout(barmode='group', legend=dict(orientation='h', y=1.14, x=1, xanchor='right'))
        fig.update_yaxes(tickformat='.0%')
        ui.show(fig, 320)
        sellers = data.csv('part2/warranty_plan_sellers.csv').dropna().sort_values('size', ascending=False)
        sellers = sellers[sellers['size'] >= 10]
        ui.hbar_race([(f"{r['brand']} ({int(r['size'])})", float(r['mean']), C['violet'] if r['mean'] > 3 else C['red'])
                      for _, r in sellers.iterrows()], height=200, key='w_sellers', fmt='{c}★')
with c2:
    with st.container(border=True):
        ui.sub('Longer warranty mentioned → higher rating', 'میانگین امتیاز بر اساس مدت گارانتی که در متن نظر آمده')
        wl = data.csv('part2/warranty_by_length.csv')
        ended = W[W['ended'] == True]['overall']
        x = list(wl['length']) + ['warranty had ended']
        y = list(wl['mean']) + [ended.mean()]
        err = list(wl['ci']) + [1.96 * ended.std() / np.sqrt(len(ended))]
        n = list(wl['size']) + [len(ended)]
        cols = [ui.rgba(C['amber'], .45 + .1 * i) for i in range(len(wl))] + [C['red']]
        fig = go.Figure(go.Bar(x=x, y=y, error_y=dict(type='data', array=err, color=C['text2'], thickness=1.2), marker_color=cols,
                               marker_cornerradius=7, customdata=n, text=[f'{v:.2f}' for v in y], textposition='inside',
                               hovertemplate='%{x}<br>mean %{y:.2f}★ · %{customdata} reviews<extra></extra>'))
        fig.update_traces(textfont=dict(color='#060912', size=13))
        fig.update_yaxes(range=[0, 5], title='mean rating')
        ui.show(fig, 330)
        ui.note('Spearman مدت و امتیاز ۰.۲۶. ولی مدتی که در <b>عنوان محصول</b> آمده با امتیاز محصول رابطه‌ای ندارد (Spearman ۰.۰۳، p = ۰.۵۳).')
ui.callout('امتیاز طرح‌ها دوقطبی است: ۳۶٪ یک ستاره و ۴۰٪ پنج ستاره. SmartGuard با ۲.۵۱ به‌وضوح پایین‌تر از SquareTrade با ۳.۲۵ است. '
           '۹۵ نظری که می‌گویند <b>هنوز از طرح استفاده نکرده‌اند</b> میانگین ۴.۲۱ دارند و بقیه ۲.۹۹؛ یعنی بخشی از امتیاز بالا رضایت از خرید است، نه از خدمات. '
           'گارانتی کوتاه یا تمام‌شده وقتی ذکر می‌شود که به کار نیامده (۲.۴۹ و ۲.۳۳).', 'insight')
fw = ui.nbfig('part2/cell129_0.json')['data']
with st.container(border=True):
    ui.sub('What unhappy and happy plan reviews talk about', 'سهم نظرهایی که هر کلمه را دارند · stop wordها اینجا حذف شدند چون دنبال موضوع‌ایم')
    fig = go.Figure()
    fig.add_bar(y=fw[0]['y'], x=fw[0]['x'], orientation='h', name='1–2 stars', marker_color=C['red'], marker_cornerradius=4,
                hovertemplate='%{y}: %{x:.0%} of 1–2★<extra></extra>')
    fig.add_bar(y=fw[1]['y'], x=fw[1]['x'], orientation='h', name='4–5 stars', marker_color=C['green'], marker_cornerradius=4,
                customdata=[-v for v in fw[1]['x']], hovertemplate='%{y}: %{customdata:.0%} of 4–5★<extra></extra>')
    fig.update_layout(barmode='overlay', legend=dict(orientation='h', y=1.1, x=1, xanchor='right'))
    fig.update_xaxes(tickvals=[-.2, -.1, 0, .1, .2], ticktext=['20%', '10%', '0', '10%', '20%'])
    ui.show(fig, 420)
ui.code('part2', [125, 126, 127, 129, 131, 135, 136, 137, 139, 141, 142])

# ================================================================= experience
ui.section('09', 'Beyond Stars: the Warranty Experience', 'امتیاز ستاره‌ای درباره‌ی کل محصول است؛ خود تجربه‌ی گارانتی را سنجیدیم')
ui.take('از هر نظر جمله‌هایی که کلمات فهرست را دارند به‌همراه جمله‌ی بعدشان جدا شد (نتیجه‌ی ماجرا معمولاً جمله‌ی بعد است). ۴۰۰ نمونه‌ی تصادفی <b>بدون دیدن امتیاز</b> '
        'برچسب خوردند: positive (گارانتی استفاده شد و نتیجه خوب بود)، negative (لازم بود و کمکی نکرد) و none (تجربه‌ای در کار نیست).')
c1, c2 = st.columns([1.35, 1], gap='large')
with c1:
    with st.container(border=True):
        ui.sub('Stars → real experience', '۴۰۰ نمونه‌ی برچسب‌خورده · پهنای هر جریان = تعداد نظر')
        cross = {'negative': [86, 25, 16, 8, 7], 'none': [25, 15, 24, 27, 106], 'positive': [7, 3, 5, 15, 31]}
        st_col = {'negative': C['red'], 'none': C['slate'], 'positive': C['green']}
        nodes = [{'name': f'{r}★', 'itemStyle': {'color': RATING[r]}} for r in range(1, 6)] + \
                [{'name': k, 'itemStyle': {'color': v}} for k, v in st_col.items()]
        links = [{'source': f'{r}★', 'target': k, 'value': cross[k][r - 1], 'lineStyle': {'color': RATING[r], 'opacity': .32}}
                 for k in cross for r in range(1, 6)]
        ui.ec({'tooltip': {**ui.TOOLTIP, 'trigger': 'item'},
               'series': [{'type': 'sankey', 'left': 40, 'right': 90, 'top': 10, 'bottom': 10, 'nodeWidth': 16, 'nodeGap': 12, 'layoutIterations': 0,
                           'draggable': False, 'emphasis': {'focus': 'adjacency'},
                           'label': {'color': C['text'], 'fontFamily': ui.FONT, 'fontWeight': 800, 'fontSize': 13},
                           'lineStyle': {'curveness': 0.5}, 'data': nodes, 'links': links}]}, height=380, key='w_sankey')
with c2:
    with st.container(border=True):
        ui.sub('Share of good experiences', 'روی val، با بازه‌ی ۹۵٪ ۰.۲۲ تا ۰.۴۸')
        g1, g2 = st.columns(2)
        with g1:
            ui.gauge(0.34, 'true (labels)', lo=0, hi=1, color=C['green'], decimals=2, height=210, key='w_true')
        with g2:
            ui.gauge(0.59, 'star proxy', lo=0, hi=1, color=C['slate'], decimals=2, height=210, key='w_proxy')
    ui.callout('در نمونه‌ها نیمی از نظرهای گارانتی (۴۹٪) <b>هیچ تجربه‌ای</b> ندارند و بیشترشان ۵ ستاره‌اند. امتیاز ستاره‌ای فقط در ۴۵٪ نمونه‌ها با تجربه‌ی واقعی جور است '
               'و سهم تجربه‌های خوب را تقریباً دو برابر نشان می‌دهد.', 'warn')

METHODS = pd.DataFrame([('hand rules', .62, .61), ('random forest', .66, .63), ('logistic regression', .68, .66), ('gradient boosting', .62, .64),
                        ('SVM (rbf)', .61, .64), ('tree depth 2', .63, .66), ('tree depth 4', .64, .62), ('naive Bayes', .57, .62),
                        ('SetFit (MiniLM)', .50, .62)], columns=['method', 'cv', 'val'])
c1, c2 = st.columns([1.25, 1], gap='large')
with c1:
    with st.container(border=True):
        ui.sub('Experience classifier', 'macro-F1 · انتخاب فقط بر اساس cross-validation روی ۲۰۰ نمونه‌ی train')
        mm = METHODS.sort_values('cv')
        fig = go.Figure()
        fig.add_bar(y=mm['method'], x=mm['cv'], orientation='h', name='cv (train)', marker_color=C['amber'], marker_cornerradius=4,
                    text=[f'{v:.2f}' for v in mm['cv']], textposition='inside')
        fig.add_bar(y=mm['method'], x=mm['val'], orientation='h', name='val (held out)', marker_color=C['sky'], marker_cornerradius=4,
                    text=[f'{v:.2f}' for v in mm['val']], textposition='inside')
        fig.update_layout(barmode='group', legend=dict(orientation='h', y=1.1, x=1, xanchor='right'))
        fig.update_traces(textfont=dict(color='#060912', size=12), insidetextanchor='end')
        fig.update_xaxes(range=[0.4, 0.72], title='macro-F1')
        ui.show(fig, 420)
with c2:
    with st.container(border=True):
        ui.sub('All 18,912 reviews, classified', 'random forest روی امتیاز + عبارت‌های نتیجه‌ی خوب و بد')
        ui.donut([('negative', 45.7, C['red']), ('no experience', 30.5, C['slate']), ('positive', 23.8, C['green'])],
                 height=280, key='w_stance', center='0.34', center_sub='satisfaction', fmt='{b}\n{c}%')
        ui.note('ورودی‌ها: امتیاز ستاره‌ای، تعداد عبارت‌های نتیجه‌ی خوب (replaced، sent me a new، refund، ...) و بد (refused، no response، out of warranty، ...). '
                'random forest روی val درستی ۰.۶۵ دارد در برابر ۰.۴۶ برای امتیاز ستاره‌ای. SetFit با ۲۰۰ نمونه (۳۱ positive) کم آورد.')

ui.sub('Brands: star rating vs warranty experience', 'روی حباب یک برند کلیک کن تا نمونه‌ی نظرهایش را ببینی')
eb = data.csv('part2/warranty_experience_by_brand.csv')
if 'w_brand' not in st.session_state:
    st.session_state['w_brand'] = 'asus' if 'asus' in set(eb['brand']) else eb['brand'].iloc[0]


def pick_brand():
    pts = st.session_state['w_brand_chart']['selection']['points']
    if pts and pts[0].get('customdata'):
        st.session_state['w_brand'] = pts[0]['customdata'][0]


c1, c2 = st.columns([1.6, 1], gap='large')
with c2:
    brand_list = eb.sort_values('n', ascending=False)['brand'].tolist()
    chosen = st.selectbox('brand', brand_list, key='w_brand', label_visibility='collapsed')
    row = eb[eb['brand'] == chosen].iloc[0]
    ui.kpis([(ui.pct0(row['satisfaction']), 'تجربه‌ی خوب', f"بازه‌ی ۹۵٪: {ui.pct0(row['low'])} – {ui.pct0(row['high'])}", C['green']),
             (f"{row['mean_rating']:.2f}", 'میانگین ستاره', f"{int(row['n'])} نظر با تجربه", C['amber'])], cols=2)
    sample = W[(W['brand'] == chosen) & W['snippet'].str.len().between(90, 340)]
    for stance, color, label in [('positive', C['green'], 'تجربه‌ی خوب'), ('negative', C['red'], 'تجربه‌ی بد')]:
        s = sample[sample['stance'] == stance]
        if len(s):
            q = s.sample(1, random_state=4).iloc[0]
            ui.quote(q['snippet'][:300], rating=q['overall'], meta=label, color=color)
with c1:
    eb = eb.assign(sel=eb['brand'] == chosen)
    fig = go.Figure()
    for sel, col in [(False, C['sky']), (True, C['amber'])]:
        p = eb[eb['sel'] == sel]
        fig.add_scatter(x=p['mean_rating'], y=p['satisfaction'], mode='markers+text' if sel else 'markers',
                        text=p['brand'] if sel else None, textposition='top center', textfont=dict(color=C['amber'], size=14),
                        error_y=dict(type='data', symmetric=False, array=p['high'] - p['satisfaction'], arrayminus=p['satisfaction'] - p['low'],
                                     color='rgba(163,172,198,.22)', thickness=1),
                        marker=dict(size=np.sqrt(p['n']) * 1.7, color=col, opacity=.85, line=dict(color=C['bg'], width=1.5)),
                        customdata=np.stack([p['brand'], p['n']], axis=1), showlegend=False,
                        hovertemplate='<b>%{customdata[0]}</b><br>stars %{x:.2f}<br>good experience %{y:.0%}<br>%{customdata[1]} reviews<extra></extra>')
    fit = np.polyfit(eb['mean_rating'], eb['satisfaction'], 1)
    xs = np.array([eb['mean_rating'].min(), eb['mean_rating'].max()])
    fig.add_scatter(x=xs, y=fit[0] * xs + fit[1], mode='lines', line=dict(color=C['muted'], dash='dot'), hoverinfo='skip', showlegend=False)
    fig.update_xaxes(title='mean star rating of warranty reviews')
    fig.update_yaxes(title='good experiences', tickformat='.0%')
    fig.update_layout(clickmode='event+select')
    ui.show(fig, 500, key='w_brand_chart', on_select=pick_brand)
ui.callout('رتبه‌ی برندها با ستاره و با تجربه هم‌جهت است (Spearman ۰.۸۶) ولی جابه‌جایی‌ها مهم‌اند: برندهای بالای خط روند (Plantronics، Linksys) تجربه‌ی گارانتی '
           'بهتری از آنچه ستاره‌شان نشان می‌دهد دارند و Acer و Nikon پایین خط‌اند. بین فروشنده‌های طرح، SquareTrade ۴۲٪ تجربه‌ی خوب دارد و SmartGuard فقط ۱۹٪.', 'insight')
ui.code('part2', [145, 146, 147, 149, 151, 153, 155, 156, 159, 160, 161, 163, 164, 165, 166])
ui.code('part2_setfit', [4, 5, 6, 7], 'کد SetFit — part2_setfit.ipynb')
ui.footer()
