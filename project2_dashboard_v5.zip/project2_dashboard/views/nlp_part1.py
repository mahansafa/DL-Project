import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from lib import data, ui
from lib.ui import C, RATING, SENT, fa

ui.set_accent(C['gold'], C['sky'])
ratings = data.csv('part1/eda_ratings.csv').set_index('rating')
total = int(ratings['count'].sum())
GROUP = {'positive': 611447, 'neutral': 80444, 'negative': 138499}

ui.hero('NLP · Main task · Part 1', 'Exploratory Data Analysis',
        f'آشنایی با {fa("830,390")} نظر آمازون درباره‌ی کالاهای الکترونیکی پیش از مدل‌سازی. نظرهای تکراری (همان نویسنده، همان محصول، همان متن) '
        f'حذف شدند و بعد به شش سؤال صورت پروژه جواب داده شد. زیر هر سؤال کد همان بخش از نوت‌بوک هم آمده است.',
        chips=['part1_eda.ipynb', 'train_data.csv · <b>838,944</b> rows', 'duplicates removed · <b>8,554</b>',
               'title_brand.csv · <b>756,077</b> products'])

ui.kpis([
    ('830,390', 'نظر بعد از حذف تکراری‌ها', 'از ۸۳۸٬۹۴۴ سطر خام', C['gold'], '💬'),
    ('55%', 'سهم امتیاز ۵', 'بزرگ‌ترین کلاس', RATING[5], '★'),
    ('8.1×', 'نسبت بزرگ‌ترین به کوچک‌ترین کلاس', '۵ ستاره در برابر ۲ ستاره', C['orange'], '⚖'),
    ('1,314', 'کران بالای IQR طول متن', '۹۲٪ نظرها زیر این طول‌اند', C['sky'], '📏'),
], cols=4)
ui.code('part1', [6, 7], 'کد بارگذاری داده و حذف تکراری‌ها')

# ================================================================= Q1
ui.section('Q1', 'Rating Distribution', 'توزیع ستون overall — آیا داده متوازن است؟')
c1, c2 = st.columns([1.45, 1], gap='large')
with c1:
    with st.container(border=True):
        ui.sub('Five ratings', 'تعداد نظرها برای هر امتیاز')
        spec = {
            'grid': {'left': 10, 'right': 10, 'top': 30, 'bottom': 10, 'containLabel': True},
            'tooltip': {**ui.TOOLTIP, 'trigger': 'axis', 'axisPointer': {'type': 'shadow'}},
            'xAxis': {'type': 'category', 'data': [f'{r}★' for r in ratings.index],
                      'axisLabel': {'color': C['text2'], 'fontSize': 14, 'fontWeight': 800}, 'axisLine': {'lineStyle': {'color': C['line']}},
                      'axisTick': {'show': False}},
            'yAxis': {'type': 'value', 'splitLine': {'lineStyle': {'color': 'rgba(148,163,184,.08)'}}, 'axisLabel': {'color': C['muted']}},
            'series': [{'type': 'bar', 'barWidth': '58%', 'name': 'reviews',
                        'label': {'show': True, 'position': 'top', 'color': C['text'], 'fontWeight': 800},
                        'data': [{'value': int(ratings.loc[r, 'count']),
                                  'label': {'formatter': f"{int(ratings.loc[r, 'count']):,}\n{ui.nice(ratings.loc[r, 'percent'])}%"},
                                  'itemStyle': {'borderRadius': [10, 10, 4, 4], 'shadowColor': RATING[r], 'shadowBlur': 14,
                                                'color': {'type': 'linear', 'x': 0, 'y': 0, 'x2': 0, 'y2': 1,
                                                          'colorStops': [{'offset': 0, 'color': RATING[r]}, {'offset': 1, 'color': ui.rgba(RATING[r], .25)}]}}}
                                 for r in ratings.index]}],
        }
        ui.ec(spec, height=330, key='q1_bar')
with c2:
    with st.container(border=True):
        ui.sub('Three sentiment classes', '۴ و ۵ مثبت · ۳ خنثی · ۱ و ۲ منفی')
        ui.donut([('positive', GROUP['positive'], SENT['positive']), ('neutral', GROUP['neutral'], SENT['neutral']),
                  ('negative', GROUP['negative'], SENT['negative'])], height=330, key='q1_donut',
                 center='74%', center_sub='positive', fmt='{b}\n{d}%')
st.html(ui.band((ratings['count'] / total).to_dict(), height=54, grow=True))
ui.callout('داده <b>نامتوازن</b> است: امتیاز ۵ به‌تنهایی ۵۵٪ نظرهاست و کلاس مثبت ۷۴٪. مدلی که همیشه «۵» بگوید روی همین داده ۵۵٪ درست است، '
           'پس accuracy خام گمراه‌کننده است. پیشنهاد ما: در مدل‌سازی هر دو حالت (داده‌ی طبیعی با <code>class_weight</code> یا prior correction، و نمونه‌ی متوازن) '
           'روی validation مقایسه شوند. در بخش ۳ همین آزمایش انجام شد و نمونه‌ی متوازن برنده شد؛ بعداً معلوم شد test هم متوازن است.', 'insight')
ui.code('part1', [9, 10])

# ================================================================= Q2
ui.section('Q2', 'Word Clouds', 'ابر کلمات سه دسته‌ی احساس، بدون stop words')
ui.take('stop wordهای پیش‌فرض WordCloud به‌همراه کلمه‌های عمومی خرید و استفاده (amazon، product، bought، use و ...) حذف شدند تا ابر کلمات اطلاعات مفید نشان دهد. '
        'تگ‌های HTML هم پیش از شمردن کلمه‌ها پاک شدند.')
tabs = st.tabs(['🟢  Positive  (4–5★)', '⚪  Neutral  (3★)', '🔴  Negative  (1–2★)'])
for tab, name in zip(tabs, ['positive', 'neutral', 'negative']):
    with tab:
        with st.container(border=True):
            st.image(str(ui.DATA / f'img/wordcloud_{name}.png'), width='stretch')
            st.html(f'<p class="note" style="text-align:center !important">{fa(f"{GROUP[name]:,}")} نظر در این دسته · ۱۴۰ کلمه‌ی پرتکرار</p>')

words = data.csv('part1/eda_top_words.csv')
words['rate'] = words['count'] / words['sentiment'].map(GROUP) * 1000
pos = words[words['sentiment'] == 'positive'].set_index('word')['rate']
neg = words[words['sentiment'] == 'negative'].set_index('word')['rate']
neu = words[words['sentiment'] == 'neutral'].set_index('word')['rate']

COMMON = ['another', 'battery', 'better', 'cable', 'camera', 'card', 'case', 'computer', 'device', 'drive', 'fine', 'good', 'great', 'hard',
          'headphones', 'keyboard', 'laptop', 'little', 'made', 'phone', 'power', 'price', 'quality', 'screen', 'sound', 'unit', 'usb', 'video',
          'without', 'worked']
ONLY_POS = ['best', 'bit', 'bluetooth', 'easy', 'enough', 'far', 'fit', 'light', 'long', 'lot', 'love', 'music', 'nice', 'old', 'perfect',
            'pretty', 'recommend', 'small', 'speaker', 'speakers']
ONLY_NEG = ['bad', 'box', 'day', 'different', 'every', 'issue', 'money', 'months', 'never', 'problem', 'purchased', 'return', 'router',
            'support', 'times', 'tried', 'update', 'working', 'year', 'years']

c1, c2 = st.columns([1.25, 1], gap='large')
with c1:
    with st.container(border=True):
        ui.sub('Positive vs negative vocabulary', 'تکرار در هر ۱۰۰۰ نظر · نمودار پروانه‌ای')
        pick = st.segmented_control('words', ['shared', 'only positive', 'only negative'], default='shared',
                                    label_visibility='collapsed', key='q2_pick')
        chosen = {'shared': COMMON, 'only positive': ONLY_POS, 'only negative': ONLY_NEG}[pick or 'shared']
        frame = pd.DataFrame({'pos': pos.reindex(chosen), 'neg': neg.reindex(chosen)}).fillna(0)
        frame = frame.assign(key=frame[['pos', 'neg']].max(axis=1)).sort_values('key').tail(16)
        fig = go.Figure()
        fig.add_bar(y=frame.index, x=-frame['neg'], orientation='h', name='negative', marker_color=SENT['negative'],
                    marker_cornerradius=5, customdata=frame['neg'], hovertemplate='%{y} · negative: %{customdata:.0f} / 1000<extra></extra>')
        fig.add_bar(y=frame.index, x=frame['pos'], orientation='h', name='positive', marker_color=SENT['positive'],
                    marker_cornerradius=5, customdata=frame['pos'], hovertemplate='%{y} · positive: %{customdata:.0f} / 1000<extra></extra>')
        lim = float(frame[['pos', 'neg']].max().max()) * 1.1
        ticks = np.linspace(-lim, lim, 7)
        fig.update_layout(barmode='relative', bargap=0.22, legend=dict(orientation='h', y=1.08, x=1, xanchor='right'))
        fig.update_xaxes(tickvals=ticks, ticktext=[f'{abs(t):.0f}' for t in ticks], title='per 1,000 reviews of the class', range=[-lim, lim])
        fig.add_vline(x=0, line_color=C['line2'])
        ui.show(fig, 470)
with c2:
    with st.container(border=True):
        ui.sub('Top-50 overlap', '۵۰ کلمه‌ی پرتکرار مثبت و منفی')
        ui.donut([('shared', 30, C['gold']), ('only positive', 20, SENT['positive']), ('only negative', 20, SENT['negative'])],
                 height=250, key='q2_overlap', center='30 / 50', center_sub='shared words', fmt='{b}\n{c}')

        def pills(ws, color):
            return ''.join(f'<span class="chip c" style="--c:{color}">{w}</span>' for w in ws)
        st.html(f'<div class="chips" style="direction:ltr; justify-content:flex-start">{pills(ONLY_POS, SENT["positive"])}</div>'
                f'<div class="chips" style="direction:ltr; justify-content:flex-start">{pills(ONLY_NEG, SENT["negative"])}</div>')
ui.callout('از ۵۰ کلمه‌ی پرتکرار نظرهای مثبت و منفی، <b>۳۰ کلمه مشترک</b>‌اند و بیشترشان اسم موضوع یا قطعه‌اند (battery، camera، sound، screen، quality). '
           'یعنی هر دو گروه درباره‌ی چیزهای یکسانی حرف می‌زنند و تفاوت در <b>قضاوت</b> است، نه موضوع: love، easy، perfect و recommend فقط در مثبت‌ها، '
           'و return، problem، issue، never، money و support فقط در منفی‌ها. حتی good و great در نظرهای منفی هم پرتکرارند (مثل «not good»)؛ '
           'پس حذف not و no به‌عنوان stop word در مدل‌سازی اشتباه است.', 'insight')

with st.container(border=True):
    ui.sub('Compare any word across the three classes', 'یک یا چند کلمه انتخاب کن')
    shared_all = sorted(set(pos.index) & set(neg.index) & set(neu.index))
    chosen = st.multiselect('words', shared_all, default=[w for w in ['great', 'good', 'easy', 'return', 'problem', 'fine'] if w in shared_all],
                            label_visibility='collapsed', key='q2_words')
    if chosen:
        fig = go.Figure()
        for s, series in [('negative', neg), ('neutral', neu), ('positive', pos)]:
            fig.add_bar(x=chosen, y=series.reindex(chosen), name=s, marker_color=SENT[s], marker_cornerradius=5,
                        hovertemplate=s + ' · %{x}: %{y:.0f} per 1000<extra></extra>')
        fig.update_layout(barmode='group', legend=dict(orientation='h', y=1.12, x=1, xanchor='right'))
        fig.update_yaxes(title='per 1,000 reviews')
        ui.show(fig, 330)
ui.code('part1', [13, 14, 15])

# ================================================================= Q3
ui.section('Q3', 'Most Helpful Reviewers', '۱۰ نظردهنده با بیشترین مجموع vote')
reviewers = data.csv('part1/eda_top_reviewers.csv')
c1, c2 = st.columns([1.5, 1], gap='large')
with c1:
    with st.container(border=True):
        palette = [C['gold']] + [C['sky']] * 2 + [C['violet']] * 7
        ui.hbar_race([(r['name'], int(r['total_votes']), palette[i]) for i, r in reviewers.iterrows()], height=400, key='q3_bar')
with c2:
    top = reviewers.iloc[0]
    ui.kpis([(f"{int(top['total_votes']):,}", f'مجموع رأی «مفید» برای {top["name"]}', 'نفر اول', C['gold'], '🏆'),
             (f"{int(reviewers['total_votes'].sum()):,}", 'مجموع رأی ۱۰ نفر اول', '', C['sky'], '👍')], cols=1)
    ui.callout('مقدار vote برای هر نظر جمع زده شد و گروه‌بندی بر اساس <b>reviewerID</b> انجام شد، نه اسم، چون اسم‌ها یکتا نیستند. '
               'vote به‌صورت رشته با کاما ذخیره شده بود («1,234») و نظرهای بدون رأی NaN بودند؛ هر دو قبل از جمع زدن درست شدند.', 'info')
ui.code('part1', [18])

# ================================================================= Q4
ui.section('Q4', 'Review Length', 'هیستوگرام تعداد کاراکتر reviewText — خام و فیلترشده')
c1, c2 = st.columns([1.6, 1], gap='large')
with c1:
    with st.container(border=True):
        mode = st.segmented_control('mode', ['raw', 'filtered (IQR)'], default='filtered (IQR)', label_visibility='collapsed', key='q4_mode')
        if mode == 'raw':
            limit = 33000
            counts, edges = data.length_hist(limit, 500)
            color = C['violet']
        else:
            limit = 1314
            counts, edges = data.length_hist(limit, 26)
            color = C['sky']
        centers = (edges[:-1] + edges[1:]) / 2
        fig = go.Figure(go.Bar(x=centers, y=counts, width=(edges[1] - edges[0]) * 0.9, marker_color=color, marker_cornerradius=3,
                               marker_line_width=0, hovertemplate='%{x:.0f} characters: %{y:,} reviews<extra></extra>'))
        if mode == 'raw':
            fig.update_yaxes(type='log', title='reviews (log scale)')
            fig.add_vline(x=1314.5, line_dash='dot', line_color=C['gold'])
            fig.add_annotation(x=1314.5, y=1, yref='paper', text='IQR upper bound 1314', showarrow=False, xanchor='left',
                               font=dict(color=C['gold']))
        else:
            fig.update_yaxes(title='reviews')
            for x, t in [(277, 'Q1 277'), (406, 'median 406'), (692, 'Q3 692')]:
                fig.add_vline(x=x, line_dash='dot', line_color=C['gold'] if t.startswith('median') else C['muted'])
                fig.add_annotation(x=x, y=1, yref='paper', text=t, showarrow=False, xanchor='left', font=dict(color=C['text2'], size=11))
        fig.update_xaxes(title='characters (HTML removed)')
        ui.show(fig, 360)
with c2:
    with st.container(border=True):
        ui.sub('Kept inside the IQR range', 'سهم نظرهایی که کامل در بازه‌ی پیشنهادی جا می‌شوند')
        ui.gauge(0.915, 'kept ≤ 1314 characters', lo=0, hi=1, color=C['sky'], fmt='{value}', decimals=3, height=250, key='q4_gauge')
        ui.kpis([('70,326', 'نظر پرت (بلندتر از ۱۳۱۴)', '', C['orange']), ('5', 'نظر خالی بعد از حذف HTML', '', C['red'])], cols=2)

stats = data.length_stats()
with st.container(border=True):
    ui.sub('Length by rating', 'باکس‌پلات طول نظر برای هر امتیاز (بدون نقاط پرت)')
    fig = go.Figure()
    for r in range(1, 6):
        s = stats[r]
        fig.add_trace(go.Box(name=f'{r}★', x=[f'{r}★'], q1=[s['q1']], median=[s['med']], q3=[s['q3']], lowerfence=[s['lo']], upperfence=[s['hi']],
                             mean=[s['mean']], marker_color=RATING[r], fillcolor=ui.rgba(RATING[r], .25), line=dict(width=2),
                             boxmean=True, showlegend=False, hoverinfo='y+name'))
    fig.update_yaxes(title='characters')
    ui.show(fig, 330)
ui.callout('کوتاه‌ترین متن خام دقیقاً ۲۰۰ کاراکتر است، یعنی داده از قبل فیلتر شده. بعد از حذف HTML، ۱٬۳۴۲ نظر کوتاه‌تر از ۲۰۰ کاراکترند و ۵ نظر خالی می‌شوند. '
           'کران پایین IQR منفی است، پس پرت‌ها فقط نظرهای خیلی بلندند (۹٪). <b>پیشنهاد ما برای مدل‌سازی: ۱ تا ۱۳۱۴ کاراکتر</b>؛ نظرهای خالی کنار می‌روند و '
           'نظرهای بلندتر <b>کوتاه</b> می‌شوند نه حذف، چون اطلاعاتشان به کار می‌آید. TF-IDF محدودیت طول ندارد؛ برای ترنسفورمرها همین ایده به ۵۱۲ token رسید '
           'که ۹۷٪ نظرها را کامل جا می‌دهد. نظرهای ۵ ستاره کوتاه‌ترین‌اند: کسی که راضی است کمتر توضیح می‌دهد.', 'insight')
ui.code('part1', [21, 22, 23])

# ================================================================= Q5
ui.section('Q5', 'Products With the Most 5-Star Reviews', '۱۰ محصول برتر، با برند و عنوان')
products = data.csv('part1/eda_top_products.csv')
c1, c2 = st.columns([1.7, 1], gap='large')
with c1:
    st.dataframe(products[['brand', 'title', 'five_star_reviews']].rename(columns={'five_star_reviews': '5★ reviews'}),
                 hide_index=True, width='stretch', height=35 * 11 + 3,
                 column_config={'brand': st.column_config.TextColumn('brand', width='small'),
                                'title': st.column_config.TextColumn('title', width='large'),
                                '5★ reviews': st.column_config.ProgressColumn('5★ reviews', format='%d', min_value=0,
                                                                              max_value=int(products['five_star_reviews'].max()), color='#34d399')})
with c2:
    with st.container(border=True):
        ui.sub('Share of the top 10', 'سهم هر برند از نظرهای ۵ ستاره‌ی این ده محصول')
        by_brand = products.groupby('brand')['five_star_reviews'].sum().sort_values(ascending=False)
        colors = [C['green'], C['teal'], C['sky'], C['violet'], C['gold'], C['orange'], C['pink'], C['rose'], C['slate']]
        ui.donut([(b.split()[0].strip(','), int(v), colors[i % len(colors)]) for i, (b, v) in enumerate(by_brand.items())], height=330,
                 key='q5_donut', rose=True, radius=('14%', '60%'), fmt='{b}')
ui.callout('بلندگوی OontZ Angle 3 (برند Cambridge Soundworks) با ۱٬۱۶۳ نظر ۵ ستاره با فاصله‌ی زیاد اول است. قبل از حذف نظرهای تکراری دو محصول دیگر '
           '(StarTech USB2SATAIDE و VideoSecu ML531BE) هم در این فهرست بودند؛ تقریباً همه‌ی نظرهایشان دو بار در داده آمده بود.', 'warn')
ui.code('part1', [26])

# ================================================================= Q6
ui.section('Q6', 'Mean Rating of the 10 Most Reviewed Brands', 'مرتب‌شده بر اساس میانگین امتیاز')
brands = data.csv('part1/eda_top_brands.csv').sort_values('mean_rating', ascending=False)
c1, c2 = st.columns([1, 1.35], gap='large')
with c1:
    st.dataframe(brands, hide_index=True, width='stretch', height=35 * 11 + 3,
                 column_config={'brand': st.column_config.TextColumn('brand'),
                                'reviews': st.column_config.NumberColumn('reviews', format='%d'),
                                'mean_rating': st.column_config.ProgressColumn('mean rating', format='%.2f ★', min_value=3.5, max_value=4.5,
                                                                               color='#f5b53f')})
with c2:
    with st.container(border=True):
        b = brands.sort_values('mean_rating')
        fig = go.Figure()
        for _, r in b.iterrows():
            fig.add_shape(type='line', x0=3.7, x1=r['mean_rating'], y0=r['brand'], y1=r['brand'], line=dict(color=C['line2'], width=3),
                          layer='below')
        fig.add_scatter(x=b['mean_rating'], y=b['brand'], mode='markers+text', text=[f'{v:.2f}' for v in b['mean_rating']],
                        textposition='middle right', textfont=dict(color=C['text'], size=12),
                        marker=dict(size=np.sqrt(b['reviews']) / 3.2, color=b['mean_rating'], colorscale=[[0, C['orange']], [1, C['green']]],
                                    line=dict(color=C['bg'], width=2)),
                        customdata=b['reviews'], hovertemplate='%{y}: %{x:.2f}★ from %{customdata:,} reviews<extra></extra>', showlegend=False)
        fig.update_xaxes(range=[3.7, 4.38], title='mean rating (bubble size = reviews)')
        ui.show(fig, 360)
ui.callout('Anker با میانگین ۴.۲۴ اول و AmazonBasics با ۴.۲۰ دوم است؛ NETGEAR با ۳.۸۱ کمترین میانگین را بین این ده برند دارد. '
           'فاصله‌ی بیشترین و کمترین میانگین کمتر از نیم ستاره است. نظرهایی که برند محصولشان معلوم نیست حساب نشدند.', 'insight')
ui.code('part1', [29])
ui.footer()
