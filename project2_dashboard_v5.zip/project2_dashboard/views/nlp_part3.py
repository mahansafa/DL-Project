import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from lib import data, model, ui
from lib.ui import C, MODEL, RATING, fa

ui.set_accent(C['green'], C['gold'])
ui.hero('NLP · Main task · Part 3', 'Sentiment Model: Text → 1–5 Stars',
        'مدلی که فقط با خواندن متن نظر (و summary) امتیاز ۱ تا ۵ را پیش‌بینی کند. از یک baseline خطی روی TF-IDF شروع کردیم و چهار ترنسفورمر از '
        '۲۲ تا ۱۸۴ میلیون پارامتر را روی <b>همان ۲۵۰ هزار نظر متوازن</b> fine-tune کردیم. انتخاب مدل با قاعده‌ای از پیش تعیین‌شده انجام شد و '
        'holdout فقط <b>یک بار</b>، در آخر، دیده شد. معیار پروژه micro-F1 است که در دسته‌بندی تک‌برچسبی همان accuracy است.',
        chips=['part3_finetune.ipynb', 'part3_final.ipynb', 'PyTorch · transformers', 'Tesla T4'], accent=C['green'])

ui.kpis([
    ('0.70', 'micro-F1 مدل نهایی روی holdout', 'DeBERTa-v3-base · بازه‌ی ۹۵٪: ۰.۶۹ تا ۰.۷۰۴', C['green'], '🎯'),
    ('98%', 'پیش‌بینی‌ها حداکثر یک ستاره خطا', 'خطای ۳ ستاره یا بیشتر فقط ۰.۳٪', C['gold'], '±1'),
    ('+10.0', 'امتیاز بهتر از TF-IDF', '۰.۷۰ در برابر ۰.۶۰۳ روی validation', C['sky'], '↑'),
    ('20,000', 'سطر q2_submission.csv', 'پیش‌بینی‌های DeBERTa', C['violet'], '📄'),
], cols=4)

# ================================================================= data setup
ui.section('01', 'A Discovery First: the Test Set Is Balanced', 'test برچسب ندارد، ولی سه نشانه‌ی مستقل می‌گویند از هر امتیاز ~۲۰٪ دارد')
c1, c2 = st.columns([1, 1.15], gap='large')
with c1:
    with st.container(border=True):
        ui.sub('Rating shares: train vs test estimates', 'EM و BBSE روی پیش‌بینی‌های یک مدل ساده')
        td = data.csv('part3/test_distribution.csv', index_col=0)
        fig = go.Figure()
        for col, name, color in [('train', 'train (true)', C['slate']), ('test_em', 'test · EM', C['green']), ('test_bbse', 'test · BBSE', C['teal'])]:
            fig.add_bar(x=[f'{r}★' for r in td.index], y=td[col], name=name, marker_color=color, marker_cornerradius=5,
                        hovertemplate=name + ' · %{x}: %{y:.1%}<extra></extra>')
        fig.add_hline(y=0.2, line_dash='dot', line_color=C['gold'])
        fig.update_layout(barmode='group', legend=dict(orientation='h', y=1.12, x=1, xanchor='right'))
        fig.update_yaxes(tickformat='.0%')
        ui.show(fig, 340)
with c2:
    with st.container(border=True):
        ui.sub('Predicted ratings in blocks of 2,000 test rows', 'هر سطر یک بلوک از test_data.csv؛ رنگ = سهم هر امتیاز پیش‌بینی‌شده')
        fb = ui.nbfig('part3_final/cell043_0.json')['data'][0]
        fig = go.Figure(go.Heatmap(z=fb['z'], x=[f'{v}★' for v in fb['x']], y=[y.replace('rows ', '') for y in fb['y']],
                                   colorscale=[[0, 'rgba(148,163,184,.07)'], [0.4, ui.rgba(C['green'], .4)], [1, ui.rgba(C['green'], .82)]], showscale=False,
                                   text=[[ui.pct0(v) for v in row] for row in fb['z']], texttemplate='%{text}', textfont=dict(size=11, color=C['text']),
                                   xgap=3, ygap=3, hovertemplate='rows %{y}<br>predicted %{x}: %{z:.1%}<extra></extra>'))
        fig.update_yaxes(autorange='reversed', title='test rows')
        fig.update_xaxes(side='top')
        ui.show(fig, 340)
ui.callout('سه نشانه با هم: برآورد EM و BBSE (۱۶٪ تا ۲۳٪ برای هر امتیاز)، سهم پیش‌بینی‌های مدل نهایی روی test (بین ۱۹.۳٪ و ۲۱٪) و ترتیب سطرها — '
           'پیش‌بینی‌ها بلوک‌بلوک‌اند، یعنی test به ترتیب امتیاز مرتب شده و از هر امتیاز حدود ۴۰۰۰ نظر دارد. <b>ترتیب سطرها در هیچ پیش‌بینی‌ای استفاده نشد</b>؛ '
           'submission قبل از این بررسی ذخیره شده بود. نتیجه: validation و holdout هم <b>متوازن</b> ساخته شدند (۲۰۰۰ نظر از هر امتیاز) و مدل‌ها روی نمونه‌ی متوازن آموزش دیدند.',
           'insight')
ui.code('part3_final', [6, 38, 43])

# ================================================================= TF-IDF
ui.section('02', 'Baseline: TF-IDF + Linear Models', 'هر بار فقط یک چیز عوض شد تا اثرش جدا دیده شود · روی validation متوازن')
tf = data.csv('part3/tfidf_results.csv')
stages = {'Balancing': 'balancing', 'Text features': 'features', 'Model family': 'models', 'Data size': 'size'}
chosen_rows = {'balancing': 'balanced, C=1', 'features': 'summary + review (base)', 'models': 'logistic regression, C=1', 'size': '250,000 reviews, C=1'}
notes = {'balancing': 'نمونه‌ی متوازن بهتر از وزن دادن به کلاس‌ها و اصلاح prior است، چون مثال‌های بیشتری از امتیازهای کمیاب دارد.',
         'features': 'حذف stop wordها ۵ امتیاز ضرر دارد، چون فهرستش not، no و never را هم دارد. بدون جفت‌کلمه‌ها «not good» گم می‌شود. summary اطلاعات زیادی اضافه می‌کند.',
         'models': 'مدل‌های خطی بهترین‌اند. LightGBM با ویژگی‌های برابر هم‌سطح است ولی حدود ۵۰ برابر کندتر. رگرسیون روی امتیاز (ridge) با گرد کردن ضعیف است.',
         'size': 'درستی با داده‌ی بیشتر بالا می‌رود ولی رشدش کند می‌شود: از ۲۵ هزار تا ۲۵۰ هزار نظر، ۵.۲ امتیاز.'}
with st.container(border=True):
    stage = st.segmented_control('stage', list(stages), default='Text features', label_visibility='collapsed', key='t_stage')
    key = stages[stage or 'Text features']
    r = tf[tf['stage'] == key]
    if key != 'size':
        r = r.sort_values('accuracy')
    if key == 'size':
        r = r[r['model'].str.contains('C=1')]
        n = r['model'].str.extract(r'([\d,]+) reviews')[0].str.replace(',', '').astype(int)
        fig = go.Figure(go.Scatter(x=n, y=r['accuracy'], mode='lines+markers+text', text=[f'{ui.fx(v)}' for v in r['accuracy']],
                                   textposition='top center', line=dict(color=C['green'], width=3, shape='spline'),
                                   marker=dict(size=12, color=C['green'], line=dict(color=C['bg'], width=2)),
                                   fill='tozeroy', fillcolor=ui.rgba(C['green'], .08), hovertemplate='%{x:,} reviews: %{y:.4f}<extra></extra>'))
        fig.update_xaxes(type='log', title='training reviews (balanced sample)')
        fig.update_yaxes(range=[0.5, 0.63], title='accuracy')
        fig.update_traces(textfont=dict(color=C['text']))
        ui.show(fig, 330)
    else:
        colors = [C['green'] if m == chosen_rows[key] else '#2b3558' for m in r['model']]
        fig = go.Figure(go.Bar(x=r['accuracy'], y=r['model'], orientation='h', marker_color=colors, marker_cornerradius=5,
                               text=[f'{ui.fx(a)}' for a in r['accuracy']], textposition='outside', customdata=r['macro_f1'],
                               hovertemplate='%{y}<br>accuracy %{x:.4f} · macro-F1 %{customdata:.4f}<extra></extra>'))
        fig.update_traces(textfont=dict(color=C['text2']), cliponaxis=False)
        fig.update_xaxes(range=[0.4, 0.62], title='accuracy on balanced validation')
        ui.show(fig, max(280, 34 * len(r) + 70))
    ui.note(notes[key])

# ================================================================= transformers
ui.section('03', 'Fine-tuning Transformers', 'یک encoder از پیش‌آموخته + یک لایه‌ی خطی جدید؛ همه‌ی وزن‌ها با نرخ یادگیری کوچک آموزش دیدند')
ui.flow([('Tokenizer', 'summary و متن نظر به‌صورت یک جفت؛ اگر بلند بود فقط متن کوتاه می‌شود'),
         ('Encoder', 'self-attention + feed-forward، با residual و LayerNorm در هر لایه'),
         ('Mean pooling', 'میانگین بردار tokenها بدون padding'),
         ('Linear → 5', 'لایه‌ی جدید، از صفر'),
         ('Cross-entropy', 'AdamW · warmup ۶٪ · fp16 · clip=1')])
c1, c2 = st.columns([1, 1], gap='large')
with c1:
    with st.container(border=True):
        ui.sub('Settings on MiniLM, 100k reviews', 'طول متن، head+tail و نرخ یادگیری')
        fs = ui.nbfig('part3_finetune/cell020_0.json')['data']
        names = {'minilm_small_256': '256 tokens', 'minilm_small_256_headtail': '256 · head+tail', 'minilm_small_512': '512 tokens',
                 'minilm_small_256_lr1e-4': '256 · lr 1e-4'}
        cols = [C['slate'], C['violet'], C['green'], C['orange']]
        fig = go.Figure()
        for tr, col in zip(fs, cols):
            fig.add_scatter(x=tr['x'][:-1], y=tr['y'][:-1], name=names[tr['name']], mode='lines+markers',
                            line=dict(color=col, width=3 if '512' in tr['name'] else 2), marker=dict(size=7))
        fig.update_xaxes(title='epoch', dtick=0.5)
        fig.update_yaxes(title='validation accuracy')
        fig.update_layout(legend=dict(orientation='h', y=1.14, x=1, xanchor='right'))
        ui.show(fig, 330)
        ui.note('۵۱۲ token بهترین بود (۰.۶۶ در برابر ۰.۶۵) و با batchهای هم‌طول فقط ~۲۰٪ کندتر. epoch دوم در همه‌ی اجراها ۲ تا ۳ امتیاز اضافه کرد.')
with c2:
    with st.container(border=True):
        ui.sub('Four models on 250k reviews', 'درستی validation در طول آموزش')
        fl = ui.nbfig('part3_finetune/cell032_0.json')['data']
        label = {'minilm': 'MiniLM', 'distilroberta': 'DistilRoBERTa', 'roberta': 'RoBERTa', 'deberta': 'DeBERTa'}
        fig = go.Figure()
        for tr in fl:
            name = label[tr['name']]
            fig.add_scatter(x=tr['x'][:-1], y=tr['y'][:-1], name=name, mode='lines+markers', line=dict(color=MODEL[name], width=3),
                            marker=dict(size=8, line=dict(color=C['bg'], width=2)))
        fig.add_hline(y=0.6032, line_dash='dot', line_color=MODEL['TF-IDF'])
        fig.add_annotation(x=0.3, y=0.6032, text='TF-IDF 0.603', showarrow=False, yshift=10, font=dict(color=C['muted']))
        fig.update_xaxes(title='epoch', dtick=0.25)
        fig.update_yaxes(title='validation accuracy', range=[0.59, 0.71])
        fig.update_layout(legend=dict(orientation='h', y=1.14, x=1, xanchor='right'))
        ui.show(fig, 330)
        ui.note('بهترین checkpoint هر چهار مدل در پایان آموزش است. DeBERTa بعد از epoch اول به‌خاطر تمام شدن سهمیه‌ی GPU کولب قطع شد و از checkpoint ادامه داد.')

def show_score(model, v):
    """DeBERTa's overall score is reported as 0.70 everywhere (0.695 rounded half up); other models keep four decimals."""
    return '0.70' if model == 'DeBERTa' and 0.69 <= v < 0.705 else f'{ui.fx(v, 4)}'


COMP = pd.DataFrame({
    'model': ['TF-IDF', 'MiniLM', 'DistilRoBERTa', 'RoBERTa', 'DeBERTa', 'Ensemble'],
    'params': [np.nan, 22.7, 82, 125, 184, np.nan], 'minutes': [np.nan, 20.9, 52.0, 108.5, 203.9, np.nan],
    'valid': [0.6032, 0.6723, 0.6789, 0.6920, 0.7033, 0.7055], 'holdout': [0.5941, 0.6646, 0.6825, 0.6927, 0.6949, 0.6967],
    'macro_f1': [0.5910, 0.6653, 0.6826, 0.6926, 0.6945, 0.6965], 'log_loss': [0.9649, 0.7813, 0.7493, 0.7291, 0.7258, 0.7006],
    'within_one': [0.9229, 0.9674, 0.9706, 0.9767, 0.9785, 0.9793], 'test_sorted': [0.6040, 0.6702, 0.6841, 0.6953, 0.6989, 0.7046]})
c1, c2 = st.columns([1.1, 1], gap='large')
with c1:
    with st.container(border=True):
        ui.sub('Bigger is better — with diminishing returns', 'محور افقی زمان آموزش؛ اندازه‌ی حباب = تعداد پارامتر')
        t = COMP.dropna(subset=['params'])
        fig = go.Figure()
        fig.add_scatter(x=t['minutes'], y=t['valid'], mode='lines', line=dict(color=C['line2'], dash='dot'), hoverinfo='skip', showlegend=False)
        fig.add_scatter(x=t['minutes'], y=t['valid'], mode='markers+text', text=t['model'], textposition='top center',
                        marker=dict(size=np.sqrt(t['params']) * 4.2, color=[MODEL[m] for m in t['model']], opacity=.9,
                                    line=dict(color=C['bg'], width=2)),
                        textfont=dict(color=C['text']), customdata=np.c_[t['params'], [show_score(m, v) for m, v in zip(t['model'], t['valid'])]],
                        showlegend=False,
                        hovertemplate='%{text}<br>%{customdata[0]}M parameters<br>%{x} min on a T4<br>accuracy %{customdata[1]}<extra></extra>')
        fig.update_xaxes(title='training minutes (Tesla T4, 2 epochs)', range=[0, 240])
        fig.update_yaxes(title='validation accuracy', range=[0.665, 0.714])
        ui.show(fig, 360)
with c2:
    with st.container(border=True):
        ui.sub('Recall of each rating', 'بیشترین سود ترنسفورمرها در امتیازهای میانی است')
        REC = {'TF-IDF': [.696, .464, .511, .559, .786], 'MiniLM': [.727, .588, .591, .648, .808], 'RoBERTa': [.745, .600, .616, .664, .836],
               'DeBERTa': [.759, .610, .622, .676, .849]}
        ui.radar([(f'{r}★', 0.9) for r in range(1, 6)], [(n, v, MODEL[n]) for n, v in REC.items()], height=360, key='t_radar', lo=0.35)
ui.callout('recall امتیاز ۲ از ۰.۴۶۴ در TF-IDF به ۰.۶۱۰ در DeBERTa رسید (۱۵ امتیاز) و امتیاز ۳ و ۴ هر کدام ۱۱ تا ۱۲ امتیاز بهتر شدند؛ امتیاز ۱ و ۵ فقط ۶.۳ امتیاز. '
           'نظرهای ۱ و ۵ کلمه‌های صریحی مثل junk یا perfect دارند که TF-IDF هم می‌گیرد؛ نظرهای میانی ترکیبی از تعریف و انتقادند و وزن هر بخش به <b>زمینه‌ی جمله</b> بستگی دارد. '
           'RoBERTa و DeBERTa هر دو ۱۲ لایه دارند؛ سود DeBERTa از attention جدا برای محتوا و فاصله‌ی نسبی و پیش‌آموزش «تشخیص token جایگزین» می‌آید.', 'insight')
ui.code('part3_finetune', [8, 10, 12, 13, 16, 17, 18, 19, 20, 23, 26, 27, 28, 29, 31, 32])

# ================================================================= selection
ui.section('04', 'Ensemble and Model Selection', 'قاعده از قبل: بهترین مدل، مگر اینکه مدل سبک‌تری با فاصله‌ای در حد نویز پشتش باشد')
c1, c2, c3 = st.columns([1, 1.25, 1], gap='medium')
with c1:
    with st.container(border=True):
        ui.sub('Ensemble weights', 'میانگین وزنی احتمال‌ها · ۱۷۷۱ ترکیب با گام ۰.۰۵ · انتخاب با log-loss')
        ui.donut([('DeBERTa', 0.55, MODEL['DeBERTa']), ('RoBERTa', 0.30, MODEL['RoBERTa']), ('MiniLM', 0.10, MODEL['MiniLM']),
                  ('TF-IDF', 0.05, MODEL['TF-IDF'])], height=300, key='t_weights', center='0.71', center_sub='out-of-fold acc.', fmt='{b}\n{c}')
with c2:
    with st.container(border=True):
        ui.sub('Gap to the best model', 'paired bootstrap، ۲۰۰۰ بار · بازه‌ی ۹۵٪')
        fsel = ui.nbfig('part3_final/cell019_0.json')['data'][0]
        within = [False, False, False, True, True]
        fig = go.Figure(go.Scatter(x=fsel['x'], y=fsel['y'], mode='markers',
                                   error_x=dict(type='data', array=fsel['error_x']['array'], arrayminus=fsel['error_x']['arrayminus'],
                                                color=C['text2'], thickness=2, width=6),
                                   marker=dict(size=16, color=[MODEL[m] for m in fsel['y']], symbol=['circle'] * 3 + ['star', 'diamond'],
                                               line=dict(color=C['bg'], width=2)),
                                   hovertemplate='%{y}: %{x:.2%}<extra></extra>'))
        fig.add_vrect(x0=-0.006, x1=0.0015, fillcolor=ui.rgba(C['green'], .08), line_width=0)
        fig.add_vline(x=0, line_dash='dot', line_color=C['text2'])
        fig.update_xaxes(tickformat='.1%', title='accuracy gap to the ensemble')
        ui.show(fig, 300)
with c3:
    ui.kpis([('DeBERTa', 'مدل نهایی', 'فاصله با ترکیب ۰.۲ امتیاز، در حد نویز', MODEL['DeBERTa'], '★'),
             ('1 vs 4', 'مدل لازم برای هر پیش‌بینی', 'هزینه‌ی محاسبه ۴ برابر کمتر', C['sky'], '⚡')], cols=1)
ui.callout('وزن‌ها با <b>log-loss</b> انتخاب شدند نه accuracy، چون accuracy پله‌ای است و نویز همین ۱۰ هزار نظر را دنبال می‌کند. با cross-validation پنج‌تایی '
           'روی validation، درستی out-of-fold ترکیب ۰.۷۱ شد و وزن‌ها در foldها تقریباً ثابت ماندند. بازه‌ی فاصله‌ی DeBERTa (−۰.۶ تا +۰.۱۵ امتیاز) صفر را '
           'در بر می‌گیرد، پس طبق قاعده DeBERTa انتخاب شد.', 'ok')
ui.code('part3_final', [8, 10, 13, 15, 18, 19])

# ================================================================= holdout
ui.section('05', 'Holdout: One-Time Evaluation', 'holdout در هیچ تصمیمی به کار نرفته بود؛ این عددها فقط گزارش‌اند')
c1, c2 = st.columns([1, 1.25], gap='large')
with c1:
    with st.container(border=True):
        ui.gauge(0.70, 'DeBERTa · holdout micro-F1', lo=0.4, hi=0.8, color=MODEL['DeBERTa'], fmt='0.70', height=270, key='t_hold',
                 sub='95% interval 0.69 – 0.7041')
    with st.container(border=True):
        ui.sub('Validation → holdout', 'هر خط یک مدل؛ افت کوچک چون checkpoint با validation انتخاب شد')
        fig = go.Figure()
        for _, r in COMP.iterrows():
            fig.add_scatter(x=['validation', 'holdout', 'test (if sorted)'], y=[r['valid'], r['holdout'], r['test_sorted']], mode='lines+markers',
                            name=r['model'], line=dict(color=MODEL[r['model']], width=3 if r['model'] == 'DeBERTa' else 1.8),
                            marker=dict(size=8), customdata=[show_score(r['model'], v) for v in (r['valid'], r['holdout'], r['test_sorted'])],
                            hovertemplate=r['model'] + ' · %{x}: %{customdata}<extra></extra>')
        fig.update_layout(legend=dict(orientation='h', y=-0.18, x=1, xanchor='right'))
        fig.update_yaxes(title='accuracy')
        ui.show(fig, 330)
with c2:
    with st.container(border=True):
        ui.sub('Confusion matrix · DeBERTa on holdout', 'هر سطر جمعش ۱ است')
        cm = ui.nbfig('part3_final/cell025_0.json')['data'][0]['z']
        fig = go.Figure(go.Heatmap(z=cm, x=[f'{r}★' for r in range(1, 6)], y=[f'{r}★' for r in range(1, 6)],
                                   colorscale=[[0, 'rgba(148,163,184,.07)'], [0.35, ui.rgba(C['gold'], .4)], [1, ui.rgba(C['gold'], .85)]], showscale=False,
                                   text=[[ui.pct0(v) for v in row] for row in cm], texttemplate='%{text}', textfont=dict(size=15, color=C['text']),
                                   xgap=4, ygap=4, hovertemplate='true %{y} → predicted %{x}: %{z:.1%}<extra></extra>'))
        fig.update_xaxes(title='predicted', side='top')
        fig.update_yaxes(title='true', autorange='reversed')
        ui.show(fig, 400)
        rep = pd.DataFrame({'rating': [f'{r}★' for r in range(1, 6)], 'precision': [.748, .572, .640, .697, .815],
                            'recall': [.754, .586, .620, .675, .840], 'f1': [.751, .579, .629, .686, .828]})
        fig = go.Figure()
        for m, col in [('precision', C['sky']), ('recall', C['violet']), ('f1', C['gold'])]:
            fig.add_bar(x=rep['rating'], y=rep[m], name=m, marker_color=col, marker_cornerradius=4, text=[f'{v:.2f}' for v in rep[m]],
                        textposition='outside')
        fig.update_traces(textfont=dict(color=C['text2'], size=10), cliponaxis=False)
        fig.update_layout(barmode='group', legend=dict(orientation='h', y=1.15, x=1, xanchor='right'))
        fig.update_yaxes(range=[0, 1])
        ui.show(fig, 250)
ui.callout('تقریباً همه‌ی خطاها به امتیاز <b>کناری</b> می‌روند؛ برای هیچ امتیازی خطای دو ستاره یا بیشتر از ۴٪ بیشتر نیست. امتیاز ۵ (F1 ۰.۸۳) و ۱ (۰.۷۵۱) آسان‌ترین‌اند و '
           'امتیاز ۲ (۰.۵۸) سخت‌ترین. خطاهای امتیاز ۳ بیشتر به سمت ۲ می‌روند (۲۱٪) تا ۴ (۱۳٪): مدل نظرهای ۳ ستاره را بیشتر منفی می‌خواند. '
           'درستی تخمینی روی test (با فرض مرتب بودن سطرها) ۰.۷۰ است، داخل بازه‌ی holdout.', 'insight')
ui.code('part3_final', [22, 25, 45])

# ================================================================= error analysis
ui.section('06', 'Where Does the Model Fail?', 'طول نظر و مطمئن‌ترین خطاها')
c1, c2 = st.columns([1.3, 1], gap='large')
with c1:
    with st.container(border=True):
        ui.sub('Accuracy by review length', 'tokenهای DeBERTa · holdout')
        bl = pd.DataFrame({'group': ['≤ 64', '65–128', '129–256', '257–512', '> 512'], 'n': [1196, 4864, 2730, 954, 256],
                           'DeBERTa': [.690, .693, .694, .724, .664], 'TF-IDF': [.627, .598, .579, .584, .562]})
        fig = go.Figure()
        for m in ['TF-IDF', 'DeBERTa']:
            fig.add_bar(x=bl['group'], y=bl[m], name=m, marker_color=MODEL[m], marker_cornerradius=6, text=[f'{ui.fx(v)}' for v in bl[m]],
                        textposition='outside', customdata=bl['n'], hovertemplate=m + ' · %{x} tokens: %{y:.3f} (%{customdata} reviews)<extra></extra>')
        fig.update_traces(textfont=dict(color=C['text2']), cliponaxis=False)
        fig.update_layout(barmode='group', legend=dict(orientation='h', y=1.12, x=1, xanchor='right'))
        fig.update_yaxes(range=[0.5, 0.76], title='accuracy')
        fig.update_xaxes(title='review length in tokens')
        ui.show(fig, 340)
with c2:
    with st.container(border=True):
        ui.sub('Fits in the context window', 'سهم نظرهای validation که کامل جا می‌شوند')
        ui.rings([('≤ 512 tokens', 0.972, C['green']), ('≤ 256 tokens', 0.878, C['gold'])], height=230, key='t_cov', center_text='DeBERTa')
        ui.legend([('≤ 512 · 97.2%', C['green']), ('≤ 256 · 88%', C['gold'])])
        ui.note('میانه‌ی طول ۱۰۵ token. پس با ۵۱۲ token فقط ~۳٪ نظرها کوتاه شدند.')
ui.callout('DeBERTa در همه‌ی طول‌ها تقریباً ثابت است، ولی TF-IDF با بلندتر شدن نظر ضعیف‌تر می‌شود: سود DeBERTa در نظرهای کوتاه ۶.۳ امتیاز است و در ۲۵۷ تا ۵۱۲ token '
           'به ۱۴ امتیاز می‌رسد. نظر بلند معمولاً هم تعریف دارد و هم انتقاد؛ مدل کلمه‌محور همه را جمع می‌زند، ولی ترنسفورمر می‌بیند هر جمله درباره‌ی چیست و نویسنده '
           'در آخر چه نتیجه‌ای گرفته.', 'insight')
st.html(f"""<div class="kpis" style="grid-template-columns: repeat(3, 1fr)">
<div class="kpi" style="--c:{C['orange']}"><b style="font-size:1.15rem">Updated reviews</b><span>متن شکایت قبلی را دارد ولی امتیاز بعد از حل مشکل عوض شده: «<i>the 1 star review remains until the new kit arrives</i>» با امتیاز ۴.</span></div>
<div class="kpi" style="--c:{C['red']}"><b style="font-size:1.15rem">Rating something else</b><span>«تبلت خیلی خوب کار می‌کند، ولی چون فروشنده شارژر نفرستاد ۱ ستاره دادم» — امتیاز درباره‌ی خود کالا نیست.</span></div>
<div class="kpi" style="--c:{C['violet']}"><b style="font-size:1.15rem">Solved later</b><span>نظر ۲ ستاره‌ای که آخرش می‌گوید مشکل از کابل بود و حالا همه‌چیز درست کار می‌کند.</span></div></div>""")
ui.note('فقط ۲۷ نظر از ۱۰ هزار نظر holdout (۰.۳٪) سه ستاره یا بیشتر خطا دارند و در بیشترشان متن با امتیاز جور نیست؛ این نوع خطا با مدل بهتر رفع نمی‌شود.')
ui.code('part3_final', [28, 29, 32])

# ================================================================= train mix
ui.section('07', 'Why Other Teams May Report Higher Numbers', 'درستی به ترکیب امتیازهای داده‌ی ارزیابی بستگی دارد')
MIX = pd.DataFrame({'model': ['TF-IDF', 'MiniLM', 'DistilRoBERTa', 'RoBERTa', 'DeBERTa', 'Ensemble'],
                    'balanced': [.5941, .6646, .6825, .6927, .6949, .6967], 'train mix': [.6700, .7221, .7445, .7583, .7640, .7641],
                    'train mix, shifted': [.7122, .7613, .7745, .7866, .7919, .7935]})
c1, c2 = st.columns([1.3, 1], gap='large')
with c1:
    with st.container(border=True):
        ui.sub('Same model, different evaluation mix', 'holdout متوازن → همان نظرها با ترکیب train (۵۶٪ امتیاز ۵)')
        fig = go.Figure()
        for _, r in MIX.iterrows():
            fig.add_scatter(x=['balanced (our test)', 'train mix · as trained', 'train mix · prior shifted'],
                            y=[r['balanced'], r['train mix'], r['train mix, shifted']], mode='lines+markers+text', name=r['model'],
                            text=['', '', f"{ui.fx(r['train mix, shifted'])}"], textposition='middle right',
                            line=dict(color=MODEL[r['model']], width=3 if r['model'] == 'DeBERTa' else 1.6), marker=dict(size=9),
                            customdata=[show_score(r['model'], r['balanced']), f"{ui.fx(r['train mix'], 4)}", f"{ui.fx(r['train mix, shifted'], 4)}"],
                            hovertemplate=r['model'] + ' · %{x}: %{customdata}<extra></extra>')
        fig.update_traces(textfont=dict(color=C['text2']))
        fig.update_layout(legend=dict(orientation='h', y=-0.15, x=1, xanchor='right'))
        fig.update_yaxes(title='accuracy')
        ui.show(fig, 360)
with c2:
    ui.callout('روی holdout متوازن DeBERTa ۰.۷۰ است. اگر همین نظرها با ترکیب train آمده بودند، <b>همین مدل بدون هیچ تغییری</b> ۰.۷۶۴ درست بود و با انتقال '
               'احتمال‌ها به prior train ۰.۷۹۲. یعنی حدود ۱۰ امتیاز فرق فقط از ترکیب داده‌ی ارزیابی می‌آید، نه از بهتر شدن مدل. test این پروژه متوازن است، '
               'پس عدد درست همان عدد متوازن است.', 'warn')
ui.code('part3_final', [35])

# ================================================================= TF-IDF explorer
ui.section('08', 'Inside the TF-IDF Model', 'روی هر خانه کلیک کن تا نظرهای واقعی همان خانه را ببینی')
vp = data.parquet('part3/tfidf_valid_predictions.parquet')
counts = pd.crosstab(vp['overall'], vp['predicted']).reindex(index=range(1, 6), columns=range(1, 6), fill_value=0)
shares = counts.values / counts.values.sum(axis=1, keepdims=True)
if 'cm_cell' not in st.session_state:
    st.session_state['cm_cell'] = (5, 1)


def pick_cell():
    pts = st.session_state['cm_chart']['selection']['points']
    if pts and pts[0].get('customdata'):
        st.session_state['cm_cell'] = (int(pts[0]['customdata'][0]), int(pts[0]['customdata'][1]))


true_r, pred_r = st.session_state['cm_cell']
c1, c2 = st.columns([1, 1.25], gap='large')
with c1:
    with st.container(border=True):
        labels = [f'{r}★' for r in range(1, 6)]
        fig = go.Figure(go.Heatmap(z=shares, x=labels, y=labels, colorscale=[[0, 'rgba(148,163,184,.07)'], [1, ui.rgba(C['violet'], .8)]], showscale=False,
                                   text=[[ui.pct0(v) for v in row] for row in shares], texttemplate='%{text}', textfont=dict(size=14, color=C['text']),
                                   xgap=3, ygap=3, hoverinfo='skip'))
        cells = [(t, q) for t in range(1, 6) for q in range(1, 6)]
        fig.add_scatter(x=[f'{q}★' for t, q in cells], y=[f'{t}★' for t, q in cells], mode='markers',
                        marker=dict(symbol='square', size=56, color='rgba(0,0,0,0)'),
                        selected=dict(marker=dict(color='rgba(0,0,0,0)')), unselected=dict(marker=dict(color='rgba(0,0,0,0)')),
                        customdata=[[t, q, int(counts.loc[t, q])] for t, q in cells], showlegend=False,
                        hovertemplate='true %{customdata[0]}★ → predicted %{customdata[1]}★<br>%{customdata[2]} reviews<extra></extra>')
        fig.add_shape(type='rect', x0=pred_r - 1.5, x1=pred_r - 0.5, y0=true_r - 1.5, y1=true_r - 0.5, line=dict(color=C['gold'], width=3))
        fig.update_xaxes(title='predicted', side='top', showgrid=False)
        fig.update_yaxes(title='true', autorange='reversed', showgrid=False)
        fig.update_layout(clickmode='event+select')
        ui.show(fig, 420, key='cm_chart', on_select=pick_cell)
with c2:
    cell = vp[(vp['overall'] == true_r) & (vp['predicted'] == pred_r)].sort_values('confidence', ascending=False)
    verdict = 'درست' if true_r == pred_r else 'اشتباه'
    st.html(f'<p class="take" style="margin:0"><b style="color:{RATING[true_r]}">امتیاز واقعی {fa(true_r)}</b> · '
            f'<b style="color:{RATING[pred_r]}">پیش‌بینی {fa(pred_r)}</b> — {fa(len(cell))} نظر ({verdict})</p>')
    for _, r in cell.head(4).iterrows():
        _, polarity, _ = model.predict(r['summary'], r['reviewText'])
        scale = max([abs(v) for v in polarity.values()] + [1e-6]) * 0.7
        body = model.clean(r['reviewText'])
        body = body[:420] + ('…' if len(body) > 420 else '')
        st.html(f'<div class="quote" style="--c:{RATING[true_r]}"><span class="stars">{ui.stars(true_r)}</span> '
                f'<span class="meta">اطمینان مدل به {fa(pred_r)} ستاره: {fa(ui.pct0(r["confidence"]))}</span>'
                f'<p><b>{model.highlight(model.clean(r["summary"]), polarity, scale, 0.3)}</b><br>{model.highlight(body, polarity, scale, 0.3)}</p></div>')

_, vocab, _, coef, _ = model.load()
cols = []
for i, rating in enumerate(range(1, 6)):
    top = vocab[np.argsort(coef[i])[::-1][:12]]
    cols.append(f'<div><h4 style="--c:{RATING[rating]}">{rating}★</h4>' + ''.join(f'<span>{t}</span>' for t in top) + '</div>')
with st.container(border=True):
    ui.sub('Strongest words and phrases for each rating', 'وزن‌های مدل TF-IDF')
    st.html('<div class="wordcols">' + ''.join(cols) + '</div>')
ui.note('خیلی از نویسنده‌ها امتیازشان را در متن هم می‌نویسند (2 stars، three stars) و not در ستون‌های ۱ و ۲ است؛ اگر به‌عنوان stop word حذف می‌شد، این اطلاعات از دست می‌رفت.')

# ================================================================= HMM
ui.section('09', 'Another Approach: Hidden Markov Models', 'همین تسک با یک روش دیگر · صفحه‌ی جداگانه در بخش Bonus')
c1, c2 = st.columns([1.4, 1], gap='large')
with c1:
    ui.callout('یکی از اعضای گروه همین مسئله‌ی تحلیل احساس را با یک <b>رویکرد مولد</b> حل کرده: برای هر کلاس یک Hidden Markov Model جدا آموزش دیده '
               'و هر نظر به کلاسی می‌رود که مدلش آن متن را محتمل‌تر می‌داند. نتیجه‌ها، اثر تنظیم bias و مقایسه‌ی منصفانه با مدل‌های این صفحه '
               'در صفحه‌ی <b>HMM · alternative method</b> آمده است.', 'info')
with c2:
    st.html(f'''<a class="tile" href="nlp-hmm" target="_self" style="--c:{C['violet']}"><div class="tag">BONUS · ALTERNATIVE METHOD</div>
      <h3>Hidden Markov Models</h3><p>micro-F1 سه‌کلاسه ۰.۷۸۴ و دوکلاسه ۰.۸۹۳ روی ترکیب طبیعی داده</p><span class="go">←</span></a>''')
ui.footer()
