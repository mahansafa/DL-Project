import plotly.graph_objects as go
import streamlit as st

from lib import ui
from lib.ui import C

ACC, ACC2 = C['violet'], C['teal']
CLS3 = ['dissatisfied', 'neutral', 'satisfied']
COL3 = [C['red'], C['slate'], C['green']]

# validation results (notebook task_3-HMM.ipynb): bias tuned on the first half of validation, reported on the second half
R3 = dict(before=0.6632, after=0.7837, majority=7422 / 10000, support=[1635, 943, 7422],
          precision=[.63, .30, .90], recall=[.61, .38, .87], f1=[.62, .33, .89], macro_f1=0.61, bias=[0.0, -0.01, 0.05])
R2 = dict(before=0.841, after=0.8925, majority=8186 / 10000, support=[1814, 8186],
          precision=[.69, .94], recall=[.73, .93], f1=[.71, .93], macro_f1=0.82, bias=0.05)
TEST3 = {0: 6007, 1: 4066, 2: 9927}
TEST2 = {0: 7980, 1: 12020}

ui.set_accent(ACC, ACC2)
ui.hero('NLP · Bonus · Alternative method', 'Hidden Markov Models for Sentiment',
        'این بخش مسئله‌ی جدیدی نیست: <b>همان تسک اصلی، یعنی تحلیل احساس نظرها</b>، با یک <b>روش و رویکرد دیگر</b> حل شده است. '
        'مدل‌های بخش ۳ (TF-IDF و ترنسفورمرها) <b>تمایزی</b>‌اند و مستقیم یاد می‌گیرند از روی متن کلاس را حدس بزنند. '
        'HMM <b>مولد</b> است: برای هر کلاس جدا یاد می‌گیرد متن‌های آن کلاس چطور «تولید» می‌شوند، و هر نظر به کلاسی می‌رود که مدلش آن متن را محتمل‌تر می‌داند.',
        chips=['task_3-HMM.ipynb', 'hmmlearn · CategoricalHMM', 'one model per class', '3 classes and 2 classes'],
        accent=ACC, accent2=ACC2)

st.html(f"""<div class="vs" style="margin-bottom:1.2rem">
  <div class="side" style="--c:{C['green']}"><span class="badge" style="--c:{C['green']}">MAIN TASK · PART 3</span>
    <h4 style="margin-top:.6rem">Discriminative models</h4>
    <p>TF-IDF + رگرسیون لجستیک و ترنسفورمرهای fine-tune شده مستقیم <bdi>P(class | text)</bdi> را یاد می‌گیرند؛ ۵ کلاس، روی validation متوازن.</p></div>
  <div class="mid">same task<br>↔<br>other method</div>
  <div class="side" style="--c:{ACC}"><span class="badge" style="--c:{ACC}">BONUS · THIS PAGE</span>
    <h4 style="margin-top:.6rem">Generative model · HMM</h4>
    <p>برای هر کلاس یک HMM جدا <bdi>P(text | class)</bdi> را یاد می‌گیرد؛ کلاس با بیشترین likelihood (به‌علاوه‌ی یک bias کوچک) برنده است.</p></div>
</div>""")

ui.kpis([
    ('0.784', 'micro-F1 · سه کلاس', 'منفی · خنثی · مثبت', ACC, '3'),
    ('0.893', 'micro-F1 · دو کلاس', 'بدون نظرهای ۳ ستاره', ACC2, '2'),
    ('+0.121', 'اثر تنظیم bias در سه کلاس', '۰.۶۶۳ → ۰.۷۸۴', C['gold'], '⚙'),
    ('0.61', 'macro-F1 · سه کلاس', 'کلاس خنثی سخت‌ترین است: F1 = ۰.۳۳', C['orange'], '⚖️'),
], cols=4)

# ================================================================= how it works
ui.section('01', 'How the HMM Classifier Works', 'یک مدل مولد برای هر کلاس، پیش‌بینی با بیشترین likelihood')
ui.flow([
    ('Clean words', 'متن summary + review با حروف کوچک، <code>n\'t</code> → <code>not</code>، فقط حروف انگلیسی، ۱۰۰ کلمه‌ی اول.'),
    ('Word ids', 'واژگان: کلمه‌هایی با حداقل ۵ تکرار در ۲۰۰ هزار نظر نمونه؛ بقیه <code>unk</code>.'),
    ('One HMM per class', 'CategoricalHMM با ۳ حالت پنهان و ۱۰ دور EM، روی ۱۵٬۰۰۰ سند از هر کلاس.'),
    ('Score', 'log-likelihood متن زیر مدل هر کلاس، تقسیم بر تعداد کلمه‌ها تا متن بلند جریمه نشود.'),
    ('Bias + argmax', 'یک bias کوچک برای هر کلاس روی نیمه‌ی اول validation تنظیم و روی نیمه‌ی دوم گزارش شد.'),
])

with st.container(border=True):
    ui.sub('One generative model per class', 'هر مدل ۳ حالت پنهان دارد که بین هم جابه‌جا می‌شوند و در هر قدم یک کلمه تولید می‌کنند')
    nodes, links = [], []
    for k, (name, col) in enumerate(zip(CLS3, COL3)):
        x0 = 120 + k * 330
        nodes.append({'name': name, 'x': x0 + 80, 'y': 40, 'symbolSize': [150, 40], 'symbol': 'roundRect',
                      'itemStyle': {'color': ui.rgba(col, .22), 'borderColor': col, 'borderWidth': 2},
                      'label': {'show': True, 'color': C['text'], 'fontWeight': 800, 'fontSize': 13, 'formatter': f'HMM · {name}'}})
        for s, (dx, dy) in enumerate([(0, 150), (160, 150), (80, 255)]):
            nid = f'{name}-s{s}'
            nodes.append({'name': nid, 'x': x0 + dx, 'y': dy, 'symbolSize': 46,
                          'itemStyle': {'color': ui.rgba(col, .85), 'shadowColor': col, 'shadowBlur': 14},
                          'label': {'show': True, 'formatter': f's{s + 1}', 'color': '#060912', 'fontWeight': 900}})
        for a in range(3):
            for b in range(3):
                if a != b:
                    links.append({'source': f'{name}-s{a}', 'target': f'{name}-s{b}',
                                  'lineStyle': {'color': ui.rgba(col, .6), 'width': 1.6, 'curveness': 0.25}})
            links.append({'source': name, 'target': f'{name}-s{a}', 'lineStyle': {'color': ui.rgba(col, .25), 'width': 1, 'type': 'dashed'},
                          'symbol': ['none', 'none']})
    ui.ec({'tooltip': {**ui.TOOLTIP, 'formatter': '{b}'},
           'series': [{'type': 'graph', 'layout': 'none', 'roam': False, 'data': nodes, 'links': links,
                       'edgeSymbol': ['none', 'arrow'], 'edgeSymbolSize': 7, 'emphasis': {'focus': 'adjacency'}}]},
          height=330, key='hmm_graph')
    ui.note('شکل مفهومی است: s1 تا s3 حالت‌های پنهان هر مدل‌اند. یک نظر جدید زیر هر سه مدل امتیاز می‌گیرد و به مدلی می‌رود که آن را محتمل‌تر می‌داند.')
ui.callout('تفاوت اصلی با بخش ۳: HMM <b>ترتیب کلمه‌ها</b> را از طریق جابه‌جایی بین حالت‌های پنهان مدل می‌کند، ولی هر کلمه فقط یک نماد گسسته است؛ '
           'هیچ embedding یا دانش از پیش‌آموخته‌ای ندارد، و هر مدل فقط داده‌ی کلاس خودش را می‌بیند، نه مرز بین کلاس‌ها را.', 'info')

# ================================================================= results
ui.section('02', 'Results on Validation', 'bias روی نیمه‌ی اول validation تنظیم شد و عددها مال نیمه‌ی دوم‌اند (۱۰٬۰۰۰ نظر)')
c1, c2 = st.columns(2, gap='large')
with c1:
    with st.container(border=True):
        ui.gauge(R3['after'], 'micro-F1 · 3 classes', 0, 1, ACC, height=260, key='hmm_g3', decimals=4, mark=R3['majority'],
                 sub='red tick = always "satisfied" (0.742)')
with c2:
    with st.container(border=True):
        ui.gauge(R2['after'], 'micro-F1 · 2 classes', 0, 1, ACC2, height=260, key='hmm_g2', decimals=4, mark=R2['majority'],
                 sub='red tick = always "satisfied" (0.82)')

c1, c2 = st.columns([1, 1.25], gap='large')
with c1:
    with st.container(border=True):
        ui.sub('HMM vs the majority baseline', 'micro-F1 روی همان ۱۰٬۰۰۰ نظر')
        fig = go.Figure()
        groups = ['3 classes', '2 classes']
        for name, vals, col in [('always satisfied', [R3['majority'], R2['majority']], C['slate']),
                                ('HMM · no bias', [R3['before'], R2['before']], ui.rgba(ACC, .5)),
                                ('HMM · tuned bias', [R3['after'], R2['after']], ACC)]:
            fig.add_bar(x=groups, y=vals, name=name, marker_color=col, text=[f'{ui.fx(v)}' for v in vals], textposition='outside',
                        textfont=dict(color=C['text2'], size=12), cliponaxis=False, marker_cornerradius=5)
        fig.update_yaxes(range=[0.5, 1.0], title='micro-F1')
        fig.update_layout(barmode='group', bargap=0.3, legend=dict(orientation='h', y=1.16, x=1, xanchor='right'))
        ui.show(fig, 320)
with c2:
    ui.callout('بدون bias، مدل سه‌کلاسه حتی از «همیشه بگو مثبت» (۰.۷۴۲) <b>بدتر</b> است (۰.۶۶۳)؛ چون هر HMM روی تعداد برابر سند از هر کلاس آموزش دیده '
               'ولی داده‌ی واقعی ۷۴٪ مثبت است. یک bias کوچک (<code>[0, -0.01, +0.05]</code>) این عدم توازن را جبران می‌کند و عدد را به ۰.۷۸۴ می‌رساند.', 'insight')
    ui.callout('تنظیم bias روی نیمه‌ی اول validation و گزارش روی نیمه‌ی دوم انجام شد، پس عدد نهایی روی داده‌ای است که در تنظیم استفاده نشده.', 'ok')

with st.container(border=True):
    tab3, tab2 = st.tabs(['Three classes', 'Two classes'])
    for tab, names, cols, r in [(tab3, CLS3, COL3, R3), (tab2, ['dissatisfied', 'satisfied'], [C['red'], C['green']], R2)]:
        with tab:
            a, b = st.columns([1.5, 1], gap='large')
            with a:
                ui.sub('Precision, recall and F1 per class', 'نیمه‌ی دوم validation')
                fig = go.Figure()
                for m, col in [('precision', C['sky']), ('recall', C['violet']), ('f1', C['gold'])]:
                    fig.add_bar(x=names, y=r[m], name=m, marker_color=col, marker_cornerradius=4, text=[f'{v:.2f}' for v in r[m]],
                                textposition='outside', textfont=dict(color=C['text2']), cliponaxis=False)
                fig.update_layout(barmode='group', legend=dict(orientation='h', y=1.14, x=1, xanchor='right'))
                fig.update_yaxes(range=[0, 1.08])
                ui.show(fig, 290, key=f'hmm_pc_{len(names)}')
            with b:
                ui.sub('Class mix of the check set', 'support هر کلاس')
                ui.donut([(n, v, c) for n, v, c in zip(names, r['support'], cols)], height=270, key=f'hmm_sup_{len(names)}',
                         center=f"{r['macro_f1']:.2f}", center_sub='macro-F1')
ui.callout('کلاس <b>خنثی</b> (۳ ستاره) نقطه‌ی ضعف است: F1 = ۰.۳۳. همین الگو در مدل‌های بخش ۳ هم دیده شد (۳ ستاره سخت‌ترین امتیاز بود)، '
           'ولی این‌جا شدیدتر است، چون مدل مولد هر کلاس را جدا یاد می‌گیرد و متن خنثی کلمه‌های هر دو طرف را دارد.', 'warn')

# ================================================================= test predictions
ui.section('03', 'Predictions on the Test Set', 'test برچسب ندارد؛ فقط توزیع پیش‌بینی‌ها را می‌شود دید')
c1, c2, c3 = st.columns(3, gap='medium')
with c1:
    with st.container(border=True):
        ui.sub('HMM · 3 classes', 'q2_submission_hmm.csv')
        ui.donut([(n, TEST3[k], c) for k, (n, c) in enumerate(zip(['negative', 'neutral', 'positive'], COL3))], height=280, key='hmm_t3', center='20k', center_sub='test reviews',
                 radius=('40%', '58%'))
with c2:
    with st.container(border=True):
        ui.sub('Expected if test is balanced', 'یافته‌ی بخش ۳: ~۲۰٪ از هر امتیاز')
        ui.donut([('1–2★', 40, C['red']), ('3★', 20, C['slate']), ('4–5★', 40, C['green'])],
                 height=280, key='hmm_exp', center='≈20%', center_sub='per star', radius=('40%', '58%'))
with c3:
    with st.container(border=True):
        ui.sub('HMM · 2 classes', 'q2_submission_hmm_2class.csv')
        ui.donut([('negative', TEST2[0], C['red']), ('positive', TEST2[1], C['green'])], height=280, key='hmm_t2',
                 center='60%', center_sub='positive', radius=('40%', '58%'))
ui.callout('مدل سه‌کلاسه ۵۰٪ نظرهای test را مثبت می‌داند، در حالی که اگر test مثل یافته‌ی بخش ۳ متوازن باشد انتظار ۴۰٪ داریم. '
           'دلیلش همان bias است: روی validation با ترکیب طبیعی (۷۴٪ مثبت) تنظیم شده و به سمت مثبت هل می‌دهد. '
           'این همان درسی است که در بخش ۳ گرفتیم: <b>ترکیب کلاس‌های داده‌ی ارزیابی</b> باید شبیه داده‌ی هدف باشد.', 'insight')

# ================================================================= compare
ui.section('04', 'How It Compares', 'چرا این عددها را نمی‌شود مستقیم کنار مدل اصلی گذاشت')
c1, c2 = st.columns([1.1, 1], gap='large')
with c1:
    with st.container(border=True):
        ui.sub('Gain over the "always majority" baseline', 'هر مدل در شرایط خودش · micro-F1 منهای خط پایه')
        ui.hbar_race([('HMM · 2 classes · natural mix', round(R2['after'] - R2['majority'], 3), ACC2),
                      ('HMM · 3 classes · natural mix', round(R3['after'] - R3['majority'], 3), ACC),
                      ('DeBERTa · 5 classes · balanced holdout', round(0.70 - 0.20, 3), C['green'])],
                     height=210, key='hmm_gain', fmt='+{c}', xmin=0, xmax=0.55)
        ui.note('خط پایه: پیش‌بینی همیشگی پرتکرارترین کلاس. در داده‌ی متوازن ۵ کلاسه این عدد ۰.۲۰ است و در داده‌ی طبیعی سه‌کلاسه ۰.۷۴۲.')
with c2:
    st.html("""<table class="board"><tbody>
        <tr class="me"><td>setup</td><td>HMM · this page</td><td>main task · Part 3</td></tr>
        <tr><td>classes</td><td>3 or 2</td><td>5 (1★–5★)</td></tr>
        <tr><td>evaluation mix</td><td>natural · ~74% positive</td><td>balanced · 20% each</td></tr>
        <tr><td>text features</td><td>word ids · no embeddings</td><td>TF-IDF / pretrained encoder</td></tr>
        <tr><td>learns</td><td>P(text | class)</td><td>P(class | text)</td></tr>
        <tr><td>micro-F1</td><td>0.784 · 0.893</td><td>0.70 (DeBERTa, holdout)</td></tr>
      </tbody></table>""")
    ui.callout('عدد بالاتر HMM به معنی مدل بهتر نیست: مسئله‌اش ساده‌تر است (کلاس کمتر) و داده‌ی ارزیابی‌اش نامتوازن است. '
               'HMM یک روش <b>سبک، قابل تفسیر و بدون GPU</b> برای همان مسئله است و مقایسه‌ی منصفانه با بخش ۳ نیاز به همان ۵ کلاس و همان validation متوازن دارد.', 'warn')

ui.section('05', 'Takeaways', 'جمع‌بندی')
c1, c2, c3 = st.columns(3, gap='medium')
with c1:
    ui.callout('<b>روش جایگزین، نه رقیب.</b> HMM نشان می‌دهد حتی یک مدل مولد ساده که فقط ترتیب نمادهای کلمه را می‌بیند، احساس را بهتر از خط پایه تشخیص می‌دهد.', 'ok')
with c2:
    ui.callout('<b>bias همه‌چیز را عوض کرد.</b> مدل‌های جداگانه‌ی هر کلاس روی داده‌ی متوازن آموزش دیدند؛ بدون تصحیح prior، از خط پایه هم بدتر بودند.', 'insight')
with c3:
    ui.callout('<b>قدم بعدی:</b> اجرای HMM روی همان ۵ کلاس و validation متوازن بخش ۳، تا عددها واقعاً کنار هم قرار بگیرند.', 'info')
ui.code('part3_hmm', [1, 3], 'کد HMM — task_3-HMM.ipynb')
ui.footer()
