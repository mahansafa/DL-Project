import base64
import math

import numpy as np
import plotly.graph_objects as go
import streamlit as st
from plotly.subplots import make_subplots

from lib import data, ui
from lib.ui import C

ACC, ACC2 = C['cyan'], C['sky']
APPEAR, DYN, OURS, TEAM = C['violet'], C['cyan'], C['cyan'], C['slate']
N_DEV, N_TEST = 1200, 300


def wilson(acc, n, z=1.96):
    """95% confidence interval of an accuracy measured on n videos (same formula as the notebook)."""
    center = (acc + z ** 2 / (2 * n)) / (1 + z ** 2 / n)
    half = z * math.sqrt(acc * (1 - acc) / n + z ** 2 / (4 * n ** 2)) / (1 + z ** 2 / n)
    return center - half, center + half


ui.set_accent(ACC, ACC2)
ui.hero('Vision · Main task', 'Accident Detection From Dashcam Video',
        'آیا در یک ویدئوی دوربین خودرو <b>تصادف یا شبه‌تصادف</b> رخ می‌دهد؟ ۱۵۰۰ ویدئوی برچسب‌دار Nexar، نصف تصادف و نصف رانندگی عادی. '
        'از هر ویدئو، از اول تا آخر، هر ۰.۲ ثانیه یک «لحظه» برداشته می‌شود و یک مدل زمانی کوچک (Attention-MIL) روی ویژگی‌های frozen آموزش می‌بیند. '
        'زمان حادثه (<code>time_of_event</code>) فقط برای ساختن برچسب و یک بررسی بعد از آموزش خوانده شد؛ همه‌ی تصمیم‌ها با 5-fold CV روی '
        '۱۲۰۰ ویدئوی dev گرفته شد و ۳۰۰ ویدئوی test <b>فقط یک بار</b>، در پایان، استفاده شد.',
        chips=['accident_preprocessing.ipynb', 'accident_mil_model.ipynb', 'CLIP · DINOv2 · optical flow', 'Attention-MIL · ensemble', 'Colab · T4'],
        accent=ACC, accent2=ACC2)

ui.kpis([
    ('0.810', 'accuracy روی test', '۳۰۰ ویدئو · بازه‌ی ۹۵٪: ۰.۷۶۲ تا ۰.۸۵۰', ACC, '🎯'),
    ('0.88', 'ROC-AUC روی test', 'F1 = ۰.۸۱۱', C['sky'], '📈'),
    ('0.781', 'accuracy در 5-fold CV', '۱۲۰۰ ویدئوی dev · AUC ‏۰.۸۶', C['violet'], '🔁'),
    ('71%', 'اوج امتیاز مدل در ۲± ثانیه‌ی حادثه', 'انتخاب تصادفی: ۱۱٪ · مدل زمان حادثه را ندیده', C['gold'], '📍'),
], cols=4)

# ================================================================= data
ui.section('01', 'The Data', 'ویدئوها، تقسیم داده و یک نمونه')
strip = base64.b64encode((ui.DATA / 'vision_main/frames_00822.jpg').read_bytes()).decode()
with st.container(border=True):
    ui.sub('Eight moments of accident video 00822', 'هر ۵.۸ ثانیه یک فریم از کل ویدئو · کادر قرمز: دو فریمی که برخورد بینشان رخ می‌دهد')
    st.html(f'<div class="strip"><img alt="eight frames of a dashcam video with an accident" src="data:image/jpeg;base64,{strip}"></div>')
    ui.note('برای نمایش فقط ۸ فریم آمده؛ مدل از همین ویدئو ۲۰۳ لحظه، هر ۰.۲ ثانیه یکی، می‌بیند.')

c1, c2 = st.columns([1.35, 1], gap='large')
with c1:
    with st.container(border=True):
        ui.sub('Where every video goes', 'ویدئوهای train حدود ۴۰ ثانیه · کلیپ‌های رسمی حدود ۱۰ ثانیه و مال مسئله‌ی امتیازی‌اند')
        nodes = [{'name': n, 'itemStyle': {'color': c, 'borderWidth': 0}} for n, c in [
            ('Nexar · 2,844', C['slate']), ('train · 1,500', ACC), ('official clips · 1,344', C['orange']),
            ('dev · 1,200 · 5 folds', C['violet']), ('test · 300 · used once', C['gold']), ('bonus task', C['pink'])]]
        links = [('Nexar · 2,844', 'train · 1,500', 1500), ('Nexar · 2,844', 'official clips · 1,344', 1344),
                 ('train · 1,500', 'dev · 1,200 · 5 folds', 1200), ('train · 1,500', 'test · 300 · used once', 300),
                 ('official clips · 1,344', 'bonus task', 1344)]
        ui.ec({'tooltip': {**ui.TOOLTIP, 'trigger': 'item'},
               'series': [{'type': 'sankey', 'left': 10, 'right': 150, 'top': 14, 'bottom': 14, 'nodeWidth': 16, 'nodeGap': 18, 'layoutIterations': 0,
                           'draggable': False, 'emphasis': {'focus': 'adjacency'},
                           'label': {'color': C['text'], 'fontFamily': ui.FONT, 'fontWeight': 700, 'fontSize': 12},
                           'lineStyle': {'color': 'gradient', 'opacity': 0.28, 'curveness': 0.5}, 'data': nodes,
                           'links': [{'source': a, 'target': b, 'value': v} for a, b, v in links]}]}, height=300, key='vm_sankey')
with c2:
    ui.kpis([('750 / 750', 'تصادف / بدون تصادف در train', 'test داخلی: ۱۴۹ / ۱۵۱', ACC, '⚖'),
             ('283,387', 'لحظه در ۱۵۰۰ ویدئو', '۷۵ تا ۳۰۰ لحظه برای هر ویدئو', C['violet'], '🎞')], cols=1)
    ui.note('تقسیم بر اساس برچسب و نوع صحنه stratify شد و یک بار ذخیره شد. برچسب از وجود مقدار در <code>time_of_event</code> ساخته شد و با نام پوشه کنترل شد.')
ui.code('vision_prep', [10, 12])

# ================================================================= shortcuts
ui.section('02', 'Shortcuts the Model Must Not Use', 'میان‌بُرهایی که جواب را بدون دیدن حادثه لو می‌دهند',
           'قبل از ساختن مدل بررسی شد چه چیزهایی به‌تنهایی کلاس را حدس می‌زنند. هر مدل ویدئویی باید به‌وضوح از این عددها بالاتر برود، و چیزی که در استفاده‌ی واقعی '
           'معلوم نیست (مثل زمان حادثه) نباید هیچ راهی به مدل پیدا کند.')
c1, c2 = st.columns(2, gap='large')
with c1:
    with st.container(border=True):
        ui.sub('Time of the event in accident videos', '۸۷٪ حادثه‌ها بین ثانیه‌ی ۱۸ و ۲۲ هستند')
        ev = ui.nbfig('vision_prep/cell014_1.json')['data'][0]['x']
        fig = go.Figure(go.Histogram(x=ev, xbins=dict(start=0, end=60, size=1), marker_color=ui.rgba(C['red'], .8), marker_line_width=0,
                                     hovertemplate='%{x} s<br>%{y} videos<extra></extra>'))
        fig.add_vrect(x0=18, x1=22, fillcolor=ui.rgba(C['gold'], .16), line_width=0, annotation_text='87%', annotation_position='top left',
                      annotation_font=dict(color=C['gold'], size=14))
        fig.update_xaxes(title='seconds from the start of the video', range=[0, 45]); fig.update_yaxes(title='videos')
        ui.show(fig, 300)
    ui.callout('اگر فریم‌ها بر اساس زمان حادثه انتخاب شوند یا مدل جایگاه مطلق زمان را بداند، می‌تواند فقط به «ثانیه‌ی ۲۰» نگاه کند؛ در استفاده‌ی واقعی این زمان معلوم نیست. '
               'برای همین نمونه‌برداری <b>یکنواخت روی کل ویدئو</b> است، مدل <b>positional encoding</b> ندارد و لحظه‌های لبه‌ی ویدئو از pooling کنار می‌روند.', 'leak')
with c2:
    with st.container(border=True):
        ui.sub('How far a shortcut gets', 'پررنگ: accuracy · کم‌رنگ: ROC-AUC · logistic regression روی همان ۵ fold')
        rows = [('final ensemble · test', 0.810, 0.877, ACC), ('final ensemble · CV', 0.781, 0.859, C['violet']),
                ('metadata only', 0.619, 0.642, C['orange']), ('video duration only', 0.527, 0.530, C['slate']),
                ('file size only', 0.514, 0.502, C['slate'])][::-1]
        fig = go.Figure()
        fig.add_bar(y=[r[0] for r in rows], x=[r[1] for r in rows], orientation='h', name='accuracy', marker_color=[r[3] for r in rows],
                    marker_cornerradius=5, text=[f'{ui.fx(r[1])}' for r in rows], textposition='outside', textfont=dict(color=C['text']))
        fig.add_bar(y=[r[0] for r in rows], x=[r[2] for r in rows], orientation='h', name='ROC-AUC', marker_color=[ui.rgba(r[3], .4) for r in rows],
                    marker_cornerradius=5, text=[f'{ui.fx(r[2])}' for r in rows], textposition='outside', textfont=dict(color=C['text2']))
        fig.add_vline(x=0.5, line_dash='dot', line_color=C['muted'])
        fig.update_xaxes(range=[0.4, 0.95])
        fig.update_layout(barmode='group', bargap=0.25, showlegend=False)
        ui.show(fig, 300)
    with st.container(border=True):
        ui.sub('Accident share by video condition', 'train · چرا متادیتا به‌تنهایی به ۰.۶۲ می‌رسد')
        audit = data.csv('vision/metadata_audit.csv')
        names = {'scene': 'scene', 'weather': 'weather', 'light': 'light_conditions'}
        pick = st.segmented_control('column', list(names), default='scene', label_visibility='collapsed', key='vm_col')
        part = audit[audit['column'] == names[pick or 'scene']].sort_values('p_accident')
        fig = go.Figure(go.Bar(x=part['p_accident'], y=part['value'], orientation='h', marker_cornerradius=5,
                               marker_color=[C['red'] if v > .55 else (C['sky'] if v < .45 else C['slate']) for v in part['p_accident']],
                               text=[ui.pct0(v) for v in part['p_accident']], textposition='outside',
                               hovertemplate='%{y}: %{x:.0%} accidents<extra></extra>'))
        fig.add_vline(x=0.5, line_dash='dot', line_color=C['gold'])
        fig.update_traces(textfont=dict(color=C['text2']), cliponaxis=False)
        fig.update_xaxes(range=[0, 1.12], tickformat='.0%')
        ui.show(fig, 230)
ui.code('vision_prep', [14, 17, 29])

# ================================================================= features
ui.section('03', 'From Video to Moments', 'هر ۰.۲ ثانیه یک بردار ۲۰۶۳ بعدی')
ui.flow([
    ('Sample', 'هر ۰.۲ ثانیه یک فریم، حدود ۲۰۰ لحظه برای ویدئوی ۴۰ ثانیه‌ای؛ برخورد کسری از ثانیه است و با فاصله‌ی بیشتر ممکن است بین دو نمونه بیفتد.'),
    ('CLIP ViT-B/16', '۵۱۲ عدد: معنای صحنه (خودرو، عابر، تقاطع). frozen، بدون fine-tune.'),
    ('DINOv2 ViT-B/14', '۱۵۳۶ عدد: CLS + میانگین patchها، جزئیات مکانی و شکل اجسام.'),
    ('Optical flow', '۶ عدد حرکت بین هر فریم و فریم بعدی‌اش + تغییر همان‌ها نسبت به لحظه‌ی قبل.'),
    ('Change', '۳ عدد: فاصله‌ی cosine هر embedding با لحظه‌ی قبل؛ «چقدر کل تصویر عوض شد».'),
])
c1, c2 = st.columns([1.5, 1], gap='large')
with c1:
    with st.container(border=True):
        ui.sub('Motion features over time', 'بالا: ویدئوی تصادف 00822 · پایین: رانندگی عادی · خط‌چین قرمز فقط برای مقایسه‌ی چشمی است')
        mf = ui.nbfig('vision_prep/cell024_1.json')['data']
        fig = make_subplots(rows=2, cols=1, shared_xaxes=True, vertical_spacing=0.08)
        cols = {'flow_bottom': C['sky'], 'expansion': C['gold'], 'flow_y': C['violet']}
        for k, t in enumerate(mf):
            row = 1 if k < 3 else 2
            fig.add_scatter(x=t['x'], y=t['y'], name=t['name'], legendgroup=t['name'], showlegend=row == 1, mode='lines',
                            line=dict(color=cols[t['name']], width=1.8), row=row, col=1)
        fig.add_vline(x=19.5, line_dash='dash', line_color=C['red'], row=1, col=1)
        fig.update_yaxes(title='accident · px/s', row=1, col=1)
        fig.update_yaxes(title='normal · px/s', row=2, col=1)
        fig.update_xaxes(title='seconds', row=2, col=1)
        fig.update_layout(legend=dict(orientation='h', y=1.12, x=1, xanchor='right'))
        ui.show(fig, 400)
with c2:
    st.html(f"""<table class="board"><tbody>
      <tr class="me"><td>motion feature</td><td>meaning</td></tr>
      <tr><td>flow_mean</td><td>شدت کلی حرکت</td></tr>
      <tr><td>flow_bottom</td><td>حرکت یک‌سوم پایین تصویر؛ تقریب سرعت</td></tr>
      <tr><td>expansion</td><td>باز شدن تصویر از مرکز؛ نزدیک شدن</td></tr>
      <tr><td>flow_x</td><td>انحراف به چپ و راست</td></tr>
      <tr><td>flow_y</td><td>تکان عمودی؛ ضربه یا ترمز</td></tr>
      <tr><td>pixel_change</td><td>تغییر روشنایی بین دو فریم</td></tr>
    </tbody></table>""")
    ui.callout('در شبه‌تصادف خسارتی دیده نمی‌شود؛ نشانه‌ی اصلی <b>ترمز یا انحراف ناگهانی</b> است. فریم‌ها هم مربعی نمی‌شوند، چون برش مربعی حدود ۴۴٪ عرض تصویر را '
               'حذف می‌کند و برخوردهای جانبی همان‌جاست.', 'vision')
ui.code('vision_prep', [19, 20])

with st.container(border=True):
    ui.sub('Linear probe: how much the features know', 'ویژگی‌ها در طول زمان با mean، max و std خلاصه شده‌اند · ترتیب زمانی دیده نمی‌شود')
    probe = [('CLIP', 0.692, 0.690, 0.755), ('DINOv2', 0.696, 0.691, 0.771), ('Motion', 0.682, 0.692, 0.730), ('All', 0.699, 0.697, 0.779)]
    fig = go.Figure()
    for j, (metric, col) in enumerate([('accuracy', ACC), ('F1', C['violet']), ('ROC-AUC', C['gold'])], start=1):
        fig.add_bar(x=[p[0] for p in probe], y=[p[j] for p in probe], name=metric, marker_color=col, marker_cornerradius=4,
                    text=[f'{ui.fx(p[j])}' for p in probe], textposition='outside', textfont=dict(color=C['text2'], size=11))
    fig.update_yaxes(range=[0.5, 0.85])
    fig.update_layout(barmode='group', bargap=0.3, legend=dict(orientation='h', y=1.14, x=1, xanchor='right'))
    ui.show(fig, 280)
ui.note('linear probe مدل نهایی نیست: لحظه‌ی کوتاه حادثه در میانگین ۴۰ ثانیه گم می‌شود. این عددها سقف پایینی است که مدل زمانی باید از آن بالاتر برود.')
ui.code('vision_prep', [31])

# ================================================================= model
ui.section('04', 'Attention-MIL', 'هر ویدئو یک «کیسه» از لحظه‌هاست و فقط برچسب کل ویدئو معلوم است')
st.html(f"""<div class="flow" style="direction:ltr">
  <div class="step" data-n="IN"><b>moments · T × d</b><span>T بین ۷۵ و ۳۰۰؛ لحظه‌های پرشده با mask کنار می‌روند</span></div><div class="arrow">→</div>
  <div class="step" data-n="01"><b>Linear → 128</b><span>نمایش هر لحظه، مشترک برای همه‌ی لحظه‌ها</span></div><div class="arrow">→</div>
  <div class="step" data-n="02"><b>[LayerNorm → Conv1d → GELU] ×2</b><span>residual · هر لحظه ۱.۸ ثانیه‌ی اطرافش را می‌بیند</span></div><div class="arrow">→</div>
  <div class="step" data-n="03"><b>gated attention / max</b><span>کدام لحظه‌ها مهم‌اند؛ نمایش کل ویدئو</span></div><div class="arrow">→</div>
  <div class="step" data-n="OUT"><b>Linear → p(accident)</b><span>۴۴۵٬۵۰۶ پارامتر در مدل اول</span></div>
</div>""")
c1, c2, c3, c4 = st.columns(4, gap='small')
with c1:
    ui.callout('<b>ویژگی frozen، نه fine-tune.</b> با ۹۶۰ ویدئوی آموزشی در هر fold، fine-tune یک encoder بزرگ (MViT با حدود ۳۵ میلیون پارامتر) سریع overfit می‌شود.', 'info')
with c2:
    ui.callout('<b>MIL، نه برچسب برای هر فریم.</b> بیش از ۹۰٪ فریم‌های ویدئوی تصادف رانندگی عادی‌اند؛ برچسب فریم از زمان حادثه هم ممنوع است.', 'info')
with c3:
    ui.callout('<b>conv کوتاه، نه LSTM یا Transformer.</b> conv به جای مطلق حساس نیست؛ LSTM می‌تواند گام‌ها را بشمارد و «ثانیه‌ی ۲۰» را یاد بگیرد.', 'info')
with c4:
    ui.callout('<b>اعتبارسنجی سخت‌گیر.</b> lr ثابت، epoch با کمترین log loss out-of-fold، ۳ seed در هر fold، آستانه‌ی ثابت ۰.۵، نرمال‌سازی فقط با train همان fold.', 'ok')
ui.code('vision_mil', [6, 8, 10])

# ================================================================= fingerprint
ui.section('05', 'The Video Fingerprint', 'مدل اول ویدئوها را حفظ کرد، نه حادثه را',
           'مدل اول با همه‌ی ویژگی‌ها در <b>epoch 1</b> بهترین بود: accuracy ‏۰.۶۹، حتی پایین‌تر از linear probe. ۲۰۴۸ عدد ظاهری هر لحظه برای هر ویدئو یک «اثر انگشت» '
           'می‌سازد (نوع جاده، نور، ماشین جلویی) که در کل ویدئو تقریباً ثابت است، و با ۹۶۰ ویدئو حفظ کردن آن از یاد گرفتن الگوی کوتاه حادثه آسان‌تر است.')
c1, c2 = st.columns([1.25, 1], gap='large')
with c1:
    with st.container(border=True):
        ui.sub('Training curves of the first model', 'میانگین ± انحراف معیار ۵ fold · خط‌چین: epoch انتخاب‌شده')
        tc = ui.nbfig('vision_mil/cell013_0.json')['data']
        fig = make_subplots(rows=1, cols=2, horizontal_spacing=0.12)
        for col, base in [(1, 0), (2, 4)]:
            for off, name, color in [(0, 'train', C['slate']), (2, 'validation', C['red'])]:
                band, mean = tc[base + off], tc[base + off + 1]
                fig.add_scatter(x=band['x'], y=band['y'], fill='toself', fillcolor=ui.rgba(color, .15), line_width=0, mode='lines',
                                hoverinfo='skip', showlegend=False, row=1, col=col)
                fig.add_scatter(x=mean['x'], y=mean['y'], name=name, line=dict(color=color, width=2.6), showlegend=col == 1,
                                legendgroup=name, row=1, col=col)
        fig.add_vline(x=1, line_dash='dash', line_color=C['gold'])
        fig.update_xaxes(title='epoch')
        fig.update_yaxes(title='log loss', row=1, col=1)
        fig.update_yaxes(title='accuracy', row=1, col=2)
        fig.update_layout(legend=dict(orientation='h', y=1.16, x=1, xanchor='right'))
        ui.show(fig, 320)
with c2:
    ui.callout('از epoch 2 به بعد accuracy روی train از ۷۵٪ به ۹۹٪ (epoch 9) می‌رسد و log loss روی validation از ۰.۶۰ به بیش از ۲ بالا می‌رود، '
               'در حالی که accuracy روی validation بین ۶۶ و ۶۹٪ ثابت می‌ماند.', 'warn')
    ui.callout('عوض کردن pooling، conv یا طول پنجره این را تغییر نداد (همه بین ۰.۶۸ و ۰.۷۱)؛ پس مشکل از <b>ورودی</b> است، نه معماری. '
               'centering و PCA روی ویژگی‌های ظاهری هم کمکی نکرد.', 'insight')

with st.container(border=True):
    ui.sub('Appearance memorizes, motion learns', 'هر نقطه یک مدل در 5-fold CV · محور افقی: epoch با کمترین log loss · بنفش: ورودی ظاهری دارد · فیروزه‌ای: فقط حرکت و تغییر')
    pts = [  # model, best epoch, accuracy, AUC, uses appearance
        ('first model · all features', 1, 0.688, 0.751, True), ('mean pooling', 1, 0.688, 0.750, True), ('max pooling', 3, 0.707, 0.773, True),
        ('no temporal conv', 3, 0.690, 0.765, True), ('longer context 3.4 s', 1, 0.691, 0.750, True), ('CLIP only', 1, 0.684, 0.745, True),
        ('DINOv2 only', 1, 0.683, 0.741, True), ('appearance PCA 32', 2, 0.686, 0.748, True), ('appearance centered', 1, 0.700, 0.759, True),
        ('Motion only', 21, 0.732, 0.810, False), ('Motion + change', 13, 0.723, 0.800, False), ('Motion + change · max pooling', 36, 0.749, 0.829, False),
        ('Motion + change · 80 epochs', 45, 0.753, 0.829, False), ('Motion + change · mirror', 63, 0.760, 0.834, False)]
    fig = go.Figure()
    for flag, name, col in [(True, 'with CLIP / DINOv2', APPEAR), (False, 'motion + change only', DYN)]:
        sel = [p for p in pts if p[4] == flag]
        fig.add_scatter(x=[p[1] for p in sel], y=[p[2] for p in sel], mode='markers', name=name,
                        marker=dict(size=[8 + 60 * (p[3] - 0.73) for p in sel], color=ui.rgba(col, .8), line=dict(color=col, width=1.5)),
                        customdata=[[p[0], p[3]] for p in sel],
                        hovertemplate='%{customdata[0]}<br>best epoch %{x}<br>accuracy %{y:.3f}<br>AUC %{customdata[1]:.3f}<extra></extra>')
    fig.add_annotation(x=2, y=0.712, text='overfit by epoch 1–3', showarrow=False, font=dict(color=APPEAR, size=12), xanchor='left')
    fig.add_annotation(x=63, y=0.760, text='mirror · 63 epochs', showarrow=True, arrowcolor=DYN, font=dict(color=DYN, size=12), ax=-20, ay=-30)
    fig.update_xaxes(title='best epoch (lowest out-of-fold log loss)', type='log', dtick=1, range=[-0.1, 1.95])
    fig.update_yaxes(title='accuracy · 1200 dev videos', range=[0.67, 0.775])
    fig.update_layout(legend=dict(orientation='h', y=1.12, x=1, xanchor='right'))
    ui.show(fig, 340)
ui.callout('با فقط ۱۵ عدد حرکت و تغییر در هر لحظه چیزی برای حفظ کردن نیست؛ مدل باید الگوی زمانی را یاد بگیرد و دیرتر overfit می‌شود (epoch 13 تا 63). '
           '<b>Motion only</b> با ۱۲ عدد به ۰.۷۳۲ رسید، در حالی که همین ویژگی‌ها در linear probe ۰.۶۸۲ گرفتند؛ اختلاف ۵ درصدی سهم مدل زمانی است. '
           'از این‌جا مدل زمانی فقط ویژگی‌های دینامیک می‌بیند و ظاهر صحنه از راه linear probe در ensemble وارد می‌شود.', 'insight')
ui.code('vision_mil', [12, 13, 16, 19])

# ================================================================= climb
ui.section('06', 'Climbing to the Final Model', 'هر قدم فقط یک چیز را عوض می‌کند')
steps = [('first model · all features', 0.688, 0.751, N_DEV), ('motion only', 0.732, 0.810, N_DEV),
         ('+ change · max pooling', 0.749, 0.829, N_DEV), ('+ 80 epochs', 0.753, 0.829, N_DEV), ('+ mirror augmentation', 0.760, 0.834, N_DEV),
         ('+ random search', 0.772, 0.846, N_DEV), ('+ ensemble with probe', 0.781, 0.859, N_DEV), ('test · 300 videos, once', 0.810, 0.877, N_TEST)]
with st.container(border=True):
    ui.sub('Accuracy at every step', 'نقطه‌ها: accuracy با بازه‌ی ۹۵٪ (Wilson) · خط‌چین: ROC-AUC · نوار سبز: هدف ۰.۷۸ تا ۰.۸۰')
    xs = [s[0] for s in steps]
    lo_hi = [wilson(s[1], s[3]) for s in steps]
    fig = go.Figure()
    fig.add_hrect(y0=0.78, y1=0.80, fillcolor=ui.rgba(C['green'], .12), line_width=0)
    fig.add_scatter(x=xs, y=[s[2] for s in steps], name='ROC-AUC', mode='lines+markers', line=dict(color=C['gold'], width=2, dash='dot'),
                    marker=dict(size=7), hovertemplate='%{x}<br>AUC %{y:.3f}<extra></extra>')
    fig.add_scatter(x=xs, y=[s[1] for s in steps], name='accuracy', mode='lines+markers+text', line=dict(color=ACC, width=3, shape='hv'),
                    marker=dict(size=[12] * 7 + [16], color=[ACC] * 7 + [C['gold']], line=dict(color=C['bg'], width=2)),
                    error_y=dict(type='data', symmetric=False, array=[h - s[1] for s, (l, h) in zip(steps, lo_hi)],
                                 arrayminus=[s[1] - l for s, (l, h) in zip(steps, lo_hi)], color=ui.rgba(ACC, .5), thickness=1.5, width=5),
                    text=[f'{ui.fx(s[1])}' for s in steps], textposition='bottom right', textfont=dict(color=C['text'], size=12),
                    hovertemplate='%{x}<br>accuracy %{y:.3f}<extra></extra>')
    fig.update_yaxes(range=[0.64, 0.9], title='score')
    fig.update_xaxes(tickangle=-20, tickfont=dict(size=11))
    fig.update_layout(legend=dict(orientation='h', y=1.12, x=1, xanchor='right'))
    ui.show(fig, 400)

c1, c2 = st.columns([1.4, 1], gap='large')
with c1:
    with st.container(border=True):
        ui.sub('Random search · 6 trials', 'هر trial با همان 5-fold CV و یک seed · مرتب بر اساس log loss')
        trials = [(4, 'max', 128, 9, 3, 0.7700, 0.8355, 0.5049), (0, 'max', 128, 5, 2, 0.7483, 0.8252, 0.5167),
                  (5, 'max', 32, 5, 2, 0.7358, 0.8092, 0.5369), (1, 'attention', 64, 5, 1, 0.7367, 0.8042, 0.5434),
                  (3, 'attention', 128, 3, 3, 0.7533, 0.8113, 0.5686), (2, 'attention', 64, 9, 2, 0.7258, 0.7981, 0.5947)]
        fig = go.Figure()
        labels = [f'trial {t[0]} · {t[1]} · dim {t[2]} · k{t[3]}×{t[4]}' for t in trials][::-1]
        fig.add_bar(y=labels, x=[t[7] for t in trials][::-1], orientation='h', marker_cornerradius=5,
                    marker_color=[ACC if t[1] == 'max' else C['violet'] for t in trials][::-1],
                    text=[f'{ui.fx(t[7])} · acc {ui.fx(t[5])}' for t in trials][::-1], textposition='outside', cliponaxis=False,
                    textfont=dict(color=C['text2'], size=11))
        fig.update_xaxes(range=[0.45, 0.68], title='out-of-fold log loss (lower is better)')
        ui.show(fig, 300)
with c2:
    st.html('<div class="chips" style="margin-top:.2rem">' + ''.join(f'<span class="chip c" style="--c:{ACC}">{c}</span>' for c in [
        'max pooling', 'dim 128', 'kernel 9 × 3 layers = 5 s context', 'dropout 0.1', 'input dropout 0', 'time drop 0.2', 'lr 1e-4',
        'weight decay 0.05', 'mirror', '80 epochs max']) + '</div>')
    ui.callout('trial شماره‌ی ۴ برنده شد و با ۳ seed تازه دوباره آموزش دید: accuracy ‏۰.۷۷۲، AUC ‏۰.۸۵ و log loss ‏۰.۴۹، در برابر ۰.۷۶۰، ۰.۸۳۴ و ۰.۵۱ پیش از search. '
               'دو trial برتر هر دو max pooling‌اند: حادثه یک لحظه‌ی کوتاه است و max همان قوی‌ترین لحظه را می‌گیرد.', 'insight')
    ui.note('random search به‌جای grid: grid کامل این فضا تقریباً ۲۰ هزار ترکیب بود. seedهای تازه سهم شانس را از برنده حذف می‌کنند.')

c1, c2 = st.columns([1, 1.4], gap='large')
with c1:
    with st.container(border=True):
        ui.sub('Ensemble weights', 'با گام ۰.۰۵ و کمترین log loss out-of-fold')
        ui.donut([('tuned model', 0.70, ACC), ('mirror model', 0.05, C['violet']), ('linear probe', 0.25, C['gold'])],
                 height=270, key='vm_w', center='3', center_sub='members', radius=('44%', '64%'))
with c2:
    ui.callout('ensemble در CV به accuracy ‏۰.۷۸۱ (بازه‌ی ۰.۷۶ تا ۰.۸۰۳)، F1 ‏۰.۷۷۳ و AUC ‏۰.۸۶ رسید. وزن کم مدل دوم یعنی اطلاعات تازه‌ای ندارد و سود از '
               '<b>linear probe</b> می‌آید که ظاهر کلی صحنه را می‌بیند؛ همان چیزی که مدل زمانی کنار گذاشته بود.', 'ok')
    ui.callout('۱۰ ترکیب برتر وزن‌ها همه بین ۰.۷۸۱ و ۰.۷۸۴‌اند؛ نتیجه به وزن دقیق حساس نیست. چون همه‌ی این انتخاب‌ها روی همین ۱۲۰۰ ویدئو انجام شده، '
               'عدد CV کمی خوش‌بینانه است و عدد بی‌طرف را فقط test می‌دهد.', 'info')
ui.code('vision_mil', [22, 25, 26, 29])

# ================================================================= test
ui.section('07', 'Final Evaluation on the Test Set', '۳۰۰ ویدئو، برای اولین و تنها بار',
           'مدل‌ها با همان تنظیمات و همان تعداد epoch این بار روی <b>همه‌ی ۱۲۰۰ ویدئوی dev</b> آموزش دیدند و ensemble با همان وزن‌های CV ساخته شد. '
           'هیچ چیز بر اساس نتیجه‌ی test عوض نشد.')
c1, c2, c3 = st.columns(3, gap='medium')
for col_, (v, title, color, key) in zip((c1, c2, c3), [(0.810, 'accuracy · test', ACC, 'vm_ga'), (0.811, 'F1 · test', C['violet'], 'vm_gf'),
                                                        (0.877, 'ROC-AUC · test', C['gold'], 'vm_gauc')]):
    with col_:
        with st.container(border=True):
            ui.gauge(v, title, 0.5, 1.0, color, height=240, key=key, mark=0.781 if key == 'vm_ga' else None, fmt=f'{ui.fx(v)}',
                     sub='red tick = CV accuracy (0.781)' if key == 'vm_ga' else '300 videos · 149 accidents')

c1, c2 = st.columns([1, 1.45], gap='large')
with c1:
    with st.container(border=True):
        ui.sub('Confusion matrix · test', 'ensemble · آستانه‌ی ثابت ۰.۵')
        st.html(f"""<div class="cm">
          <div></div><div class="h">predicted<br>accident</div><div class="h">predicted<br>no accident</div>
          <div class="h">accident</div>
          <div class="cell" style="--c:{C['green']}"><b>122</b><span>caught</span></div>
          <div class="cell" style="--c:{C['red']}"><b>27</b><span>missed</span></div>
          <div class="h">no accident</div>
          <div class="cell" style="--c:{C['orange']}"><b>30</b><span>false alarm</span></div>
          <div class="cell" style="--c:{C['slate']}"><b>121</b><span>correct</span></div>
        </div>""")
        ui.note('خطاها تقریباً متقارن‌اند: ۲۷ حادثه‌ی ازدست‌رفته و ۳۰ هشدار اشتباه.')
with c2:
    with st.container(border=True):
        ui.sub('Every member: cross-validation → test', 'ترتیب مدل‌ها روی test همان ترتیب CV است')
        members = [('ensemble', 0.781, 0.810, C['gold']), ('tuned temporal model', 0.772, 0.803, ACC),
                   ('mirror model', 0.760, 0.787, C['violet']), ('linear probe', 0.699, 0.747, C['slate'])]
        fig = go.Figure()
        for name, cv, te, col in members:
            fig.add_scatter(x=['CV · 1200 dev', 'test · 300'], y=[cv, te], mode='lines+markers+text', name=name, line=dict(color=col, width=3),
                            marker=dict(size=11), text=[f'{ui.fx(cv)}', f'{ui.fx(te)}'], textposition=['middle left', 'middle right'],
                            textfont=dict(color=col, size=12))
        fig.update_xaxes(range=[-0.45, 1.45])
        fig.update_yaxes(range=[0.68, 0.83], title='accuracy')
        fig.update_layout(legend=dict(orientation='h', y=1.14, x=1, xanchor='right'))
        ui.show(fig, 300)
ui.callout('عدد test (۰.۸۱۰) کمی بالاتر از CV (۰.۷۸۱) است، به دو دلیل: مدل‌های نهایی با ۱۲۰۰ ویدئو به‌جای ۹۶۰ آموزش دیده‌اند، و ۳۰۰ ویدئو بازه‌ای حدود ۵± درصد دارد. '
           'برآورد منصفانه‌ی دقت مدل <b>حدود ۷۸ تا ۸۱ درصد</b> است.', 'ok')
ui.code('vision_mil', [43, 44])

# ================================================================= where it looks
ui.section('08', 'Where Does the Model Look?', 'مدل هیچ‌وقت زمان حادثه را ندیده است',
           'اگر مدل واقعاً حادثه را تشخیص می‌دهد، در ویدئوهای تصادف بیشترین امتیاز لحظه باید حوالی خود حادثه باشد. <code>time_of_event</code> فقط این‌جا و بعد از آموزش '
           'خوانده شد؛ مدل اول و مدل نهایی روی fold 0 دوباره آموزش دیدند و روی ۲۴۰ ویدئوی validation همان fold بررسی شدند.')
c1, c2 = st.columns([1, 1.3], gap='large')
with c1:
    with st.container(border=True):
        ui.sub('Peak within ±2 s of the event', 'سهم ویدئوهای تصادف fold 0')
        ui.hbar_race([('final model', 71, ACC), ('first model · all features', 30, APPEAR), ('random moment', 11, C['slate'])],
                     height=190, key='vm_peak', fmt='{c}%', xmin=0, xmax=85)
    ui.kpis([('0 %', 'اوج در ثانیه‌ی اول یا آخر', 'مدل اول: ۱۴٪', ACC, '⟷'),
             ('0.8 s', 'میانه‌ی فاصله‌ی اوج تا حادثه', 'مدل اول: ۷.۹ ثانیه', C['gold'], '⏱')], cols=2)
with c2:
    with st.container(border=True):
        ui.sub('Peak time minus event time', 'مدل نهایی · ۱۱۹ ویدئوی تصادف fold 0 · نوار: ۲± ثانیه')
        d = ui.nbfig('vision_mil/cell032_0.json')['data'][0]['x']
        fig = go.Figure(go.Histogram(x=d, xbins=dict(start=-30, end=30, size=1), marker_color=ui.rgba(ACC, .8), marker_line_width=0,
                                     hovertemplate='%{x} s<br>%{y} videos<extra></extra>'))
        fig.add_vrect(x0=-2, x1=2, fillcolor=ui.rgba(C['gold'], .16), line_width=0)
        fig.update_xaxes(title='seconds (negative = before the event)', range=[-25, 25]); fig.update_yaxes(title='videos')
        ui.show(fig, 330)

with st.container(border=True):
    ui.sub('Moment scores of five videos', 'اولین ویدئوهای fold 0، بدون انتخاب دستی · قرمز: تصادف (خط‌چین = زمان حادثه) · آبی: عادی · p = احتمال ویدئو در مدل fold 0')
    wt = ui.nbfig('vision_mil/cell033_0.json')
    titles = [a['text'] for a in wt['layout']['annotations']]
    events = [21.177, 21.864, 20.087, None, None]
    fig = make_subplots(rows=5, cols=1, shared_xaxes=True, vertical_spacing=0.045, subplot_titles=titles)
    for k, (t, e) in enumerate(zip(wt['data'], events), start=1):
        col = C['red'] if e else C['sky']
        y = [None if v is None else v for v in t['y']]
        fig.add_scatter(x=t['x'], y=y, mode='lines', line=dict(color=col, width=1.8), showlegend=False, hovertemplate='%{x:.1f} s · score %{y:.2f}<extra></extra>', row=k, col=1)
        if e:
            fig.add_vline(x=e, line_dash='dash', line_color=C['gold'], row=k, col=1)
    fig.update_annotations(font=dict(color=C['text2'], size=11), xanchor='left', x=0)
    fig.update_xaxes(title='seconds', row=5, col=1)
    fig.update_yaxes(showticklabels=False)
    ui.show(fig, 560)
ui.callout('در دو ویدئوی تصادف از سه تا، اوج امتیاز در کمتر از ۲ ثانیه از حادثه است (00884 و 00903) حتی با این‌که احتمال کل ویدئو زیر ۰.۵ ماند؛ '
           'مدل لحظه‌ی درست را پیدا کرده ولی به آن اطمینان کافی ندارد. ویدئوی عادی 01429 با احتمال ۰.۹۴ یک هشدار اشتباه است. '
           'در کل fold هیچ ویدئویی اوجش در ثانیه‌ی اول یا آخر نیست: دقت مدل از دیدن خود حادثه می‌آید، نه از یک میان‌بُر.', 'insight')
ui.code('vision_mil', [32, 33])

# ================================================================= learning curve
ui.section('09', 'More Data Would Still Help', 'منحنی یادگیری با تعداد ویدئوی آموزشی')
c1, c2 = st.columns([1.5, 1], gap='large')
with c1:
    with st.container(border=True):
        ui.sub('Learning curve', 'Motion + change با max pooling · زیرمجموعه‌های تودرتو و متوازن · نوار نارنجی: اندازه‌ی کار نسخه‌های قبلی تیم')
        lc = [(120, 1.000, 0.644, 0.708), (240, 0.992, 0.682, 0.762), (480, 0.935, 0.711, 0.806), (720, 0.881, 0.721, 0.817), (960, 0.856, 0.738, 0.828)]
        n = [r[0] for r in lc]
        ci = [wilson(r[2], N_DEV) for r in lc]
        fig = go.Figure()
        fig.add_vrect(x0=240, x1=450, fillcolor=ui.rgba(C['orange'], .12), line_width=0)
        fig.add_scatter(x=n + n[::-1], y=[h for _, h in ci] + [l for l, _ in ci][::-1], fill='toself', fillcolor=ui.rgba(ACC, .14),
                        line_width=0, mode='lines', hoverinfo='skip', showlegend=False)
        for j, name, col, dash in [(1, 'train accuracy', C['slate'], 'dot'), (2, 'validation accuracy', ACC, None), (3, 'validation ROC-AUC', C['gold'], None)]:
            fig.add_scatter(x=n, y=[r[j] for r in lc], name=name, mode='lines+markers', line=dict(color=col, width=3, dash=dash), marker=dict(size=9))
        fig.update_xaxes(title='training videos per fold', tickvals=n)
        fig.update_yaxes(title='score', range=[0.6, 1.02])
        fig.update_layout(legend=dict(orientation='h', y=1.12, x=1, xanchor='right'))
        ui.show(fig, 340)
with c2:
    ui.callout('accuracy با ۱۲۰ ویدئو ۰.۶۴۴ است و با ۹۶۰ ویدئو به ۰.۷۴ می‌رسد؛ با ۲۴۰ ویدئو، یعنی اندازه‌ی کار نسخه‌های قبلی تیم، ۰.۶۸۲ است که با عددهای آن‌ها هم‌خوان است.', 'insight')
    ui.callout('accuracy روی train از ۱.۰ به ۰.۸۶ پایین می‌آید و فاصله با validation کم می‌شود. منحنی validation در ۹۶۰ هنوز صاف نشده؛ برای همین '
               'mirror augmentation کمک کرد و مدل‌های نهایی برای test روی همه‌ی ۱۲۰۰ ویدئو آموزش دیدند.', 'ok')
ui.code('vision_mil', [36, 37])

# ================================================================= comparison (a readable selection)
ui.section('10', 'Comparison With Earlier Models', 'منتخب ۱۳ مدل از ۴۲ مدل جدول کامل نوت‌بوک',
           'نسخه‌های قبلی تیم روی یک validation کوچک (۳۰ تا ۳۰۰ ویدئو) گزارش شده‌اند و با تقسیم دیگری؛ پس مستقیم هم‌سنگ نیستند. برای همین کنار هر accuracy '
           'بازه‌ی ۹۵٪ رسم شده: با ۶۰ ویدئو بازه حدود ۲۲ درصد پهنا دارد و بیشتر آن مدل‌ها از نظر آماری از هم قابل تشخیص نیستند.')
cmp = [  # model, accuracy, F1, AUC, videos evaluated, ours
    ('Ensemble · this project', 0.781, 0.773, 0.859, 1200, True), ('Tuned temporal model', 0.772, 0.761, 0.846, 1200, True),
    ('Motion + change · mirror', 0.760, 0.763, 0.834, 1200, True), ('Motion only', 0.732, 0.730, 0.810, 1200, True),
    ('Linear probe · all features', 0.699, 0.697, 0.779, 1200, True), ('First model · all features', 0.688, 0.670, 0.751, 1200, True),
    ('Metadata only', 0.619, None, 0.642, 1200, True),
    ('MViT-v2-S + attention MIL', 0.717, 0.679, 0.772, 60, False), ('MViT-v2-S + MIL · 3-seed ensemble', 0.700, 0.733, 0.766, 60, False),
    ('ResNet18 + BiLSTM · 3 seeds + TTA', 0.683, 0.655, 0.700, 60, False), ('Frozen VideoMAE V2 + LogReg', 0.653, 0.649, 0.719, 300, False),
    ('YOLOv8n + LSTM + attention', 0.633, 0.718, 0.796, 30, False), ('MobileNetV3-small + LSTM', 0.550, 0.571, 0.592, 60, False)]
cmp = sorted(cmp, key=lambda r: r[1])
with st.container(border=True):
    ui.sub('Accuracy with 95% interval', 'فیروزه‌ای: این پروژه، ۱۲۰۰ ویدئو با 5-fold CV · خاکستری: نسخه‌های قبلی تیم، عدد کنار نام = تعداد ویدئوی ارزیابی')
    fig = go.Figure()
    for ours, name, col in [(True, 'this project · 1200 dev videos', OURS), (False, 'earlier team models', TEAM)]:
        part = [r for r in cmp if r[5] == ours]
        lo_hi = [wilson(r[1], r[4]) for r in part]
        fig.add_scatter(x=[r[1] for r in part], y=[f'{r[0]}' + ('' if ours else f'  · n={r[4]}') for r in part], mode='markers', name=name,
                        marker=dict(size=13, color=col, line=dict(color=C['bg'], width=2)),
                        error_x=dict(type='data', symmetric=False, array=[h - r[1] for r, (l, h) in zip(part, lo_hi)],
                                     arrayminus=[r[1] - l for r, (l, h) in zip(part, lo_hi)], color=ui.rgba(col, .7), thickness=2.5, width=0),
                        customdata=[[r[2] if r[2] is not None else float('nan'), r[3], r[4]] for r in part],
                        hovertemplate='%{y}<br>accuracy %{x:.3f}<br>F1 %{customdata[0]:.3f} · AUC %{customdata[1]:.3f}<br>%{customdata[2]} videos<extra></extra>')
    order = [r[0] + ('' if r[5] else f'  · n={r[4]}') for r in cmp]
    fig.update_yaxes(categoryorder='array', categoryarray=order, tickfont=dict(size=12))
    fig.add_vrect(x0=0.78, x1=0.80, fillcolor=ui.rgba(C['green'], .12), line_width=0, annotation_text='target', annotation_position='top',
                  annotation_font=dict(color=C['green']))
    fig.update_xaxes(range=[0.35, 0.95], title='accuracy')
    fig.update_layout(legend=dict(orientation='h', y=1.08, x=1, xanchor='right'))
    ui.show(fig, 520)
c1, c2 = st.columns(2, gap='large')
with c1:
    ui.callout('<b>تفاوت‌های اصلی با نسخه‌های قبلی:</b> ۹۶۰ ویدئوی آموزشی در هر fold به‌جای ۲۴۰ تا ۴۵۰؛ ارزیابی روی ۱۲۰۰ ویدئو به‌جای ۶۰؛ پوشش کامل ویدئو هر ۰.۲ ثانیه '
               '(MViT هشت کلیپ ۳ ثانیه‌ای می‌دید و حدود یک‌سوم ویدئو دیده نمی‌شد)؛ ویژگی حرکتی صریح برای شبه‌تصادف‌ها.', 'insight')
with c2:
    ui.callout('<b>میان‌بُرها حذف شدند:</b> اثر انگشت ظاهری ویدئو، لبه‌های ویدئو و جایگاه زمانی. هیچ checkpoint یا آستانه‌ای روی validation انتخاب نشد و '
               'hyperparameter search هم با CV انجام شد.', 'ok')
ui.note('جدول کامل ۴۲ مدل (همه‌ی ablationها و نسخه‌های قبلی) در نوت‌بوک <code>accident_mil_model.ipynb</code> و صفحه‌ی Notebooks هست.')
ui.code('vision_mil', [40, 41])

# ================================================================= limits
ui.section('11', 'Limits & Next Step', 'محدودیت‌ها و قدم بعدی')
c1, c2, c3 = st.columns(3, gap='medium')
with c1:
    ui.callout('<b>حرکت هنوز میانگین کل تصویر است.</b> قدم بعدی محاسبه‌ی حرکت با RAFT در یک شبکه‌ی ۳×۳ از تصویر است (کجای تصویر حرکت هست)؛ '
               'استخراجش برای ۱۵۰۰ ویدئو روی Colab چند ساعت طول می‌کشد و در زمان پروژه انجام نشد.', 'info')
with c2:
    ui.callout('<b>test کوچک است.</b> ۳۰۰ ویدئو بازه‌ای حدود ۵± درصد دارد؛ اختلاف چند درصدی CV و test در همین بازه طبیعی است.', 'warn')
with c3:
    ui.callout('<b>شبه‌تصادف سخت است.</b> برچسب ۱ شامل تصادف و شبه‌تصادف است و در شبه‌تصادف خسارتی دیده نمی‌شود و مدل فقط از الگوی حرکت (ترمز یا انحراف ناگهانی) می‌تواند آن را بشناسد.', 'vision')
ui.note('مسئله‌ی امتیازی همین داده (پیش‌بینی برخورد قبل از وقوع، روی کلیپ‌های ۱۰ ثانیه‌ای رسمی) در صفحه‌ی Collision anticipation است.')
ui.footer()
