import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st
from plotly.subplots import make_subplots

from lib import ui
from lib.ui import C

ui.set_accent(C['red'], C['cyan'])
ui.hero('Vision · Bonus · New problem', 'Collision Anticipation',
        'مدلی که در هر لحظه فقط <b>۲ ثانیه‌ی آخر</b> ویدئو را ببیند و یک امتیاز خطر بدهد: آیا تا ۰.۵ تا ۱.۵ ثانیه‌ی دیگر تصادف رخ می‌دهد؟ ویژگی‌های یخ‌زده‌ی DINOv2 برای هر فریم، '
        'پنجره‌های خطر و منفی‌های سخت از خود ویدئوهای تصادف، انتخاب مدل با cross-validation گروهی روی ویدئوها، و ارزیابی روی <b>آزمون رسمی Nexar</b> با اسکریپت رسمی. '
        'از متادیتا (نور، آب‌وهوا، صحنه) فقط برای سنجیدن اینکه بدون دیدن تصویر چقدر امتیاز به دست می‌آید استفاده شد.',
        chips=['anticipation_model.ipynb', 'DINOv2-small · frozen', 'LightGBM + 1D CNN', 'official evaluate_submission.py'],
        accent=C['red'], accent2=C['cyan'])

ui.kpis([('0.75', 'mAP روی ۱۳۴۴ کلیپ آزمون رسمی', 'public ۰.۷۵۳ · private ۰.۷۵', C['cyan'], '🎯'),
         ('0.731', 'mAP در cross-validation', 'بازه‌ی ۹۵٪: ۰.۶۹۲ تا ۰.۷۷', C['sky'], '↻'),
         ('0.582', 'فقط متادیتا، بدون دیدن تصویر', 'تصویر mAP را ۰.۱۶ بالا می‌برد', C['slate'], '∅'),
         ('615 / h', 'هشدار اشتباه با recall ۸۰٪', 'محدودیت اصلی، صادقانه گزارش شد', C['red'], '⚠')], cols=4)

# ================================================================= framing
ui.section('01', 'How the Problem Is Framed', 'هر نمونه یک پنجره‌ی ۲ ثانیه‌ای (۲۰ فریم) است که در لحظه‌ی t تمام می‌شود')
ui.flow([('Frames · 10 fps', '۵۷۰٬۳۲۲ فریم از ۲۸۴۴ ویدئو'),
         ('DINOv2-small', 'CLS + میانگین patchهای ۴ ربع تصویر · ۵×۳۸۴'),
         ('PCA → 256', 'فقط روی ویدئوهای آموزشی هر fold'),
         ('2 s window', 'LightGBM روی فریم آخر + 1D CNN روی ۲۰ فریم'),
         ('Risk score', 'میانگین دو احتمال؛ آستانه برای هشدار')])
c1, c2 = st.columns([1.5, 1], gap='large')
with c1:
    with st.container(border=True):
        ui.sub('Window labels in one collision video', 'خطر از time_of_alert تا ۰.۳ ثانیه قبل از حادثه · یک ثانیه‌ی قبل از alert بدون برچسب')
        fw = ui.nbfig('vision_bonus/cell016_0.json')
        fig = go.Figure()
        kinds = {'risk': C['red'], 'hard negative': C['orange']}
        for tr in fw['data']:
            fig.add_scatter(x=tr['x'], y=tr['y'], mode='markers', name=tr['name'],
                            marker=dict(size=14, color=kinds.get(tr['name'], C['sky']), symbol='square', line=dict(color=C['bg'], width=2)),
                            hovertemplate='window ends at %{x:.2f} s<extra>' + tr['name'] + '</extra>')
        fig.add_vrect(x0=16.551, x1=17.551, fillcolor='rgba(148,163,184,.12)', line_width=0)
        fig.add_annotation(x=17.05, y=1.02, yref='paper', text='buffer', showarrow=False, font=dict(color=C['muted']))
        for x0, t, col in [(17.551, 'alert', C['orange']), (19.953, 'event', C['red'])]:
            fig.add_vline(x=x0, line_dash='dash', line_color=col)
            fig.add_annotation(x=x0, y=1.02, yref='paper', text=t, showarrow=False, font=dict(color=col))
        fig.update_xaxes(title='window end time (s)')
        fig.update_layout(showlegend=False)
        ui.show(fig, 260)
with c2:
    with st.container(border=True):
        ui.sub('Training windows', '۱۸٬۷۸۲ پنجره از ۱۵۰۰ ویدئو')
        ui.donut([('risk', 5295, C['red']), ('hard negative', 4494, C['orange']), ('normal driving', 8993, C['sky'])], height=260, key='vb_win',
                 center='28%', center_sub='risk windows', fmt='{b}\n{c}')
ui.callout('<b>منفی سخت</b> از خود ویدئوی تصادف و قبل از هشدار برداشته می‌شود: صحنه همان صحنه‌ی پنجره‌های خطر است، پس نوع جاده سرنخ نمی‌شود. ارزیابی دقیقاً قاعده‌ی '
           'آزمون رسمی را دنبال می‌کند: پنجره‌ای که Δ ثانیه (۰.۵، ۱ یا ۱.۵) قبل از حادثه تمام می‌شود، و برای رانندگی عادی یک زمان حادثه‌ی ساختگی از توزیع زمان‌های واقعی. '
           'در آزمون، <code>time_of_event</code> فقط برای کلیپ‌های مثبت مقدار دارد، پس به‌تنهایی برچسب را لو می‌دهد و هیچ‌جا استفاده نشد.', 'leak')
ui.code('vision_bonus', [3, 4, 6, 15, 16, 19])

# ================================================================= checks
ui.section('02', 'Data Checks', 'ویدئوهای تکراری و تغییر فریم‌ها پیش از حادثه')
c1, c2 = st.columns(2, gap='large')
with c1:
    with st.container(border=True):
        ui.sub('Duplicate videos?', 'شباهت شبیه‌ترین ثانیه‌ها · مرز «صحنه‌ی یکسان» = صدک ۱ کلیپ‌های یک ویدئوی آزمون')
        fd = ui.nbfig('vision_bonus/cell009_0.json')['data']
        fig = go.Figure()
        for tr, col in zip(fd, [C['gold'], C['sky'], C['violet']]):
            fig.add_histogram(x=tr['x'], name=tr['name'], marker_color=col, opacity=.65, histnorm='percent', xbins=dict(start=.6, end=1.0, size=.005))
        fig.add_vline(x=0.987, line_dash='dash', line_color=C['red'])
        fig.add_annotation(x=0.987, y=1, yref='paper', text='0.99', showarrow=False, xanchor='right', font=dict(color=C['red']))
        fig.update_layout(barmode='overlay', legend=dict(orientation='h', y=-0.25, x=1, xanchor='right'))
        fig.update_xaxes(title='cosine similarity of the best-matching second', range=[0.7, 1.0])
        fig.update_yaxes(title='% of pairs')
        ui.show(fig, 340)
        ui.note('فقط یک جفت تکراری در train پیدا شد (۰۰۷۸۸ و ۰۰۷۸۹، شباهت ۱.۰۰) و در یک fold قرار گرفت. بیشترین شباهت آزمون به train ۰.۹۵ است: صحنه‌ی مشترکی نیست.')
with c2:
    with st.container(border=True):
        ui.sub('Frame-to-frame change of the CLS vector', 'میانگین روی ۷۳۹ ویدئوی تصادف و ۶۵۰ ویدئوی عادی')
        fc = ui.nbfig('vision_bonus/cell012_0.json')['data']
        fig = go.Figure()
        for tr, col in zip(fc, [C['red'], C['sky']]):
            fig.add_scatter(x=tr['x'], y=tr['y'], name=tr['name'], mode='lines', line=dict(color=col, width=3, shape='spline'))
        fig.add_vline(x=0, line_dash='dash', line_color=C['red'])
        fig.add_vline(x=-1.433, line_dash='dash', line_color=C['orange'])
        fig.add_annotation(x=0, y=1, yref='paper', text='event', showarrow=False, xanchor='left', font=dict(color=C['red']))
        fig.add_annotation(x=-1.433, y=1, yref='paper', text='median alert', showarrow=False, xanchor='right', font=dict(color=C['orange']))
        fig.update_xaxes(title='seconds from the event')
        fig.update_yaxes(title='1 − cosine similarity')
        fig.update_layout(legend=dict(orientation='h', y=-0.25, x=1, xanchor='right'))
        ui.show(fig, 340)
        ui.note('در ویدئوهای تصادف تغییر فریم‌ها با نزدیک شدن به حادثه ۳۶٪ زیاد می‌شود، ولی سطح پایه‌ی ویدئوهای عادی بالاتر است؛ پس مقدار تغییر به‌تنهایی کافی نیست و '
                '<b>افزایش نسبت به ثانیه‌های قبلِ همان ویدئو</b> مهم است — دلیل دیگر برای منفی‌های سخت.')
ui.code('vision_bonus', [9, 12, 22])

# ================================================================= models
ui.section('03', 'Model Comparison', 'cross-validation پنج‌تایی روی ویدئوها · mAP = معیار رسمی چالش (میانگین AP سه Δ)')
c1, c2 = st.columns([1.3, 1], gap='large')
with c1:
    with st.container(border=True):
        ui.sub('Cross-validation mAP', 'بازه‌ی ۹۵٪ با bootstrap روی ویدئوها، نه پنجره‌ها')
        fm = ui.nbfig('vision_bonus/cell032_0.json')['data'][0]
        names = fm['y']
        colors = [C['slate'] if 'metadata' in n else (C['red'] if '+' in n else C['cyan']) for n in names]
        fig = go.Figure(go.Bar(x=fm['x'], y=names, orientation='h', marker_color=colors, marker_cornerradius=5,
                               error_x=dict(type='data', array=fm['error_x']['array'], arrayminus=fm['error_x']['arrayminus'], color=C['text2'], thickness=1.4),
                               text=[f'{ui.fx(v)}' for v in fm['x']], textposition='inside', insidetextanchor='end', textfont=dict(color='#060912'),
                               hovertemplate='%{y}: %{x:.3f}<extra></extra>'))
        fig.add_vline(x=0.5, line_dash='dot', line_color=C['muted'])
        fig.add_annotation(x=0.5, y=1, yref='paper', text='random 0.5', showarrow=False, xanchor='left', font=dict(color=C['muted']))
        fig.update_xaxes(range=[0.4, 0.82], title='mAP')
        ui.show(fig, 380)
with c2:
    with st.container(border=True):
        ui.sub('Overall vs same-video test', 'AUC داخل یک ویدئو: پنجره‌های خطر در برابر منفی‌های سختِ همان ویدئو')
        fs = ui.nbfig('vision_bonus/cell032_1.json')['data']
        fig = go.Figure()
        for tr in fs:
            n = tr['name']
            col = C['slate'] if 'metadata' in n else (C['red'] if '+' in n else C['cyan'])
            fig.add_scatter(x=tr['x'], y=tr['y'], mode='markers+text', text=[n.replace('LightGBM, ', 'LGBM · ')], textposition='top center',
                            marker=dict(size=16, color=col, line=dict(color=C['bg'], width=2)), textfont=dict(size=10, color=C['text2']),
                            showlegend=False, hovertemplate=n + '<br>same-video AUC %{x:.3f}<br>mAP %{y:.3f}<extra></extra>')
        fig.add_vline(x=0.5, line_dash='dot', line_color=C['muted'])
        fig.update_xaxes(range=[0.45, 0.75], title='same-video AUC')
        fig.update_yaxes(range=[0.54, 0.76], title='mAP')
        ui.show(fig, 380)
ui.callout('ترکیب «LightGBM روی فریم آخر» و 1D CNN بهترین است (۰.۷۳۱). فریم آخر از میانگین ۲۰ فریم بهتر است چون میانگین وضع لحظه‌ی آخر را محو می‌کند. مدل متادیتا '
           'به همه‌ی پنجره‌های یک ویدئو یک امتیاز می‌دهد، پس AUC داخل ویدئو برایش دقیقاً ۰.۵ است؛ مدل‌های تصویری ۰.۵۶ تا ۰.۶۹ می‌گیرند، یعنی بخشی از <b>خودِ خطر</b> را می‌بینند. '
           'فاصله‌ی پنج مدل اول از پهنای بازه‌ها کمتر است. طول پنجره (۱، ۲ و ۳ ثانیه) با قاعده‌ای از پیش ثابت سنجیده شد و ۲ ثانیه ماند.', 'insight')
ui.code('vision_bonus', [24, 26, 27, 29, 31, 32, 35])

# ================================================================= replay
ui.section('04', 'Risk Replay', 'منحنی خطر هشت ویدئوی نمونه (out-of-fold) — دکمه‌ی ▶ را بزن')
fr = ui.nbfig('vision_bonus/cell047_0.json')
titles = [a['text'] for a in fr['layout']['annotations']]
shapes = fr['layout']['shapes']
thr = {}
marks = {}
for s in shapes:
    axis = s.get('yref', '').split()[0] if s.get('xref', '').endswith('domain') else None
    if axis:
        thr[axis] = s['y0']
    else:
        marks.setdefault(s['xref'], []).append(s['x0'])
videos = []
for k, tr in enumerate(fr['data']):
    ax = 'y' if k == 0 else f'y{k + 1}'
    xa = 'x' if k == 0 else f'x{k + 1}'
    videos.append(dict(name=titles[k], x=tr['x'], y=tr['y'], thr=thr.get(ax, 0.2), alert=(marks.get(xa) or [None])[0],
                       event=(marks.get(xa) or [None, None])[-1] if marks.get(xa) else None))
labels = [v['name'] for v in videos]
pick = st.segmented_control('video', labels, default='collision 00872', label_visibility='collapsed', key='vb_video')
v = videos[labels.index(pick or 'collision 00872')]
xs, ys = np.array(v['x']), np.array(v['y'])
step = max(1, len(xs) // 60)
idx = list(range(0, len(xs), step)) + ([len(xs) - 1] if (len(xs) - 1) % step else [])
color = C['red'] if v['name'].startswith('collision') else C['cyan']

fig = go.Figure()


def gauge_trace(val):
    return go.Indicator(mode='gauge+number', value=val, number=dict(font=dict(size=40, color=C['text']), valueformat='.2f'),
                        gauge=dict(axis=dict(range=[0, 1], tickcolor=C['muted'], tickfont=dict(color=C['muted'])),
                                   bar=dict(color=C['red'] if val >= v['thr'] else C['cyan'], thickness=0.32),
                                   bgcolor='rgba(148,163,184,.08)', borderwidth=0,
                                   steps=[dict(range=[0, v['thr']], color='rgba(34,211,238,.10)'), dict(range=[v['thr'], 1], color='rgba(244,63,94,.12)')],
                                   threshold=dict(line=dict(color=C['gold'], width=4), thickness=0.85, value=v['thr'])),
                        title=dict(text='risk score', font=dict(color=C['text2'], size=13)), domain=dict(x=[0, 0.28], y=[0, 1]))


fig.add_trace(gauge_trace(float(ys[0])))
fig.add_scatter(x=xs, y=ys, mode='lines', line=dict(color='rgba(163,172,198,.25)', width=2), hoverinfo='skip', showlegend=False)
fig.add_scatter(x=xs[:1], y=ys[:1], mode='lines', line=dict(color=color, width=3.5), fill='tozeroy', fillcolor=ui.rgba(color, .12),
                showlegend=False, hovertemplate='t %{x:.1f}s · risk %{y:.3f}<extra></extra>')
fig.add_scatter(x=xs[:1], y=ys[:1], mode='markers', marker=dict(size=14, color=color, line=dict(color='#fff', width=2)), showlegend=False,
                hoverinfo='skip')
fig.add_hline(y=v['thr'], line_dash='dot', line_color=C['gold'])
fig.add_annotation(x=xs[0], y=v['thr'], text=f"threshold {v['thr']:.2f}", showarrow=False, yshift=10, xanchor='left', font=dict(color=C['gold']))
if v['alert'] is not None and v['name'].startswith('collision'):
    for x0, t, col, anchor in [(v['alert'], 'alert', C['orange'], 'right'), (v['event'], 'event', C['red'], 'left')]:
        fig.add_vline(x=x0, line_dash='dash', line_color=col)
        fig.add_annotation(x=x0, y=1.0, text=t, showarrow=False, yshift=8, xanchor=anchor, font=dict(color=col))
frames = []
for i in idx:
    frames.append(go.Frame(name=f'{xs[i]:.1f}', data=[gauge_trace(float(ys[i])), go.Scatter(x=xs, y=ys),
                                                       go.Scatter(x=xs[:i + 1], y=ys[:i + 1]), go.Scatter(x=[xs[i]], y=[ys[i]])],
                           traces=[0, 1, 2, 3]))
fig.frames = frames
fig.update_xaxes(range=[0, float(xs.max()) + 0.5], title='time in the video (s)', domain=[0.36, 1])
fig.update_yaxes(range=[0, 1.05], title='risk')
fig.update_layout(
    updatemenus=[dict(type='buttons', showactive=False, x=0.0, y=-0.08, xanchor='left', yanchor='top', direction='left', bgcolor='#0f1628',
                      bordercolor='#26304f', font=dict(color=C['text']),
                      buttons=[dict(label='▶ play', method='animate', args=[None, dict(frame=dict(duration=90, redraw=True), fromcurrent=True,
                                                                                         transition=dict(duration=0))]),
                               dict(label='❚❚ pause', method='animate', args=[[None], dict(frame=dict(duration=0, redraw=False), mode='immediate')])])],
    sliders=[dict(active=0, x=0.36, y=-0.08, len=0.64, yanchor='top', currentvalue=dict(prefix='t = ', suffix=' s', font=dict(color=C['text2'])),
                  bgcolor='#1c2540', activebgcolor=color, bordercolor='#26304f', tickcolor=C['muted'], font=dict(color=C['muted'], size=9),
                  steps=[dict(method='animate', label=f.name, args=[[f.name], dict(mode='immediate', frame=dict(duration=0, redraw=True))])
                         for f in frames])],
    margin=dict(l=10, r=10, t=30, b=90))
with st.container(border=True):
    ui.show(fig, 430, key=f'replay_{pick}')
notes = {'collision 00872': 'تنها نمونه با شکل مورد انتظار: تا نزدیک alert پایین است و بعد تا لحظه‌ی حادثه بالا می‌رود.',
         'collision 00227': 'امتیاز از ابتدای ویدئو بالای آستانه است و نزدیک alert بیشتر نمی‌شود.',
         'collision 00713': 'امتیاز از ابتدا بالاست؛ سطح امتیاز به خود ویدئو بستگی دارد.',
         'collision 00754': 'چند ثانیه قبل از alert به آستانه می‌رسد و نزدیک آن می‌ماند.',
         'normal 01372': 'همیشه زیر آستانه — رفتار درست برای رانندگی عادی.', 'normal 01875': 'همیشه زیر آستانه.',
         'normal 01849': 'یک جهش کوتاه حدود ثانیه‌ی ۲۰.', 'normal 01071': 'در نیمه‌ی اول ویدئو بیشتر بالای آستانه است — یک هشدار اشتباه.'}
ui.callout(notes.get(v['name'], '') + ' هشت ویدئو نمونه‌ی کوچکی است، ولی بخش‌های بعد همین الگو را روی همه‌ی ویدئوها نشان می‌دهند: '
           '<b>سطح امتیاز بیشتر به خود ویدئو بستگی دارد تا به لحظه‌ی خطر.</b>', 'vision')
ui.code('vision_bonus', [38, 47])

# ================================================================= reaction + alert
ui.section('05', 'How Early, Compared to Humans?', 'AP برای δ از ۰.۲ تا ۳ ثانیه قبل از حادثه، و مقایسه با لحظه‌ی هشدار برچسب‌زن‌ها')
c1, c2 = st.columns(2, gap='large')
with c1:
    with st.container(border=True):
        ui.sub('AP by time before the event', 'بازه‌ی ۹۵٪ با bootstrap · در δ بزرگ ویدئوی کمتری می‌ماند')
        fa_ = ui.nbfig('vision_bonus/cell041_0.json')['data']
        fig = go.Figure()
        fig.add_scatter(x=fa_[0]['x'], y=fa_[0]['y'], line=dict(width=0), showlegend=False, hoverinfo='skip')
        fig.add_scatter(x=fa_[1]['x'], y=fa_[1]['y'], line=dict(width=0), fill='tonexty', fillcolor=ui.rgba(C['cyan'], .15), name='95% interval',
                        hoverinfo='skip')
        fig.add_scatter(x=fa_[2]['x'], y=fa_[2]['y'], mode='lines+markers', name='AP', line=dict(color=C['cyan'], width=3),
                        marker=dict(size=6), customdata=fa_[2]['customdata'],
                        hovertemplate='δ %{x} s<br>AP %{y:.3f}<br>%{customdata} collisions<extra></extra>')
        fig.add_hline(y=0.5, line_dash='dot', line_color=C['muted'])
        for d in [0.5, 1.0, 1.5]:
            fig.add_vline(x=d, line_color='rgba(244,63,94,.35)', line_dash='dot')
        fig.update_xaxes(title='seconds before the event (δ)')
        fig.update_yaxes(range=[0.45, 0.92], title='AP')
        fig.update_layout(legend=dict(orientation='h', y=1.12, x=1, xanchor='right'))
        ui.show(fig, 340)
with c2:
    with st.container(border=True):
        ui.sub('Collision videos above the threshold, aligned on the human alert', 'خط نقطه‌چین = همین سهم در رانندگی عادی')
        fh = ui.nbfig('vision_bonus/cell050_0.json')['data'][0]
        fig = go.Figure(go.Scatter(x=fh['x'], y=fh['y'], mode='lines+markers', line=dict(color=C['red'], width=3), marker=dict(size=5),
                                   fill='tozeroy', fillcolor=ui.rgba(C['red'], .1), customdata=[c[0] for c in fh['customdata']],
                                   hovertemplate='%{x:+.1f} s from alert<br>%{y:.1%} above threshold<br>%{customdata} videos<extra></extra>'))
        fig.add_hline(y=0.384, line_dash='dot', line_color=C['cyan'])
        fig.add_annotation(x=-8, y=0.384, text='normal driving 38.4%', showarrow=False, yshift=10, xanchor='left', font=dict(color=C['cyan']))
        fig.add_vline(x=0, line_dash='dash', line_color=C['orange'])
        fig.add_vline(x=1.433, line_dash='dash', line_color=C['red'])
        fig.update_xaxes(title='seconds from the human alert')
        fig.update_yaxes(range=[0, 1], tickformat='.0%')
        ui.show(fig, 340)
ui.callout('از ۰.۲ تا ۱.۵ ثانیه AP بین ۰.۷۳ و ۰.۷۴۲ می‌ماند و با نزدیک شدن به حادثه زیاد نمی‌شود. ۸ تا ۳ ثانیه قبل از alert، ۶۴٪ نقطه‌های ویدئوهای تصادف بالای آستانه‌اند، '
           'در برابر ۳۸٪ رانندگی عادی؛ یعنی بیشتر فرق دو دسته <b>چند ثانیه قبل از خطر هم وجود دارد</b> و به خود ویدئو مربوط است. از ~۲.۵ ثانیه قبل از alert سهم کمی بالا می‌رود.', 'insight')
ui.code('vision_bonus', [41, 50])

# ================================================================= conditions + alarms
ui.section('06', 'Alarm Threshold and Conditions', 'آستانه طوری که ۸۰٪ پنجره‌های تصادف در ۱ ثانیه قبل از حادثه به آن برسند')
c1, c2 = st.columns([1, 1.25], gap='large')
with c1:
    with st.container(border=True):
        ui.sub('Recall vs false alarms per hour', 'هشدار بعدی فقط وقتی شمرده می‌شود که ۳ ثانیه بعد باشد')
        ft = ui.nbfig('vision_bonus/cell044_0.json')['data']
        fig = go.Figure()
        fig.add_scatter(x=ft[0]['x'], y=ft[0]['y'], mode='lines+markers', line=dict(color=C['cyan'], width=3), marker=dict(size=7),
                        hovertemplate='%{x:.0f} false alarms / h<br>recall %{y:.0%}<extra></extra>', showlegend=False)
        fig.add_scatter(x=ft[1]['x'], y=ft[1]['y'], mode='markers+text', text=['chosen · 615/h'], textposition='middle left',
                        marker=dict(size=20, color=C['gold'], symbol='star', line=dict(color=C['bg'], width=2)), textfont=dict(color=C['gold']),
                        showlegend=False)
        fig.update_xaxes(title='false alarms per hour of normal driving')
        fig.update_yaxes(title='recall at 1 s', tickformat='.0%')
        ui.show(fig, 330)
        ui.note('حتی با recall ۳۰٪ بیش از ۱۰۰ هشدار اشتباه در ساعت داده می‌شود. mAP حدود ۰.۷۳ هنوز با یک سیستم هشدار قابل استفاده فاصله‌ی زیادی دارد.')
with c2:
    with st.container(border=True):
        ui.sub('Share above the threshold 1 s before the event, by condition', 'دو سهم را با هم بخوان: recall تصادف و هشدار در رانندگی عادی')
        fcd = ui.nbfig('vision_bonus/cell053_0.json')['data']
        fig = make_subplots(rows=1, cols=3, shared_yaxes=True, subplot_titles=['light', 'weather', 'scene'], horizontal_spacing=0.04)
        for k, tr in enumerate(fcd):
            col_i = k // 2 + 1
            is_col = 'collision' in tr['name']
            fig.add_scatter(x=tr['x'], y=tr['y'], mode='markers', name=tr['name'], legendgroup=tr['name'], showlegend=k < 2,
                            marker=dict(size=12, color=C['red'] if is_col else C['cyan'], line=dict(color=C['bg'], width=2)),
                            error_y=dict(type='data', array=tr['error_y']['array'], arrayminus=tr['error_y']['arrayminus'],
                                         color=ui.rgba(C['red'] if is_col else C['cyan'], .45), thickness=1.5, width=0),
                            customdata=tr['customdata'], hovertemplate='%{x}: %{y:.0%} (n=%{customdata})<extra></extra>', row=1, col=col_i)
        fig.update_yaxes(range=[0, 1.05], tickformat='.0%')
        fig.update_annotations(font=dict(color=C['text2']))
        fig.update_layout(legend=dict(orientation='h', y=-0.18, x=1, xanchor='right'))
        ui.show(fig, 360)
ui.callout('در Urban هر دو سهم بالاست (عادی ۰.۵۱، تصادف ۰.۸۶) و در Sub-urban هر دو پایین (۰.۱۴ و ۰.۵۲)؛ Rain و Dark هم همین الگو را دارند. پس سطح امتیاز با صحنه و شرایط '
           'جابه‌جا می‌شود و مدل بخشی از <b>خودِ شرایط</b> را می‌بیند، نه فقط خطر را. بیشینه‌ی منحنی هم لحظه‌ی حادثه را خوب نمی‌شناسد: میانه‌ی خطا ۱.۴۷ ثانیه، '
           'در برابر ۰.۶۰ برای پایه‌ی ساده‌ی «همیشه میانه‌ی زمان حادثه».', 'warn')
c1, c2 = st.columns(2, gap='large')
with c1:
    with st.container(border=True):
        ui.sub('Estimated event time error', 'بیشینه‌ی منحنی در برابر پایه‌ی میانه')
        fe = ui.nbfig('vision_bonus/cell056_0.json')['data']
        fig = go.Figure()
        for tr, col in zip(fe, [C['red'], C['slate']]):
            fig.add_histogram(x=np.clip(tr['x'], -10, 10), name=tr['name'], marker_color=col, opacity=.6, xbins=dict(start=-10, end=10.2, size=0.4))
        fig.add_vline(x=0, line_dash='dash', line_color=C['text2'])
        fig.update_layout(barmode='overlay', legend=dict(orientation='h', y=1.12, x=1, xanchor='right'))
        fig.update_xaxes(title='estimate − time_of_event (s)')
        ui.show(fig, 300)
with c2:
    with st.container(border=True):
        ui.sub('Why the CNN trains for 1 epoch', 'میانگین پنج fold بعد از هر epoch')
        fe2 = ui.nbfig('vision_bonus/cell059_0.json')['data']
        fig = go.Figure()
        for tr, col in zip(fe2, [C['gold'], C['cyan'], C['violet']]):
            fig.add_scatter(x=tr['x'], y=tr['y'], name=tr['name'], mode='lines+markers', line=dict(color=col, width=3), marker=dict(size=7))
        fig.update_layout(legend=dict(orientation='h', y=1.14, x=1, xanchor='right'))
        fig.update_xaxes(title='epoch', dtick=1)
        ui.show(fig, 300)
        ui.note('با آموزش بیشتر mAP دسته‌ی کنار گذاشته پایین می‌آید (۰.۷۴ → ۰.۶۹) در حالی که AUC داخل ویدئو بالا می‌رود: مدل منفی‌های سخت را بهتر جدا می‌کند ولی '
                'مقایسه‌ی ویدئوهای مختلف بدتر می‌شود.')
ui.code('vision_bonus', [44, 53, 56, 59])

# ================================================================= official test
ui.section('07', 'Official Nexar Test', '۱۳۴۴ کلیپ ~۱۰ ثانیه‌ای · مدل فقط ۲۰ فریم آخر هر کلیپ را می‌بیند · اسکریپت رسمی همان عدد را داد')
c1, c2, c3 = st.columns(3, gap='medium')
with c1:
    with st.container(border=True):
        ui.gauge(0.753, 'test-public mAP', lo=0.4, hi=1.0, color=C['cyan'], decimals=3, height=240, key='vb_pub', sub='95% interval 0.68 – 0.83')
with c2:
    with st.container(border=True):
        ui.gauge(0.748, 'test-private mAP', lo=0.4, hi=1.0, color=C['sky'], decimals=3, height=240, key='vb_priv', sub='95% interval 0.67 – 0.84')
with c3:
    with st.container(border=True):
        ui.gauge(0.767, 'test (all) ROC-AUC', lo=0.4, hi=1.0, color=C['violet'], decimals=3, height=240, key='vb_auc', sub='mAP 0.75 on all 1,344 clips')
c1, c2 = st.columns([1.1, 1], gap='large')
with c1:
    with st.container(border=True):
        ui.sub('Cross-validation vs official test', 'mAP با بازه‌ی ۹۵٪ · bootstrap روی ویدئوهای منبع')
        fo = ui.nbfig('vision_bonus/cell068_0.json')['data']
        fig = go.Figure()
        for tr, col in zip(fo, [C['cyan'], C['slate']]):
            fig.add_bar(x=tr['x'], y=tr['y'], name=tr['name'], marker_color=col, marker_cornerradius=6,
                        error_y=dict(type='data', array=tr['error_y']['array'], arrayminus=tr['error_y']['arrayminus'], color=C['text2'], thickness=1.3),
                        text=[f'{ui.fx(v)}' for v in tr['y']], textposition='inside', insidetextanchor='end', textfont=dict(color='#060912'))
        fig.add_hline(y=0.5, line_dash='dot', line_color=C['muted'])
        fig.update_layout(barmode='group', legend=dict(orientation='h', y=1.14, x=1, xanchor='right'))
        fig.update_yaxes(range=[0.4, 0.9], title='mAP')
        ui.show(fig, 340)
with c2:
    with st.container(border=True):
        ui.sub('Leaderboard on the same 1,344 clips', 'عددهای منتشرشده · AP مقاله‌ی BADAS ممکن است با mAP رسمی یکی نباشد')
        board = [('BADAS-Open (V-JEPA2, fine-tuned)', 0.86, C['violet']), ('VideoMAE-2 Large · Kaggle #11', 0.80, C['violet']),
                 ('Ours · DINOv2 + LGBM + 1D CNN', 0.746, C['cyan']), ('Industrial FCW system', 0.58, C['slate']),
                 ('Open academic models', 0.53, C['slate'])]
        ui.hbar_race([(n, v, c) for n, v, c in board], height=300, key='vb_board', xmin=0.3, xmax=0.95)
        ui.note('منبع‌ها در نوت‌بوک: Goldshmidt و همکاران (BADAS، arXiv:2510.14876)، Moura و همکاران (Nexar dataset، arXiv:2503.03848)، کارت مدل VideoMAE-2 در Hugging Face. '
                'مدل‌های بالاتر یک شبکه‌ی ویدئویی را end-to-end fine-tune می‌کنند؛ اینجا DINOv2 یخ‌زده است و هر فریم را جدا می‌بیند.')
with st.container(border=True):
    ui.sub('Final model scores on the official test clips', 'خط زرد = آستانه‌ی ثابت ۰.۲۰، قبل از دیدن آزمون')
    fh2 = ui.nbfig('vision_bonus/cell071_0.json')['data']
    fig = go.Figure()
    for tr, col in zip(fh2, [C['red'], C['cyan']]):
        fig.add_histogram(x=tr['x'], name=tr['name'], marker_color=col, opacity=.6, nbinsx=50)
    fig.add_vline(x=0.1989, line_dash='dash', line_color=C['gold'])
    fig.update_layout(barmode='overlay', legend=dict(orientation='h', y=1.12, x=1, xanchor='right'))
    fig.update_xaxes(title='risk score')
    ui.show(fig, 280)
ui.callout('mAP آزمون (۰.۷۵) کمی بیشتر از عدد cross-validation (۰.۷۳۱) و داخل بازه‌ی آن است، پس cross-validation خوش‌بینانه نبود. ولی آستانه‌ی پنج fold روی مدل نهایی '
           '<b>منتقل نمی‌شود</b>: recall آزمون در ۱ ثانیه ۸۶ تا ۹۰٪ شد و سهم کلیپ‌های عادیِ بالای آستانه ~۵۴٪، در برابر ۸۰٪ و ۳۸٪ در cross-validation. طبق قاعده آستانه '
           'بعد از دیدن آزمون عوض نشد؛ برای سیستم واقعی باید با خود مدل نهایی روی داده‌ی جدا تعیین شود.', 'warn')
ui.code('vision_bonus', [62, 65, 68, 71])

ui.section('!', 'Limitations', 'محدودیت‌ها — همان‌طور که در نوت‌بوک آمده')
lim = [('Video-level signal', 'مدل متادیتا بدون دیدن تصویر ۰.۵۸ می‌گیرد؛ امتیاز بیشتر به خود ویدئو وابسته است تا لحظه‌ی خطر.', C['red']),
       ('False alarms', '۶۱۵ هشدار اشتباه در ساعت با recall ۸۰٪ در ۱ ثانیه.', C['orange']),
       ('Frozen features', 'DINOv2-small یخ‌زده، فریم به فریم؛ PCA، شبکه‌ها و LightGBM تنظیم نشده‌اند.', C['gold']),
       ('Small test', 'هر زیرمجموعه فقط ۱۴۲ ویدئوی منبع از هر برچسب دارد؛ بازه‌ها ۰.۱۵ تا ۰.۱۷ پهنا دارند.', C['sky']),
       ('Labels', 'تصادف و نزدیک به تصادف هر دو ۱ هستند؛ time_of_alert دومین زمان دیرتر بین ۱۰ برچسب‌زن است.', C['violet']),
       ('Frame rate shift', 'سهم ویدئوهای ۳۰ fps در آزمون برای کلیپ‌های عادی بیشتر است؛ این فرق در train نیست.', C['pink'])]
st.html('<div class="kpis" style="grid-template-columns: repeat(3, 1fr)">' + ''.join(
    f'<div class="kpi" style="--c:{c}"><b style="font-size:1.05rem">{t}</b><span>{d}</span></div>' for t, d, c in lim) + '</div>')
ui.footer()
