import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st
from plotly.subplots import make_subplots
from sklearn.metrics import precision_recall_curve, roc_curve

from lib import ui
from lib.ui import C, fa

ACC, ACC2 = C['teal'], C['sky']
MODELS = ['length-only', 'tfidf + LR', 'transformer', 'stacked']
MCOL = {'length-only': C['slate'], 'tfidf + LR': C['orange'], 'transformer': C['violet'], 'stacked': C['teal']}
VAL = {'AUC': [0.6986, 0.7135, 0.7273, 0.7306], 'PR-AUC': [0.4269, 0.4517, 0.4523, 0.4667]}
TEST = {'AUC': [0.6986, 0.7150, 0.7291, 0.7326], 'PR-AUC': [0.4488, 0.4728, 0.4758, 0.4917], 'lift': [2.2137, 2.3738, 2.3839, 2.4083]}
BASE_VAL, BASE_TEST, THR = 0.2272, 0.24665, 0.239

# per-month AUC on the labelled test set (notebook cell 19)
MONTHS = pd.DataFrame([
    ('2016-01', 1113, .278, .7622, .7587), ('2016-02', 947, .279, .6893, .6953), ('2016-03', 949, .281, .7217, .7349),
    ('2016-04', 919, .329, .7372, .7448), ('2016-05', 969, .284, .7661, .7638), ('2016-06', 885, .284, .7430, .7453),
    ('2016-07', 923, .282, .7465, .7448), ('2016-08', 983, .264, .7598, .7587), ('2016-09', 870, .277, .6657, .6763),
    ('2016-10', 808, .298, .7466, .7493), ('2016-11', 692, .275, .7222, .7239), ('2016-12', 841, .234, .7303, .7378),
    ('2017-01', 833, .250, .7490, .7507), ('2017-02', 660, .247, .7070, .7025), ('2017-03', 693, .287, .6996, .7013),
    ('2017-04', 592, .294, .7146, .7238), ('2017-05', 545, .251, .7196, .7235), ('2017-06', 495, .299, .6792, .6813),
    ('2017-07', 487, .211, .6835, .6927), ('2017-08', 490, .220, .7382, .7419), ('2017-09', 435, .205, .7211, .7314),
    ('2017-10', 436, .202, .7473, .7400), ('2017-11', 399, .185, .7201, .7265), ('2017-12', 416, .212, .7100, .7052),
    ('2018-01', 479, .196, .7437, .7552), ('2018-02', 384, .125, .7266, .7496), ('2018-03', 403, .119, .7811, .7756),
    ('2018-04', 361, .114, .7378, .7289)], columns=['month', 'n', 'pos_rate', 'auc_trf', 'auc_stack'])


@st.cache_data
def predictions():
    d = pd.read_csv(ui.DATA / 'bonus_helpful/helpful_predictions.csv')
    return d['helpful_prob'].to_numpy(), d['actual_helpful'].to_numpy()


@st.cache_data
def curves():
    p, y = predictions()
    fpr, tpr, _ = roc_curve(y, p)
    prec, rec, _ = precision_recall_curve(y, p)
    order = np.argsort(-p)
    gains = np.concatenate([[0], np.cumsum(y[order]) / y.sum()])
    frac = np.arange(len(gains)) / len(p)
    keep = np.linspace(0, len(gains) - 1, 400).astype(int)
    return fpr, tpr, prec, rec, frac[keep], gains[keep]


def at_threshold(t):
    p, y = predictions()
    pred = p >= t
    tp = int((pred & (y == 1)).sum()); fp = int((pred & (y == 0)).sum())
    fn = int((~pred & (y == 1)).sum()); tn = int((~pred & (y == 0)).sum())
    precision = tp / (tp + fp) if tp + fp else 0.0
    recall = tp / (tp + fn)
    f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.0
    return dict(tp=tp, fp=fp, fn=fn, tn=tn, precision=precision, recall=recall, f1=f1, share=pred.mean(),
                fpr=fp / (fp + tn), acc=(tp + tn) / len(y))


ui.set_accent(ACC, ACC2)
ui.hero('NLP · Bonus · New problem', 'Review Helpfulness',
        'کدام نظرها برای بقیه‌ی خریدارها <b>مفید</b> از آب درمی‌آیند؟ برچسب: نظری که حداقل ۲ رأی helpful گرفته (<code>vote ≥ 2</code>). '
        'مدل فقط <b>متن نظر</b> را می‌بیند؛ شناسه‌ی محصول و زمان هیچ‌وقت ورودی مدل نیستند و فقط برای پیدا کردن علت خطاها به کار رفته‌اند. '
        'انتخاب مدل، آستانه و stacker روی validation انجام شد و test برچسب‌دار <b>فقط یک بار</b>، برای گزارش نهایی، استفاده شد.',
        chips=['bonus_helpfulness.ipynb · v3', 'DistilRoBERTa · 1 epoch', 'stacking · 5-fold OOF', 'train 300k · val 40k · test 20k'],
        accent=ACC, accent2=ACC2)

ui.kpis([
    ('0.733', 'AUC مدل stacked روی test', 'ترنسفورمر به‌تنهایی: ۰.۷۳', ACC, '🎯'),
    ('0.492', 'PR-AUC روی test', 'حدس تصادفی: ۰.۲۵ · حدود دو برابر', C['sky'], '📈'),
    ('×2.41', 'lift در ۱۰٪ بالای رتبه‌بندی', '۵۹.۴٪ این نظرها واقعاً مفیدند', C['gold'], '🏅'),
    ('0.51', 'F1 کلاس helpful', 'recall ۰.۶۷ · precision ۰.۴۱', C['violet'], '⚖️'),
], cols=4)

# ================================================================= the label
ui.section('01', 'The Label', 'مفید یعنی چه؟',
           'در داده‌ی آموزش ۷۷٪ نظرها هیچ رأیی ندارند و هیچ نظری دقیقاً ۱ رأی ندارد؛ پس <code>vote ≥ 2</code> در عمل یعنی «کسی به این نظر رأی داده است». '
           'این برچسب فقط به کیفیت متن بستگی ندارد: نظری که دیده نشود رأی هم نمی‌گیرد.')
c1, c2 = st.columns([1, 1.35], gap='large')
with c1:
    with st.container(border=True):
        ui.sub('Helpful share in the training pool', 'سهم برچسب مثبت')
        ui.donut([('no vote', 77.2, C['slate']), ('vote ≥ 2 · helpful', 22.8, ACC)], height=300, key='hp_donut',
                 center='23%', center_sub='helpful', fmt='{b}\n{d}%')
with c2:
    with st.container(border=True):
        ui.sub('Reviews by number of votes', 'شش مقدار پرتکرار در داده‌ی آموزش · محور عمودی لگاریتمی')
        votes = [('0', 647476), ('1', 0), ('2', 68047), ('3', 35503), ('4', 20755), ('5', 13617), ('6', 9523)]
        fig = go.Figure(go.Bar(x=[v for v, _ in votes], y=[max(n, 1) for _, n in votes],
                               marker_color=[C['slate'], C['red']] + [ACC] * 5,
                               text=[f'{n:,}' if n else 'none' for _, n in votes], textposition='outside',
                               textfont=dict(color=C['text2']), cliponaxis=False,
                               hovertemplate='%{x} votes<br>%{text} reviews<extra></extra>'))
        fig.update_yaxes(type='log', dtick=1, title='reviews', range=[0, 6.3])
        fig.update_xaxes(title='vote', type='category')
        ui.show(fig, 300)
ui.code('bonus_helpful', [4])

# ================================================================= v2 -> v3
ui.section('02', 'Why v3 Replaced v2', 'اشتباهی که با بررسی خود داده پیدا شد',
           'نسخه‌ی ۲ با یک تقسیم زمانی روی ۱۰٪ جدیدترین نظرها validate می‌شد. ولی test همان بازه‌ی زمانی آموزش را پوشش می‌دهد و نرخ پایه‌اش خیلی بالاتر است. '
           'PR-AUC و F1 مستقیم به نرخ پایه وابسته‌اند، پس عددهای v2 بدتر از واقعیت به نظر می‌رسیدند و آستانه و stacker هم روی توزیع اشتباهی تنظیم شده بودند.')
c1, c2 = st.columns([1, 1.2], gap='large')
with c1:
    with st.container(border=True):
        ui.sub('Base rate of the evaluation set', 'سهم نظرهای helpful')
        ui.hbar_race([('v2 validation · newest 10%', 0.098, C['red']), ('v3 validation · random', 0.2272, ACC),
                      ('labelled test set', 0.2467, C['sky'])], height=210, key='hp_base', fmt='{c}', xmax=0.3)
        ui.note('اعداد کسری‌اند: ۰.۱۰ یعنی ۱۰٪. AUC نسخه‌ی ۲ (۰.۷۶) تقریباً با تقسیم تصادفی قبلی (۰.۷۶۰) برابر بود؛ یعنی رتبه‌بندی بد نبود، فقط معیارهای وابسته به نرخ پایه گمراه می‌کردند.')
with c2:
    ui.flow([
        ('Validation ≠ test', 'validation نسخه‌ی ۲ نرخ پایه‌ی ۱۰٪ داشت و test ۲۵٪؛ آستانه روی توزیعی تنظیم شد که test ندارد.'),
        ('Cohort label = raw label', 'صدک ۷۵ رأی‌ها در هر ماه صفر بود (حداکثر ۲)، پس برچسب ماهانه دقیقاً همان vote ≥ 2 می‌شد.'),
        ('test has votes', '<code>test_data.csv</code> ستون vote دارد (۴٬۹۳۳ از ۲۰٬۰۰۰ مثبت)، پس ارزیابی نهایی روی test واقعی و دست‌نخورده ممکن شد.'),
    ])
    ui.callout('<b>تغییرات v3:</b> تقسیم تصادفی train/validation که شبیه test است، برچسب <code>vote ≥ 2</code>، ورودی فقط متن، '
               'و گزارش <b>lift</b> که بین مجموعه‌هایی با نرخ پایه‌ی متفاوت قابل مقایسه است.', 'ok')

with st.container(border=True):
    ui.sub('Train and test share the same months', 'چپ: نرخ helpful در هر ماه · راست: سهم هر ماه از کل نظرها')
    fm = ui.nbfig('bonus_helpful/cell004_0.json')['data']
    fig = make_subplots(rows=1, cols=2, horizontal_spacing=0.08)
    for k, (name, col, dash) in enumerate([('train', ACC, None), ('test', C['gold'], 'dot')]):
        fig.add_scatter(x=fm[k]['x'], y=fm[k]['y'], name=name, legendgroup=name, line=dict(color=col, width=2.6, dash=dash, shape='spline'),
                        mode='lines+markers', marker=dict(size=5), hovertemplate='%{x}<br>helpful %{y:.1%}<extra>' + name + '</extra>', row=1, col=1)
        fig.add_bar(x=fm[k + 2]['x'], y=fm[k + 2]['y'], name=name, legendgroup=name, showlegend=False, marker_color=ui.rgba(col, .75),
                    hovertemplate='%{x}<br>%{y:.1%} of reviews<extra>' + name + '</extra>', row=1, col=2)
    fig.update_yaxes(tickformat='.0%')
    fig.update_yaxes(title='helpful rate', row=1, col=1)
    fig.update_yaxes(title='share of reviews', row=1, col=2)
    fig.update_xaxes(tickangle=-60, tickfont=dict(size=10))
    fig.update_layout(barmode='group', bargap=0.15, legend=dict(orientation='h', y=1.1, x=1, xanchor='right'), hovermode='x unified')
    ui.show(fig, 380)
ui.callout('test همان ماه‌های آموزش را با سهم‌های تقریباً یکسان پوشش می‌دهد، پس تقسیم <b>تصادفی</b> validation‌ای می‌سازد که شبیه test است. '
           'افت نرخ helpful در ماه‌های آخر ربطی به مدل ندارد: نظرهای جدید هنوز فرصت جمع کردن رأی نداشته‌اند، و این ویژگی در train و test مشترک است.', 'insight')
ui.code('bonus_helpful', [8])

# ================================================================= models
ui.section('03', 'Four Models', 'از طول متن تا ترنسفورمر و stacking')
ui.flow([
    ('Length-only', 'gradient boosting روی ویژگی‌های ساده‌ی طول و سبک نوشتن؛ خط پایه‌ای که متن را «نمی‌خواند».'),
    ('TF-IDF + LR', 'unigram و bigram با رگرسیون لجستیک.'),
    ('DistilRoBERTa', 'یک epoch، ۲۵۶ توکن (۷۰٪ ابتدا + ۳۰٪ انتهای متن)، lr = 3e-5، وزن کلاس مثبت ۱.۸۴.'),
    ('Stacked', 'احتمال ترنسفورمر + احتمال TF-IDF + ویژگی‌های طول؛ روی validation با پیش‌بینی out-of-fold پنج‌تایی سنجیده شد.'),
])
c1, c2 = st.columns(2, gap='large')
for col_, metric, base_v, base_t in [(c1, 'AUC', 0.5, 0.5), (c2, 'PR-AUC', BASE_VAL, BASE_TEST)]:
    with col_:
        with st.container(border=True):
            ui.sub(f'{metric} · validation vs test', 'کم‌رنگ: validation (۴۰ هزار) · پررنگ: test (۲۰ هزار)' +
                   (' · خط‌چین: حدس تصادفی روی test' if metric == 'PR-AUC' else ''))
            fig = go.Figure()
            fig.add_bar(x=MODELS, y=VAL[metric], name='validation · 40k', marker_color=[ui.rgba(MCOL[m], .45) for m in MODELS],
                        text=[f'{ui.fx(v)}' for v in VAL[metric]], textposition='outside', textfont=dict(color=C['text2'], size=11),
                        hovertemplate='%{x}<br>validation %{y:.4f}<extra></extra>')
            fig.add_bar(x=MODELS, y=TEST[metric], name='test · 20k', marker_color=[MCOL[m] for m in MODELS],
                        text=[f'{ui.fx(v)}' for v in TEST[metric]], textposition='outside', textfont=dict(color=C['text'], size=11),
                        hovertemplate='%{x}<br>test %{y:.4f}<extra></extra>')
            if metric == 'PR-AUC':
                fig.add_hline(y=base_t, line_dash='dot', line_color=C['red'], line_width=1.5)
                fig.update_yaxes(range=[0, 0.56])
            else:
                fig.update_yaxes(range=[0.6, 0.75])
            fig.update_layout(barmode='group', bargap=0.25, bargroupgap=0.08, showlegend=False, margin=dict(t=30))
            ui.show(fig, 310)

c1, c2, c3 = st.columns([1, 1, 1.15], gap='medium')
with c1:
    with st.container(border=True):
        ui.gauge(0.7326, 'stacked · test AUC', 0.5, 1.0, ACC, height=250, key='hp_g_auc', sub='0.5 = random ranking')
with c2:
    with st.container(border=True):
        ui.gauge(0.4917, 'stacked · test PR-AUC', 0.0, 1.0, C['sky'], height=250, key='hp_g_ap', mark=BASE_TEST,
                 sub='red tick = random guess (0.25)')
with c3:
    with st.container(border=True):
        ui.sub('Lift in the top 10% · test', 'دقت در ۱۰٪ بالا ÷ نرخ پایه')
        ui.hbar_race([(m, v, MCOL[m]) for m, v in zip(MODELS[::-1], TEST['lift'][::-1])], height=200, key='hp_lift', fmt='×{c}', xmin=0, xmax=2.7)

c1, c2 = st.columns([1.3, 1], gap='large')
with c1:
    with st.container(border=True):
        ui.sub('Transformer training · validation subset', 'ارزیابی هر ۲۰۰۰ قدم؛ بهترین checkpoint در قدم ۸۰۰۰')
        steps = [2000, 4000, 6000, 8000, 9375]
        auc = ui.nbfig('bonus_helpful/cell013_0.json')['data'][0]['y']
        ap = [0.4278, 0.4446, 0.4453, 0.4525, 0.4525]
        fig = make_subplots(specs=[[{'secondary_y': True}]])
        fig.add_scatter(x=steps, y=auc, name='val AUC', mode='lines+markers+text', line=dict(color=C['violet'], width=3, shape='spline'),
                        marker=dict(size=9), text=[f'{ui.fx(v)}' for v in auc], textposition='top center', textfont=dict(color=C['text2'], size=11))
        fig.add_scatter(x=steps, y=ap, name='val PR-AUC', mode='lines+markers', line=dict(color=C['sky'], width=2, dash='dot'),
                        marker=dict(size=7), secondary_y=True)
        fig.add_vline(x=8000, line_dash='dash', line_color=ACC)
        fig.update_yaxes(title='AUC', range=[0.71, 0.735], dtick=0.01, tickformat='.2f', secondary_y=False)
        fig.update_yaxes(title='PR-AUC', range=[0.42, 0.46], dtick=0.01, tickformat='.2f', secondary_y=True, showgrid=False)
        fig.update_xaxes(title='training step (batch 32)')
        fig.update_layout(legend=dict(orientation='h', y=1.14, x=1, xanchor='right'))
        ui.show(fig, 300)
with c2:
    ui.callout('بهبودها کوچک ولی <b>پایدار</b>اند: ترنسفورمر نسبت به TF-IDF حدود ۰.۰۱۴ AUC و stacking حدود ۰.۰۰۴ دیگر اضافه می‌کند، '
               'و ترتیب مدل‌ها در validation و test یکی است. نکته‌ی مهم‌تر: مدلی که <b>فقط طول و سبک</b> را می‌بیند خودش به AUC ‏۰.۷۰ می‌رسد.', 'insight')
    ui.callout('checkpoint ترنسفورمر روی زیرمجموعه‌ای از validation انتخاب شد که بعداً برای stacking هم استفاده شد، پس عدد stacked روی validation '
               'کمی خوش‌بینانه است. برای همین گزارش نهایی روی test است که هیچ چیز رویش تنظیم نشده.', 'warn')
ui.code('bonus_helpful', [7, 10, 12, 13, 15])

# ================================================================= threshold explorer
ui.section('04', 'Threshold Explorer', 'آستانه را جابه‌جا کن و اثرش را زنده ببین',
           'همه‌ی نمودارهای این بخش از <code>helpful_predictions.csv</code> (احتمال مدل stacked برای ۲۰٬۰۰۰ نظر test) همین‌جا محاسبه می‌شوند. '
           'آستانه‌ی رسمی <b>۰.۲۴</b> روی validation تنظیم شده؛ بقیه‌ی موقعیت‌ها فقط برای دیدن مصالحه‌ی precision و recall است و عدد قابل گزارش نیست، '
           'چون انتخاب آستانه روی test یعنی نشت اطلاعات.')
p_all, y_all = predictions()
PRESETS = {'0.24 · validation': THR, 'top 10%': float(np.quantile(p_all, 0.90)),
           'top 25%': float(np.quantile(p_all, 0.75)), 'top 50%': float(np.quantile(p_all, 0.50))}
st.session_state.setdefault('hp_thr', THR)


def _preset():
    choice = st.session_state.get('hp_preset')
    if choice:
        st.session_state['hp_thr'] = round(PRESETS[choice], 3)


with st.container(border=True):
    cc1, cc2 = st.columns([1.25, 1], gap='large')
    with cc1:
        t = st.slider('decision threshold', 0.05, 0.85, step=0.001, key='hp_thr', format='%.2f')
        tt = f'{ui.half_up(t, 2):.2f}'      # threshold as shown on the slider
    with cc2:
        st.segmented_control('presets', list(PRESETS), key='hp_preset', on_change=_preset, label_visibility='collapsed')
        ui.note('top-k یعنی سیاست رتبه‌بندی: «k درصد بالای فهرست را نشان بده». این سیاست به برچسب نیازی ندارد.')
    r = at_threshold(t)

    c1, c2 = st.columns([1, 1.6], gap='large')
    with c1:
        share_txt = fa(ui.pct(r['share']))
        ui.sub('Confusion matrix · test', f'آستانه {tt} · {share_txt} نظرها helpful پیش‌بینی می‌شوند')
        st.html(f"""<div class="cm">
          <div></div><div class="h">predicted<br>helpful</div><div class="h">predicted<br>not helpful</div>
          <div class="h">actual<br>helpful</div>
          <div class="cell" style="--c:{C['green']}"><b>{r['tp']:,}</b><span>true positive</span></div>
          <div class="cell" style="--c:{C['red']}"><b>{r['fn']:,}</b><span>missed</span></div>
          <div class="h">actual<br>not helpful</div>
          <div class="cell" style="--c:{C['orange']}"><b>{r['fp']:,}</b><span>false alarm</span></div>
          <div class="cell" style="--c:{C['slate']}"><b>{r['tn']:,}</b><span>true negative</span></div>
        </div>""")
        ui.note(f'accuracy {ui.fx(r["acc"])} · ولی با نرخ پایه‌ی ۲۵٪ مدلی که همیشه «not helpful» بگوید هم accuracy ‏۰.۷۵۳ دارد؛ '
                'برای همین معیار اصلی این مسئله AUC، PR-AUC و lift است.')
    with c2:
        g1, g2, g3 = st.columns(3)
        with g1:
            ui.gauge(r['precision'], 'precision', 0, 1, C['sky'], height=215, key='hp_tp', decimals=3, mark=BASE_TEST)
        with g2:
            ui.gauge(r['recall'], 'recall', 0, 1, C['green'], height=215, key='hp_tr', decimals=3)
        with g3:
            ui.gauge(r['f1'], 'F1 · helpful', 0, 1, C['violet'], height=215, key='hp_tf', decimals=3)
        ui.note('خط قرمز روی precision نرخ پایه است: هر آستانه‌ای که precision بالاتر از ۰.۲۵ بدهد بهتر از حدس تصادفی است.')

    fpr, tpr, prec, rec, frac, gains = curves()
    c1, c2, c3 = st.columns(3, gap='medium')
    with c1:
        ui.sub('ROC', 'AUC = 0.733')
        fig = go.Figure()
        fig.add_scatter(x=[0, 1], y=[0, 1], mode='lines', line=dict(color=C['muted'], dash='dot', width=1), hoverinfo='skip', showlegend=False)
        fig.add_scatter(x=fpr, y=tpr, mode='lines', line=dict(color=ACC, width=3), fill='tozeroy', fillcolor=ui.rgba(ACC, .10),
                        hovertemplate='FPR %{x:.3f}<br>TPR %{y:.3f}<extra></extra>', showlegend=False)
        fig.add_scatter(x=[r['fpr']], y=[r['recall']], mode='markers', marker=dict(size=15, color=C['gold'], line=dict(color='#fff', width=2)),
                        hovertemplate='threshold ' + tt + '<br>FPR %{x:.3f}<br>TPR %{y:.3f}<extra></extra>', showlegend=False)
        fig.update_xaxes(title='false positive rate', range=[0, 1]); fig.update_yaxes(title='recall (TPR)', range=[0, 1.02])
        ui.show(fig, 300)
    with c2:
        ui.sub('Precision–recall', 'PR-AUC = 0.492')
        fig = go.Figure()
        fig.add_hline(y=BASE_TEST, line_dash='dot', line_color=C['red'], annotation_text='random', annotation_position='bottom right',
                      annotation_font_color=C['red'])
        fig.add_scatter(x=rec, y=prec, mode='lines', line=dict(color=C['sky'], width=3), hovertemplate='recall %{x:.3f}<br>precision %{y:.3f}<extra></extra>',
                        showlegend=False)
        fig.add_scatter(x=[r['recall']], y=[r['precision']], mode='markers', marker=dict(size=15, color=C['gold'], line=dict(color='#fff', width=2)),
                        hovertemplate='threshold ' + tt + '<br>recall %{x:.3f}<br>precision %{y:.3f}<extra></extra>', showlegend=False)
        fig.update_xaxes(title='recall', range=[0, 1]); fig.update_yaxes(title='precision', range=[0, 1.02])
        ui.show(fig, 300)
    with c3:
        ui.sub('Cumulative gains', 'چند درصد نظرهای مفید در k درصد بالای فهرست است')
        fig = go.Figure()
        fig.add_scatter(x=[0, 1], y=[0, 1], mode='lines', line=dict(color=C['muted'], dash='dot', width=1), hoverinfo='skip', showlegend=False)
        fig.add_scatter(x=frac, y=gains, mode='lines', line=dict(color=C['violet'], width=3), fill='tonexty', fillcolor=ui.rgba(C['violet'], .12),
                        hovertemplate='top %{x:.0%} of reviews<br>%{y:.0%} of helpful ones<extra></extra>', showlegend=False)
        fig.add_scatter(x=[r['share']], y=[r['recall']], mode='markers', marker=dict(size=15, color=C['gold'], line=dict(color='#fff', width=2)),
                        hovertemplate='flag %{x:.1%} of reviews<br>catch %{y:.1%} of helpful<extra></extra>', showlegend=False)
        fig.update_xaxes(title='share of reviews flagged', tickformat='.0%', range=[0, 1])
        fig.update_yaxes(title='share of helpful caught', tickformat='.0%', range=[0, 1.02])
        ui.show(fig, 300)

    ui.sub('Score distribution by true label', 'خط عمودی: آستانه‌ی فعلی')
    fig = go.Figure()
    for lab, name, col in [(0, 'not helpful', C['slate']), (1, 'helpful', ACC)]:
        fig.add_histogram(x=p_all[y_all == lab], name=f'{name} · {int((y_all == lab).sum()):,}', histnorm='probability density',
                          xbins=dict(start=0, end=1, size=0.02), marker_color=ui.rgba(col, .6), marker_line_width=0,
                          hovertemplate='score %{x}<br>density %{y:.2f}<extra>' + name + '</extra>')
    fig.add_vline(x=t, line_color=C['gold'], line_width=3, annotation_text=f'threshold {tt}', annotation_font_color=C['gold'])
    fig.update_layout(barmode='overlay', legend=dict(orientation='h', y=1.15, x=1, xanchor='right'))
    fig.update_xaxes(title='predicted probability of helpful', range=[0, 1]); fig.update_yaxes(title='density')
    ui.show(fig, 280)
ui.callout('دو توزیع روی هم افتاده‌اند: نظرهای مفید معمولاً امتیاز بالاتری می‌گیرند، ولی هیچ آستانه‌ای آن‌ها را تمیز جدا نمی‌کند. '
           'برای همین کاربرد درست این مدل <b>مرتب‌سازی</b> است، نه برچسب قطعی بله/نه: اگر فروشگاه ۱۰٪ بالای فهرست را اول نشان دهد، '
           '۵۹.۴٪ آن‌ها واقعاً مفیدند، در برابر ۲۵٪ در حالت تصادفی.', 'insight')
ui.code('bonus_helpful', [16, 17])

# ================================================================= where it works
ui.section('05', 'Where Does It Work?', 'کیفیت مدل در هر ماه و برای محصول‌های دیده‌شده و ندیده')
with st.container(border=True):
    ui.sub('AUC by publication month · test', 'بالا: AUC دو مدل · پایین: نرخ helpful همان ماه (عرض = تعداد نظر)')
    m = MONTHS
    fig = make_subplots(rows=2, cols=1, shared_xaxes=True, row_heights=[0.62, 0.38], vertical_spacing=0.06)
    fig.add_hrect(y0=m.auc_stack.min(), y1=m.auc_stack.max(), fillcolor=ui.rgba(ACC, .06), line_width=0, row=1, col=1)
    fig.add_scatter(x=m.month, y=m.auc_trf, name='transformer', mode='lines+markers', line=dict(color=C['violet'], width=2, dash='dot'),
                    marker=dict(size=6), row=1, col=1)
    fig.add_scatter(x=m.month, y=m.auc_stack, name='stacked', mode='lines+markers', line=dict(color=ACC, width=3, shape='spline'),
                    marker=dict(size=8), customdata=m.n, hovertemplate='%{x}<br>AUC %{y:.3f}<br>%{customdata} reviews<extra>stacked</extra>',
                    row=1, col=1)
    fig.add_bar(x=m.month, y=m.pos_rate, name='helpful rate', marker_color=[ui.rgba(C['gold'], .35 + .5 * v / m.pos_rate.max()) for v in m.pos_rate],
                customdata=m.n, hovertemplate='%{x}<br>helpful %{y:.1%}<br>%{customdata} reviews<extra></extra>', showlegend=False, row=2, col=1)
    fig.update_yaxes(title='AUC', range=[0.64, 0.8], row=1, col=1)
    fig.update_yaxes(title='helpful', tickformat='.0%', row=2, col=1)
    fig.update_xaxes(tickangle=-60, tickfont=dict(size=10), row=2, col=1)
    fig.update_layout(legend=dict(orientation='h', y=1.1, x=1, xanchor='right'), hovermode='x unified')
    ui.show(fig, 440)
ui.callout('نرخ helpful از ۳۳٪ در ۲۰۱۶ تا ۱۱٪ در ۲۰۱۸ پایین می‌آید ولی AUC تقریباً ثابت در بازه‌ی ۰.۶۷ تا ۰.۷۸ می‌ماند. یعنی <b>رتبه‌بندی</b> مدل '
           'به زمان حساس نیست و فقط نرخ پایه جابه‌جا می‌شود؛ دقیقاً همان چیزی که PR-AUC و F1 نسخه‌ی ۲ را خراب کرده بود.', 'insight')

c1, c2, c3 = st.columns([1, 1, 1.1], gap='medium')
with c1:
    with st.container(border=True):
        ui.gauge(0.7354, 'product seen in training', 0.5, 1.0, ACC, height=240, key='hp_seen', sub='18,088 reviews · helpful 25.2%')
with c2:
    with st.container(border=True):
        ui.gauge(0.7000, 'product NOT seen', 0.5, 1.0, C['orange'], height=240, key='hp_unseen', sub='1,912 reviews · helpful 19.2%', fmt='0.700')
with c3:
    ui.callout('برای محصول‌هایی که در نمونه‌ی آموزش نبوده‌اند AUC حدود ۰.۰۴ پایین‌تر است و نرخ helpful هم کمتر است. '
               'این نشان می‌دهد بخشی از «مفید بودن» به <b>میزان دیده‌شدن محصول</b> برمی‌گردد، نه فقط به خود متن.', 'warn')
    ui.note('سهم پیش‌بینی helpful با آستانه‌ی ۰.۲۴: ۴۰.۱٪ در برابر نرخ پایه‌ی ۲۵٪؛ آستانه عمداً به سمت recall تنظیم شده.')
ui.code('bonus_helpful', [19])

# ================================================================= diagnostics
ui.section('06', 'How Much Is in the Text?', 'چقدر از برچسب بدون خواندن متن قابل توضیح است',
           'این امتیازهای تشخیصی <b>ورودی هیچ مدلی نیستند</b> (مدل‌ها فقط متن می‌بینند) و فقط توضیح می‌دهند چرا مدل‌های متنی حدود AUC ‏۰.۷۵ متوقف می‌شوند.')
c1, c2 = st.columns([1.3, 1], gap='large')
with c1:
    with st.container(border=True):
        ui.sub('Test AUC: signals with and without the text', 'خاکستری و نارنجی: بدون خواندن متن')
        ui.hbar_race([
            ('stacked · text', 0.7326, ACC), ('transformer · text', 0.7291, C['violet']), ('TF-IDF + LR · text', 0.7150, C['orange']),
            ('length-only model', 0.6986, C['slate']), ('review length only', 0.6918, C['slate']),
            ('product id only · no text', 0.6528, C['red'])], height=300, key='hp_diag', fmt='{c}', xmin=0.5, xmax=0.76)
with c2:
    ui.kpis([
        ('0.692', 'AUC فقط با تعداد کاراکترها', 'یک عدد، بدون هیچ کلمه‌ای', C['slate'], '📏'),
        ('0.653', 'AUC فقط با نرخ helpful محصول', '۹۰٪ نظرهای test محصولشان در train بوده', C['red'], '📦'),
    ], cols=1)
    ui.callout('بخش بزرگی از «مفید بودن» را <b>طول نظر</b> و <b>میزان دیده‌شدن محصول</b> تعیین می‌کند. متن فقط حدود ۰.۰۴ AUC '
               'به طول اضافه می‌کند؛ سقف این مسئله بیشتر از برچسب می‌آید تا از مدل.', 'info')
ui.code('bonus_helpful', [21])

# ================================================================= limits
ui.section('07', 'Limits & Next Steps', 'محدودیت‌ها و قدم بعدی')
c1, c2, c3 = st.columns(3, gap='medium')
with c1:
    ui.callout('<b>برچسب به زمان و ترافیک وابسته است.</b> نظر جدید یا محصول کم‌بازدید فرصت رأی گرفتن ندارد؛ برچسبی که با سن نظر یا ترافیک محصول نرمال شود '
               'هدف تمیزتری می‌سازد.', 'warn')
with c2:
    ui.callout('<b>فقط یک epoch و ۲۵۶ توکن.</b> نظرهای مفید معمولاً بلندند؛ مدل‌های طولانی‌تر (Longformer) یا چند تکه از متن می‌تواند کمک کند. '
               'عنوان نظر (summary) هم هنوز استفاده نشده.', 'info')
with c3:
    ui.callout('<b>مدل برای رتبه‌بندی است.</b> با lift ‏۲.۴ برابر در ۱۰٪ بالا، کاربرد مناسبش مرتب‌سازی نظرهای جدید قبل از اینکه رأی بگیرند است، '
               'نه حکم قطعی درباره‌ی یک نظر.', 'ok')
ui.footer()
