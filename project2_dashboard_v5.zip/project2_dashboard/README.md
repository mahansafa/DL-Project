# Project 2 Dashboard — Quera AI Bootcamp

<div dir="rtl">

داشبورد تعاملی پروژه‌ی دوم با Streamlit: بخش NLP (تحلیل نظرهای آمازون) و بخش Vision (ویدئوی دوربین خودرو)، هر کدام با تسک اصلی و امتیازی.
همه‌ی عددها و نمودارها از خروجی نوت‌بوک‌ها آمده‌اند و فونت‌ها و داده‌ها کنار برنامه‌اند، پس بدون اینترنت هم اجرا می‌شود.

</div>

## Run

```
pip install -r requirements.txt
streamlit run app.py
```

<div dir="rtl">

دستور آخر را از داخل همین پوشه اجرا کنید تا تم و فونت‌ها از `.streamlit/config.toml` خوانده شوند. Streamlit نسخه‌ی ۱.۶۶ یا جدیدتر لازم است (برای نمودارهای ECharts).

**گرد کردن عددها:** امتیاز نهایی DeBERTa (۰.۶۹۵) همه‌جا ۰.۷۰ نوشته شده. عددی که به درصد نوشته شده اگر اعشارش ۵ یا بیشتر باشد به بالا گرد می‌شود (۷۶.۵٪ → ۷۷٪)؛ عددی که به درصد نیست اگر رقم سوم اعشارش ۵ یا بیشتر باشد با دو رقم اعشار به بالا گرد می‌شود (۰.۷۴۶ → ۰.۷۵)؛ بقیه همان خروجی نوت‌بوک‌اند. این قاعده در `lib/ui.py` (توابع `nice` و `fx`) پیاده شده و برچسب‌ها، tooltipها و گیج‌ها را هم پوشش می‌دهد. نوت‌بوک‌ها در صفحه‌ی Notebooks بدون تغییر نمایش داده می‌شوند.

**تم روشن و تاریک:** از منوی ⋮ بالای صفحه بین System، Light و Dark جابه‌جا شوید. حالت پیش‌فرض System است، یعنی تم سیستم‌عامل را دنبال می‌کند.
رنگ‌های بخش‌های سفارشی با CSS (`light-dark()`) و رنگ‌های خنثای نمودارها با یک لایه‌ی CSS عوض می‌شوند، پس تعویض تم فوری است و صفحه دوباره اجرا نمی‌شود.
منو در حالت `toolbarMode = "developer"` گزینه‌های Rerun، Auto rerun، Clear cache، Print، Record screen و دکمه‌ی Deploy را هم دارد.

</div>

## Pages

| Section | Page | Notebook |
|---|---|---|
| Overview | Home — team, mentor, project map | — |
| NLP · Main task | Part 1 · EDA | `part1_eda.ipynb` |
| | Part 2 · Warranty | `part2_warranty.ipynb`, `part2_setfit.ipynb` |
| | Part 3 · Sentiment model | `part3_finetune.ipynb`, `part3_final.ipynb` |
| | Live prediction | TF-IDF model from Part 3 |
| NLP · Bonus | Hidden incentivized reviews | `bonus_incentivized_reviews.ipynb`, `bonus_minilm_finetune.ipynb` |
| | Review helpfulness (live threshold explorer) | `bonus_helpfulness.ipynb`, `data/bonus_helpful/helpful_predictions.csv` |
| | HMM · alternative method for the main sentiment task | `task_3-HMM.ipynb` |
| Vision · Main task | Accident detection | `accident_preprocessing.ipynb`, `accident_mil_model.ipynb` |
| Vision · Bonus | Collision anticipation | `anticipation_model.ipynb` |
| Resources | Notebook explorer | all notebooks |

## Folders

```
app.py              navigation
views/              one file per page
lib/ui.py           theme, CSS, chart helpers (Plotly + ECharts)
lib/data.py         cached loaders
lib/model.py        TF-IDF model for live prediction
data/               outputs, figure data and notebook cells
static/             fonts and logo
```
